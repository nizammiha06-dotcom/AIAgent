package com.aiagent.assistant.core.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** আসল SMS পাঠানো (SmsManager)। Carrier-এর queue-এ যায়; delivery নিশ্চিত করা যায় না। */
@Singleton
class SmsSender @Inject constructor(
    @ApplicationContext private val context: Context
) {

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) ==
            PackageManager.PERMISSION_GRANTED

    fun send(to: String, body: String): Result<Unit> = runCatching {
        require(to.isNotBlank()) { "প্রাপকের নম্বর নেই" }
        require(body.isNotBlank()) { "বার্তা খালি" }
        val manager = smsManager()
        val parts = manager.divideMessage(body)
        if (parts.size <= 1) {
            manager.sendTextMessage(to, null, body, null, null)
        } else {
            manager.sendMultipartTextMessage(to, null, parts, null, null)
        }
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            SmsManager.getDefault()
        }
}
