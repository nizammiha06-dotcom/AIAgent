package com.aiagent.assistant.core.voice

import android.content.Context
import com.aiagent.assistant.core.agent.AgentServiceController
import com.aiagent.assistant.data.ai.AiProviderConfig
import com.aiagent.assistant.data.ai.SecureProviderStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class VoicePhase { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.IDLE,
    val partial: String = "",
    val lastReply: String = "",
    val error: String? = null
)

/** Live voice-এর একটি engine। Gemini Live অথবা পুরনো speech loop। */
interface VoiceBackend {
    val state: StateFlow<VoiceUiState>

    /** শেষ হলে কল হয়: null = স্বাভাবিক শেষ, String = error। */
    var onFinished: ((String?) -> Unit)?

    fun start()
    fun stop()
}

/**
 * Live voice-এর একক entry point (UI, wake word, bubble সবাই এটাই ব্যবহার করে)।
 * Gemini key থাকলে Gemini Live; ব্যর্থ হলে বা key না থাকলে পুরনো voice loop।
 */
@Singleton
class LiveVoiceSession @Inject constructor(
    @ApplicationContext private val context: Context,
    private val gemini: GeminiLiveSession,
    private val loop: SpeechLoopSession,
    private val providers: SecureProviderStore
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(VoiceUiState())
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    /** Session শেষ হলে কল হয় (Background Agent wake word শোনা আবার শুরু করতে)। */
    var onStopped: (() -> Unit)? = null

    private var active: VoiceBackend? = null
    private var mirror: Job? = null

    val isActive: Boolean get() = active != null

    fun start() {
        if (active != null) return
        val hasGeminiKey = !providers.getApiKey(AiProviderConfig.GEMINI_ID).isNullOrBlank()
        if (hasGeminiKey) {
            runBackend(gemini, fallbackToLoop = true)
        } else {
            runBackend(loop, fallbackToLoop = false)
        }
    }

    fun stop() {
        val backend = active ?: return
        active = null
        mirror?.cancel()
        mirror = null
        backend.onFinished = null
        backend.stop()
        _state.value = VoiceUiState()
        onStopped?.invoke()
    }

    private fun runBackend(backend: VoiceBackend, fallbackToLoop: Boolean) {
        active = backend
        // Background-এ mic চালু রাখতে foreground service
        AgentServiceController.start(context)
        mirror?.cancel()
        mirror = scope.launch { backend.state.collect { _state.value = it } }
        backend.onFinished = { error -> onBackendFinished(backend, error, fallbackToLoop) }
        backend.start()
    }

    private fun onBackendFinished(backend: VoiceBackend, error: String?, fallbackToLoop: Boolean) {
        if (active !== backend) return
        mirror?.cancel()
        mirror = null
        active = null
        if (error != null && fallbackToLoop) {
            _state.value = VoiceUiState(
                phase = VoicePhase.THINKING,
                partial = "Gemini Live চালু হয়নি, সাধারণ voice mode চালু হচ্ছে…",
                error = error
            )
            runBackend(loop, fallbackToLoop = false)
            return
        }
        _state.value = if (error != null) {
            VoiceUiState(phase = VoicePhase.ERROR, error = error)
        } else {
            VoiceUiState()
        }
        onStopped?.invoke()
    }
}
