package com.aiagent.assistant.presentation.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.data.settings.ThemeMode
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.components.EditTextDialog
import com.aiagent.assistant.ui.theme.Spacing

private enum class EditField { APP_NAME, ASSISTANT_NAME, WAKE_WORD }

private val voiceStyles = listOf(
    "male" to "Male · পুরুষ",
    "female" to "Female · নারী",
    "child" to "Child · শিশু",
    "robot" to "Robot · রোবট",
    "soft" to "Soft · নরম",
    "deep" to "Deep · গম্ভীর",
    "custom" to "Custom · নিজের ভয়েস"
)

private val languages = listOf(
    "bn" to "বাংলা",
    "en" to "English",
    "system" to "System · ডিভাইস অনুযায়ী"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenProviders: () -> Unit,
    onOpenDebug: () -> Unit,
    onOpenCustomSkills: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val s by viewModel.settings.collectAsState()
    var editing by remember { mutableStateOf<EditField?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings · সেটিংস") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            SectionHeader("Identity · পরিচয়")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    ClickRow("App name · অ্যাপের নাম", s.appName) { editing = EditField.APP_NAME }
                    ClickRow("Assistant name · সহকারীর নাম", s.assistantName) { editing = EditField.ASSISTANT_NAME }
                    SwitchRow(
                        title = "Wake word · ওয়েক ওয়ার্ড",
                        subtitle = "\"${s.wakeWord}\" বললে সহকারী জেগে উঠবে (Step 9-এ চালু হবে)",
                        checked = s.wakeWordEnabled,
                        onChange = { v -> viewModel.update { it.copy(wakeWordEnabled = v) } }
                    )
                    ClickRow("Wake word text · ওয়েক ওয়ার্ড লেখা", null) { editing = EditField.WAKE_WORD }
                }
            }

            SectionHeader("Appearance · থিম")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    val themes = listOf(
                        ThemeMode.SYSTEM to "System · ডিভাইস অনুযায়ী",
                        ThemeMode.LIGHT to "Light · হালকা",
                        ThemeMode.DARK to "Dark · গাঢ়"
                    )
                    themes.forEach { (mode, label) ->
                        RadioRow(label, selected = s.themeMode == mode) {
                            viewModel.update { it.copy(themeMode = mode) }
                        }
                    }
                }
            }

            SectionHeader("Language · ভাষা")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    languages.forEach { (code, label) ->
                        RadioRow(label, selected = s.language == code) {
                            viewModel.setLanguage(code)
                        }
                    }
                }
            }

            SectionHeader("Voice · কণ্ঠস্বর")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    Text("Voice style · ধরন", style = MaterialTheme.typography.titleMedium)
                    voiceStyles.forEach { (code, label) ->
                        RadioRow(label, selected = s.voiceStyle == code) {
                            viewModel.update { it.copy(voiceStyle = code) }
                        }
                    }
                    Spacer(Modifier.padding(top = Spacing.xs))
                    Text(
                        "Speed · গতি ${"%.1f".format(s.voiceSpeed)}x",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = s.voiceSpeed,
                        onValueChange = { v -> viewModel.update { it.copy(voiceSpeed = v) } },
                        valueRange = 0.5f..2f
                    )
                    Text(
                        "Pitch · সুর ${"%.1f".format(s.voicePitch)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = s.voicePitch,
                        onValueChange = { v -> viewModel.update { it.copy(voicePitch = v) } },
                        valueRange = 0.5f..2f
                    )
                    Text(
                        "Voice preview Step 9-এ চালু হবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            SectionHeader("Agent behavior · এজেন্টের আচরণ")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    SwitchRow(
                        title = "Confirm sensitive actions",
                        subtitle = "Call, SMS পাঠানো, delete করার আগে জিজ্ঞেস করবে",
                        checked = s.confirmSensitiveActions,
                        onChange = { v -> viewModel.update { it.copy(confirmSensitiveActions = v) } }
                    )
                    SwitchRow(
                        title = "Auto execute",
                        subtitle = "নিরাপদ কাজ নিজে থেকে শেষ করবে",
                        checked = s.agentAutoExecute,
                        onChange = { v -> viewModel.update { it.copy(agentAutoExecute = v) } }
                    )
                    SwitchRow(
                        title = "SMS auto reply",
                        subtitle = "আসা SMS-এ AI ছোট উত্তর পাঠাবে। OTP, bank বা payment বার্তায় উত্তর দেবে না।",
                        checked = s.smsAutoReply,
                        onChange = { v -> viewModel.update { it.copy(smsAutoReply = v) } }
                    )
                    Text("Live voice · কণ্ঠ", style = MaterialTheme.typography.labelLarge)
                    listOf("Kore", "Aoede", "Puck", "Charon").forEach { voice ->
                        RadioRow(
                            label = voice,
                            selected = s.liveVoice == voice,
                            onSelect = { viewModel.update { it.copy(liveVoice = voice) } }
                        )
                    }
                }
            }

            SectionHeader("Permissions & providers")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    ClickRow("Permissions · অনুমতি", "Accessibility, Overlay, Notification ইত্যাদি", onOpenPermissions)
                    ClickRow("AI Providers · AI প্রদানকারী", "API key ও model (Step 7-এ আসবে)", onOpenProviders)
                    ClickRow("Screen debug · স্ক্রিন পরীক্ষা", "Accessibility-এর screen element দেখো", onOpenDebug)
                    ClickRow("Custom skills · নিজের skill", "নিজের app-এর label দিয়ে skill বানাও", onOpenCustomSkills)
                }
            }

            SectionHeader("About · পরিচিতি")
            AppCard {
                Column(Modifier.padding(Spacing.md)) {
                    Text("AI Agent · Version 1.0.0", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "Build: Step 1-6 · Bangla & English",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.padding(bottom = Spacing.lg))
        }
    }

    editing?.let { field ->
        val (title, initial) = when (field) {
            EditField.APP_NAME -> "App name · অ্যাপের নাম" to s.appName
            EditField.ASSISTANT_NAME -> "Assistant name · সহকারীর নাম" to s.assistantName
            EditField.WAKE_WORD -> "Wake word · ওয়েক ওয়ার্ড" to s.wakeWord
        }
        EditTextDialog(
            title = title,
            initial = initial,
            onSave = { value ->
                viewModel.update { st ->
                    when (field) {
                        EditField.APP_NAME -> st.copy(appName = value.ifBlank { st.appName })
                        EditField.ASSISTANT_NAME -> st.copy(assistantName = value.ifBlank { st.assistantName })
                        EditField.WAKE_WORD -> st.copy(wakeWord = value.ifBlank { st.wakeWord })
                    }
                }
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = Spacing.sm)
    )
}

@Composable
private fun ClickRow(title: String, value: String?, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = Spacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (value != null) {
                Text(
                    value,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Icon(
            Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = Spacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onSelect)
            .padding(vertical = Spacing.xxs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(Spacing.xs))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
