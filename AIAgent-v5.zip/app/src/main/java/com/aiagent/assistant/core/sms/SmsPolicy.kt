package com.aiagent.assistant.core.sms

import android.content.Context

/** SMS নিরাপত্তা: OTP, password, bank ও payment নিয়ে কাজ করে না; auto reply-তে সীমা। */
object SmsPolicy {

    const val PREFS = "sms_runtime"

    private const val SENDER_COOLDOWN_MS = 120_000L
    private const val HOUR_MS = 3_600_000L
    private const val HOURLY_CAP = 20

    private val sensitiveWords = listOf(
        "otp", "one-time", "one time", "verification code", "password", "passcode",
        "cvv", "pin code", "bank", "card number", "payment", "transaction",
        "bkash", "nagad", "rocket",
        "ওটিপি", "পাসওয়ার্ড", "পিন", "ব্যাংক", "লেনদেন", "পেমেন্ট", "কার্ড নম্বর"
    )
    private val incomingCode = Regex("\\b\\d{4,8}\\b")
    private val outgoingCode = Regex("\\b\\d{6,8}\\b")

    /** পাঠানোর আগে: OTP/password/payment ধরনের বার্তা হলে কারণ, না হলে null। */
    fun outgoingBlockReason(body: String): String? {
        val lower = body.lowercase()
        if (sensitiveWords.any { lower.contains(it) }) {
            return "এই বার্তা OTP, password, bank বা payment-সংক্রান্ত, তাই পাঠানো হবে না"
        }
        if (outgoingCode.containsMatchIn(body)) {
            return "বার্তায় OTP-সদৃশ কোড আছে, তাই পাঠানো হবে না"
        }
        return null
    }

    /** আসা SMS-এ নিজে থেকে উত্তর দেওয়া উচিত কিনা। না হলে কারণ। */
    fun autoReplyBlockReason(from: String, body: String): String? {
        if (from.any { it.isLetter() } || from.count { it.isDigit() } < 7) {
            return "service বা short-code sender"
        }
        if (incomingCode.containsMatchIn(body)) return "কোডসদৃশ বার্তা"
        if (outgoingBlockReason(body) != null) return "সংবেদনশীল বার্তা"
        return null
    }

    /** একই sender-কে বারবার উত্তর ও ঘণ্টায় সীমা। উত্তর দেওয়ার অনুমতি হলে true। */
    fun reserveReply(context: Context, from: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - prefs.getLong("last_$from", 0L) < SENDER_COOLDOWN_MS) return false
        var windowStart = prefs.getLong("hour_start", 0L)
        var count = prefs.getInt("hour_count", 0)
        if (now - windowStart > HOUR_MS) {
            windowStart = now
            count = 0
        }
        if (count >= HOURLY_CAP) return false
        prefs.edit()
            .putLong("last_$from", now)
            .putLong("hour_start", windowStart)
            .putInt("hour_count", count + 1)
            .apply()
        return true
    }
}
