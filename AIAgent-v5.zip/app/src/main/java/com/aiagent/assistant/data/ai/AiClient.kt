package com.aiagent.assistant.data.ai

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class ChatTurn(val role: String, val content: String)

class AiException(val code: Int, message: String) : Exception(message)

/** AI-কে দেওয়া function (tool)। SMS ও contact এখানে যুক্ত হয়। */
interface ToolBridge {
    fun declarations(): JSONArray
    suspend fun execute(name: String, args: JSONObject): JSONObject
}

@Singleton
class AiClient @Inject constructor(
    private val http: OkHttpClient
) {

    /** Text stream। প্রতিটি provider-এর protocol আলাদাভাবে handle হয়। */
    suspend fun stream(
        config: AiProviderConfig,
        apiKey: String?,
        messages: List<ChatTurn>,
        onDelta: suspend (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val request = buildRequest(config, apiKey, messages, stream = true, maxTokens = config.maxTokens, imageB64 = null)
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw AiException(response.code, response.body?.string().orEmpty().take(300))
            }
            val source = response.body?.source() ?: throw AiException(-1, "Empty response")
            val full = StringBuilder()
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data == "[DONE]") break
                val delta = parseStreamChunk(config.protocol, data) ?: continue
                if (delta.isEmpty()) continue
                full.append(delta)
                onDelta(delta)
            }
            if (full.isEmpty()) {
                throw AiException(-1, "খালি উত্তর এসেছে (provider-এর safety filter বা model সমস্যা হতে পারে)")
            }
            full.toString()
        }
    }

    /** Gemini-র function calling loop (non-stream)। Tool call এলে চালিয়ে ফলাফল ফেরত পাঠায়। */
    suspend fun generateWithTools(
        config: AiProviderConfig,
        apiKey: String?,
        turns: List<ChatTurn>,
        tools: ToolBridge
    ): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        for (turn in turns) {
            contents.put(geminiTurn(turn.role, JSONArray().put(JSONObject().put("text", turn.content))))
        }
        val system = geminiSystem(config.systemPrompt + "\n\n" + TOOL_RULES)
        repeat(MAX_TOOL_ROUNDS) {
            val body = JSONObject()
                .put("contents", contents)
                .put("systemInstruction", system)
                .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools.declarations())))
                .put("generationConfig", JSONObject()
                    .put("temperature", config.temperature.toDouble())
                    .put("maxOutputTokens", config.maxTokens))
            val json = postGemini(config, apiKey, "generateContent", body)
            val parts = geminiParts(json)
            val calls = ArrayList<JSONObject>()
            for (i in 0 until parts.length()) {
                parts.optJSONObject(i)?.optJSONObject("functionCall")?.let { calls.add(it) }
            }
            if (calls.isEmpty()) {
                val text = geminiText(parts)
                if (text.isBlank()) throw AiException(-1, "Gemini খালি উত্তর দিয়েছে")
                return@withContext text
            }
            contents.put(JSONObject().put("role", "model").put("parts", parts))
            val responses = JSONArray()
            for (call in calls) {
                val name = call.optString("name")
                val result = tools.execute(name, call.optJSONObject("args") ?: JSONObject())
                responses.put(JSONObject().put("functionResponse", JSONObject()
                    .put("name", name)
                    .put("response", result)))
            }
            contents.put(JSONObject().put("role", "user").put("parts", responses))
        }
        throw AiException(-1, "Tool চালানোর সীমা শেষ হয়েছে")
    }

    /** Provider সংযোগ পরীক্ষা। */
    suspend fun ping(config: AiProviderConfig, apiKey: String?): String = withContext(Dispatchers.IO) {
        val request = buildRequest(
            config, apiKey,
            listOf(ChatTurn("user", "Reply with the single word OK.")),
            stream = false,
            maxTokens = 16,
            imageB64 = null
        )
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw AiException(response.code, body.take(300))
            extractText(config.protocol, JSONObject(body))
        }
    }

    /** Image সহ একটি প্রশ্ন (vision)। Non-streaming। */
    suspend fun describeImage(
        config: AiProviderConfig,
        apiKey: String?,
        prompt: String,
        jpeg: ByteArray
    ): String = withContext(Dispatchers.IO) {
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val request = buildRequest(
            config, apiKey,
            listOf(ChatTurn("user", prompt)),
            stream = false,
            maxTokens = config.maxTokens,
            imageB64 = b64
        )
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw AiException(response.code, body.take(300))
            extractText(config.protocol, JSONObject(body))
        }
    }

    private fun postGemini(config: AiProviderConfig, apiKey: String?, action: String, body: JSONObject): JSONObject {
        val builder = Request.Builder()
            .url(geminiUrl(config, action))
            .header("Accept", "application/json")
        if (!apiKey.isNullOrBlank()) builder.header("x-goog-api-key", apiKey)
        val request = builder
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw AiException(response.code, text.take(300))
            return JSONObject(text)
        }
    }

    private fun extractText(protocol: Protocol, json: JSONObject): String = when (protocol) {
        Protocol.OPENAI_COMPATIBLE -> json.getJSONArray("choices")
            .getJSONObject(0).getJSONObject("message").getString("content")
        Protocol.ANTHROPIC -> json.getJSONArray("content")
            .getJSONObject(0).getString("text")
        Protocol.GEMINI -> geminiText(geminiParts(json)).ifBlank {
            throw AiException(-1, "Gemini খালি উত্তর দিয়েছে")
        }
    }

    private fun parseStreamChunk(protocol: Protocol, data: String): String? {
        val json = JSONObject(data)
        return when (protocol) {
            Protocol.OPENAI_COMPATIBLE -> {
                if (json.has("error")) {
                    throw AiException(-1, json.optJSONObject("error")?.optString("message") ?: "API error")
                }
                json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("delta")?.optString("content")
            }
            Protocol.ANTHROPIC -> when (json.optString("type")) {
                "content_block_delta" -> json.optJSONObject("delta")?.optString("text")
                "error" -> throw AiException(
                    -1, json.optJSONObject("error")?.optString("message") ?: "Anthropic error"
                )
                else -> null
            }
            Protocol.GEMINI -> {
                json.optJSONObject("error")?.let {
                    throw AiException(-1, it.optString("message", "Gemini error"))
                }
                geminiText(geminiParts(json))
            }
        }
    }

    private fun buildRequest(
        config: AiProviderConfig,
        apiKey: String?,
        turns: List<ChatTurn>,
        stream: Boolean,
        maxTokens: Int,
        imageB64: String?
    ): Request {
        val builder = Request.Builder()
        val body = JSONObject()
        val url: String
        when (config.protocol) {
            Protocol.OPENAI_COMPATIBLE -> {
                val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", config.systemPrompt))
                for ((i, turn) in turns.withIndex()) {
                    val image = if (i == turns.lastIndex) imageB64 else null
                    msgs.put(JSONObject().put("role", turn.role).put("content", openAiContent(turn, image)))
                }
                body.put("model", config.model)
                    .put("stream", stream)
                    .put("messages", msgs)
                    .put("temperature", config.temperature.toDouble())
                    .put("max_tokens", maxTokens)
                url = config.baseUrl.trimEnd('/') + "/chat/completions"
                if (config.requiresKey && !apiKey.isNullOrBlank()) {
                    builder.header("Authorization", "Bearer $apiKey")
                }
            }
            Protocol.ANTHROPIC -> {
                val msgs = JSONArray()
                for ((i, turn) in turns.withIndex()) {
                    val image = if (i == turns.lastIndex) imageB64 else null
                    msgs.put(JSONObject().put("role", turn.role).put("content", anthropicContent(turn, image)))
                }
                body.put("model", config.model)
                    .put("stream", stream)
                    .put("system", config.systemPrompt)
                    .put("messages", msgs)
                    .put("max_tokens", maxTokens)
                    .put("temperature", config.temperature.toDouble())
                url = config.baseUrl.trimEnd('/') + "/v1/messages"
                builder.header("x-api-key", apiKey.orEmpty())
                builder.header("anthropic-version", "2023-06-01")
            }
            Protocol.GEMINI -> {
                body.put("contents", geminiContents(turns, imageB64))
                    .put("systemInstruction", geminiSystem(config.systemPrompt))
                    .put("generationConfig", JSONObject()
                        .put("temperature", config.temperature.toDouble())
                        .put("maxOutputTokens", maxTokens))
                url = geminiUrl(config, if (stream) "streamGenerateContent?alt=sse" else "generateContent")
                if (!apiKey.isNullOrBlank()) builder.header("x-goog-api-key", apiKey)
            }
        }
        return builder.url(url)
            .header("Accept", if (stream) "text/event-stream" else "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
    }

    private fun openAiContent(turn: ChatTurn, imageB64: String?): Any {
        if (imageB64 == null) return turn.content
        return JSONArray()
            .put(JSONObject().put("type", "text").put("text", turn.content))
            .put(JSONObject().put("type", "image_url")
                .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64")))
    }

    private fun anthropicContent(turn: ChatTurn, imageB64: String?): Any {
        if (imageB64 == null) return turn.content
        return JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64")
                .put("media_type", "image/jpeg")
                .put("data", imageB64)))
            .put(JSONObject().put("type", "text").put("text", turn.content))
    }

    private fun geminiContents(turns: List<ChatTurn>, imageB64: String?): JSONArray {
        val contents = JSONArray()
        for ((i, turn) in turns.withIndex()) {
            val parts = JSONArray()
            if (imageB64 != null && i == turns.lastIndex) {
                parts.put(JSONObject().put("inlineData", JSONObject()
                    .put("mimeType", "image/jpeg")
                    .put("data", imageB64)))
            }
            parts.put(JSONObject().put("text", turn.content))
            contents.put(geminiTurn(turn.role, parts))
        }
        return contents
    }

    private fun geminiTurn(role: String, parts: JSONArray): JSONObject =
        JSONObject()
            .put("role", if (role == "assistant") "model" else "user")
            .put("parts", parts)

    private fun geminiSystem(text: String): JSONObject =
        JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun geminiUrl(config: AiProviderConfig, action: String): String =
        config.baseUrl.trimEnd('/') + "/models/" + config.model + ":" + action

    private fun geminiParts(json: JSONObject): JSONArray =
        json.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()

    /** Gemini-র text part জোড়া দেয়; thinking part বাদ যায়। */
    private fun geminiText(parts: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.optBoolean("thought", false)) continue
            sb.append(part.optString("text"))
        }
        return sb.toString()
    }

    companion object {
        private const val MAX_TOOL_ROUNDS = 4

        private const val TOOL_RULES =
            "You can use tools: find a contact, send an SMS, read recent SMS. " +
                "Before sending an SMS, repeat the recipient and the exact text to the user and wait for a clear yes. " +
                "Only then call send_sms with confirmed=true. Never handle banking, OTP, passwords, PIN or payments."
    }
}
