package com.aiagent.assistant.core.voice

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/** Gemini Live-এ মাইক্রোফোন থেকে যায়: 16 kHz, 16-bit, mono PCM। */
const val LIVE_INPUT_RATE = 16_000

/** Gemini Live থেকে ফেরে: 24 kHz, 16-bit, mono PCM। */
const val LIVE_OUTPUT_RATE = 24_000

/** মাইক্রোফোন → ছোট ছোট PCM chunk (100 ms)। */
class PcmMicrophone(private val onChunk: (ByteArray) -> Unit) {

    @Volatile private var running = false
    private var record: AudioRecord? = null
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        if (running) return true
        val minBuf = AudioRecord.getMinBufferSize(
            LIVE_INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                LIVE_INPUT_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, CHUNK_BYTES * 4)
            )
        } catch (e: SecurityException) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        record = rec
        running = true
        rec.startRecording()
        thread = Thread({ readLoop(rec) }, "gemini-mic").apply { start() }
        return true
    }

    private fun readLoop(rec: AudioRecord) {
        val buffer = ByteArray(CHUNK_BYTES)
        while (running) {
            val n = rec.read(buffer, 0, buffer.size)
            if (n > 0) {
                onChunk(buffer.copyOf(n))
            } else if (n < 0) {
                break
            }
        }
    }

    fun stop() {
        running = false
        val rec = record
        if (rec != null) {
            runCatching { rec.stop() }
            thread?.join(500)
            runCatching { rec.release() }
        }
        record = null
        thread = null
    }

    companion object {
        const val CHUNK_BYTES = 3200
    }
}

/** Gemini-র audio chunk একটি queue থেকে speaker-এ চালায়। Interrupt হলে queue খালি। */
class PcmSpeaker {

    @Volatile private var running = false
    private var track: AudioTrack? = null
    private var thread: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>()

    fun start() {
        if (running) return
        val minBuf = AudioTrack.getMinBufferSize(
            LIVE_OUTPUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(LIVE_OUTPUT_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, LIVE_OUTPUT_RATE))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack.play()
        track = audioTrack
        running = true
        thread = Thread({ pump(audioTrack) }, "gemini-speaker").apply { start() }
    }

    fun play(pcm: ByteArray) {
        if (running) queue.offer(pcm)
    }

    /** User কথা বললে (interrupt) বাকি audio বাদ দাও। */
    fun clear() {
        queue.clear()
        val audioTrack = track ?: return
        runCatching {
            audioTrack.pause()
            audioTrack.flush()
            audioTrack.play()
        }
    }

    fun stop() {
        running = false
        queue.clear()
        val audioTrack = track
        track = null
        if (audioTrack != null) {
            runCatching { audioTrack.stop() }
            runCatching { audioTrack.release() }
        }
        thread = null
    }

    private fun pump(audioTrack: AudioTrack) {
        runCatching {
            while (running) {
                val chunk = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                var offset = 0
                while (offset < chunk.size && running) {
                    val written = audioTrack.write(chunk, offset, chunk.size - offset)
                    if (written <= 0) break
                    offset += written
                }
            }
        }
    }
}
