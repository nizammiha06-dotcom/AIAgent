package com.aiagent.assistant.core.voice

import android.util.Base64
import com.aiagent.assistant.core.sms.SmsTools
import com.aiagent.assistant.data.ai.AiProviderConfig
import com.aiagent.assistant.data.ai.SecureProviderStore
import com.aiagent.assistant.data.repository.ChatRepository
import com.aiagent.assistant.data.settings.AppSettings
import com.aiagent.assistant.data.settings.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gemini Live API (WebSocket)। সত্যিকারের live voice:
 * মাইক্রোফোন → 16 kHz PCM সরাসরি model-এ, model → 24 kHz PCM সরাসরি speaker-এ।
 * Model SMS/contact tool call করতে পারে; বাকি কথাবার্তা chat-এ সেভ হয়।
 */
@Singleton
class GeminiLiveSession @Inject constructor(
    private val http: OkHttpClient,
    private val providers: SecureProviderStore,
    private val settingsStore: SettingsStore,
    private val repo: ChatRepository,
    private val smsTools: SmsTools
) : VoiceBackend {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(VoiceUiState())
    override val state: StateFlow<VoiceUiState> = _state.asStateFlow()
    override var onFinished: ((String?) -> Unit)? = null

    @Volatile private var running = false
    @Volatile private var socket: WebSocket? = null
    @Volatile private var setupDone = false
    @Volatile private var pendingSetup = ""

    private var mic: PcmMicrophone? = null
    private var speaker: PcmSpeaker? = null
    private var inbox = Channel<String>(Channel.UNLIMITED)
    private var inboxJob: Job? = null
    private var setupTimer: Job? = null
    private var retries = 0
    private var chatId: String? = null
    private val userText = StringBuilder()
    private val assistantText = StringBuilder()

    override fun start() {
        if (running) return
        running = true
        retries = 0
        inbox = Channel(Channel.UNLIMITED)
        inboxJob = scope.launch {
            for (message in inbox) handle(message)
        }
        _state.value = VoiceUiState(phase = VoicePhase.THINKING, partial = "Gemini Live সংযোগ হচ্ছে…")
        scope.launch { connect() }
    }

    override fun stop() {
        if (!running) return
        running = false
        teardown()
        _state.value = VoiceUiState()
    }

    private suspend fun connect() {
        val apiKey = providers.getApiKey(AiProviderConfig.GEMINI_ID)
        if (apiKey.isNullOrBlank()) {
            fail("Gemini API key নেই। Settings → AI Providers-এ Gemini key দাও।", canRetry = false)
            return
        }
        pendingSetup = buildSetup(settingsStore.settings.first()).toString()
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"

        setupDone = false
        setupTimer?.cancel()
        setupTimer = scope.launch {
            delay(SETUP_TIMEOUT_MS)
            if (running && !setupDone) {
                // আলাদা job-এ চালাও, যাতে এই timer cancel হয়ে retry না আটকায়
                scope.launch { fail("Gemini Live সেটআপে সময় বেশি লাগছে", canRetry = true) }
            }
        }

        val client = http.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
        socket = client.newWebSocket(Request.Builder().url(url).build(), listener)
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            if (webSocket !== socket) return
            webSocket.send(pendingSetup)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            if (webSocket === socket) inbox.trySend(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            if (webSocket === socket) inbox.trySend(bytes.utf8())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (webSocket !== socket) return
            scope.launch { fail("Gemini Live বন্ধ হয়েছে (code $code)", canRetry = true) }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            if (webSocket !== socket) return
            val code = response?.code
            val retry = code == null || code >= 500 || code == 429
            val detail = if (code != null) "HTTP $code" else (t.message ?: "network")
            scope.launch { fail("Gemini Live সংযোগ ব্যর্থ ($detail)", canRetry = retry) }
        }
    }

    private suspend fun handle(raw: String) {
        val json = runCatching { JSONObject(raw) }.getOrNull() ?: return
        when {
            json.has("setupComplete") -> onSetupComplete()
            json.has("serverContent") -> onServerContent(json.optJSONObject("serverContent") ?: return)
            json.has("toolCall") -> onToolCall(json.optJSONObject("toolCall") ?: return)
            json.has("error") -> {
                val message = json.optJSONObject("error")?.optString("message").orEmpty()
                fail(message.ifBlank { "Gemini Live error" }, canRetry = false)
            }
        }
    }

    private suspend fun onSetupComplete() {
        setupDone = true
        setupTimer?.cancel()
        retries = 0
        sendHistory()
        if (!startAudio()) {
            fail("মাইক্রোফোন চালু করা যায়নি। RECORD_AUDIO অনুমতি দাও।", canRetry = false)
            return
        }
        _state.value = VoiceUiState(phase = VoicePhase.LISTENING, partial = "")
    }

    private fun startAudio(): Boolean {
        val out = speaker ?: PcmSpeaker().also { speaker = it }
        out.start()
        val input = mic ?: PcmMicrophone { chunk -> sendAudio(chunk) }.also { mic = it }
        return input.start()
    }

    private fun sendAudio(chunk: ByteArray) {
        if (!running || !setupDone) return
        val message = JSONObject().put(
            "realtimeInput",
            JSONObject().put(
                "audio",
                JSONObject()
                    .put("mimeType", "audio/pcm;rate=$LIVE_INPUT_RATE")
                    .put("data", Base64.encodeToString(chunk, Base64.NO_WRAP))
            )
        )
        socket?.send(message.toString())
    }

    /** আগের কথাবার্তা model-কে context হিসেবে দেয় (reconnect বা নতুন session-এ)। */
    private suspend fun sendHistory() {
        val id = chatId ?: return
        val turns = repo.history(id)
            .filter { !it.isError && it.content.isNotBlank() }
            .takeLast(HISTORY_TURNS)
        if (turns.isEmpty()) return
        val contents = JSONArray()
        for (turn in turns) {
            val role = if (turn.role == ChatRepository.ROLE_USER) "user" else "model"
            contents.put(
                JSONObject()
                    .put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", turn.content.take(600))))
            )
        }
        val message = JSONObject().put(
            "clientContent",
            JSONObject().put("turns", contents).put("turnComplete", false)
        )
        socket?.send(message.toString())
    }

    private suspend fun onServerContent(content: JSONObject) {
        if (content.optBoolean("interrupted", false)) {
            speaker?.clear()
        }

        val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val data = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data").orEmpty()
                if (data.isNotEmpty()) {
                    speaker?.play(Base64.decode(data, Base64.DEFAULT))
                    _state.update { it.copy(phase = VoicePhase.SPEAKING) }
                }
            }
        }

        val heard = content.optJSONObject("inputTranscription")?.optString("text").orEmpty()
        if (heard.isNotBlank()) {
            userText.append(heard)
            _state.update { it.copy(phase = VoicePhase.LISTENING, partial = userText.toString()) }
        }

        val spoken = content.optJSONObject("outputTranscription")?.optString("text").orEmpty()
        if (spoken.isNotBlank()) {
            assistantText.append(spoken)
            _state.update { it.copy(phase = VoicePhase.SPEAKING, lastReply = assistantText.toString()) }
        }

        if (content.optBoolean("turnComplete", false)) {
            saveTurn()
        }
    }

    private suspend fun saveTurn() {
        val user = userText.toString().trim()
        val assistant = assistantText.toString().trim()
        userText.clear()
        assistantText.clear()
        if (user.isNotEmpty() || assistant.isNotEmpty()) {
            val id = chatId ?: repo.createChat("Live voice").also { chatId = it }
            if (user.isNotEmpty()) repo.addMessage(id, ChatRepository.ROLE_USER, user)
            if (assistant.isNotEmpty()) repo.addMessage(id, ChatRepository.ROLE_ASSISTANT, assistant)
        }
        _state.update {
            it.copy(
                phase = VoicePhase.LISTENING,
                partial = "",
                lastReply = if (assistant.isEmpty()) it.lastReply else assistant
            )
        }
    }

    private suspend fun onToolCall(toolCall: JSONObject) {
        val calls = toolCall.optJSONArray("functionCalls") ?: return
        val responses = JSONArray()
        for (i in 0 until calls.length()) {
            val call = calls.optJSONObject(i) ?: continue
            val name = call.optString("name")
            val result = smsTools.execute(name, call.optJSONObject("args") ?: JSONObject())
            responses.put(
                JSONObject()
                    .put("id", call.optString("id"))
                    .put("name", name)
                    .put("response", result)
            )
        }
        if (responses.length() > 0) {
            val message = JSONObject().put(
                "toolResponse",
                JSONObject().put("functionResponses", responses)
            )
            socket?.send(message.toString())
        }
    }

    /** Retry সম্ভব হলে আবার সংযোগ; না হলে session বন্ধ করে facade-কে জানায়। */
    private suspend fun fail(message: String, canRetry: Boolean) {
        setupTimer?.cancel()
        if (!running) return
        if (canRetry && retries < MAX_RETRIES) {
            retries++
            stopAudio()
            val stale = socket
            socket = null
            stale?.cancel()
            _state.update {
                it.copy(
                    phase = VoicePhase.THINKING,
                    partial = "সংযোগ আবার চেষ্টা হচ্ছে ($retries/$MAX_RETRIES)…",
                    error = message
                )
            }
            delay(RETRY_DELAY_MS * retries)
            if (running) connect()
            return
        }
        teardown()
        running = false
        onFinished?.invoke(message)
    }

    private fun buildSetup(settings: AppSettings): JSONObject {
        val speech = JSONObject().put(
            "voiceConfig",
            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", settings.liveVoice))
        )
        val generation = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", speech)
        val setup = JSONObject()
            .put("model", "models/${AiProviderConfig.GEMINI_LIVE_MODEL}")
            .put("generationConfig", generation)
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", instruction(settings))))
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", smsTools.declarations())))
        return JSONObject().put("setup", setup)
    }

    private fun instruction(settings: AppSettings): String = """
        You are ${settings.assistantName}, a live voice assistant on the user's Android phone.
        Speak the language the user speaks (Bangla or English). Keep replies short and natural for speech.
        SMS: to send an SMS, get the recipient (use find_contact if only a name is given), read back the number and the exact text, and wait for a clear yes. Only then call send_sms with confirmed=true. Tell the user it was sent only when the tool returns ok=true.
        Never help with banking, OTP, passwords, PIN or payments, and never read out or send an OTP.
    """.trimIndent()

    private fun stopAudio() {
        mic?.stop()
        mic = null
        speaker?.stop()
        speaker = null
    }

    private fun teardown() {
        setupTimer?.cancel()
        setupTimer = null
        inboxJob?.cancel()
        inboxJob = null
        val stale = socket
        socket = null
        stale?.cancel()
        stopAudio()
    }

    companion object {
        private const val SETUP_TIMEOUT_MS = 15_000L
        private const val MAX_RETRIES = 3
        private const val RETRY_DELAY_MS = 1_500L
        private const val HISTORY_TURNS = 12
    }
}
