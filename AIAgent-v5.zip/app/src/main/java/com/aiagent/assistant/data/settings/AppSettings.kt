package com.aiagent.assistant.data.settings

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val appName: String = "AI Agent",
    val assistantName: String = "Aria",
    val wakeWord: String = "hey aria",
    val wakeWordEnabled: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val language: String = "bn",            // bn | en | system
    val voiceStyle: String = "female",      // male | female | child | robot | soft | deep | custom
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val confirmSensitiveActions: Boolean = true,
    val agentAutoExecute: Boolean = false,
    /** Gemini Live-এর কণ্ঠ: Kore, Aoede, Puck, Charon ইত্যাদি। */
    val liveVoice: String = "Kore",
    /** আসা SMS-এ AI নিজে উত্তর দেবে কিনা। */
    val smsAutoReply: Boolean = false
)
