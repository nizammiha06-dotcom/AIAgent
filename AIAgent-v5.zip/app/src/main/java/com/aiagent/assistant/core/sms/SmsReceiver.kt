package com.aiagent.assistant.core.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf

/** SMS এলে এখানে আসে। উত্তর তৈরি ও পাঠানো WorkManager-এ হয়, যাতে background-এ নির্ভরযোগ্য থাকে। */
class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return

        val bySender = LinkedHashMap<String, StringBuilder>()
        for (message in messages) {
            val from = message.originatingAddress ?: continue
            bySender.getOrPut(from) { StringBuilder() }.append(message.messageBody.orEmpty())
        }

        for ((from, body) in bySender) {
            val input = workDataOf(
                SmsAutoReplyWorker.KEY_FROM to from,
                SmsAutoReplyWorker.KEY_BODY to body.toString().take(1000)
            )
            val request = OneTimeWorkRequestBuilder<SmsAutoReplyWorker>()
                .setInputData(input)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
