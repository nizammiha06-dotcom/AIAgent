package com.aiagent.assistant.core.sms

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.provider.Telephony
import androidx.core.content.ContextCompat
import com.aiagent.assistant.data.ai.ToolBridge
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/** AI-এর হাতের tool: contact খোঁজা, SMS পাঠানো, সাম্প্রতিক SMS পড়া। */
@Singleton
class SmsTools @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sender: SmsSender
) : ToolBridge {

    override fun declarations(): JSONArray = JSONArray()
        .put(
            declaration(
                name = "find_contact",
                description = "Find phone numbers in the user's contacts by name (partial match allowed).",
                properties = JSONObject().put("name", prop("STRING", "Contact name to search")),
                required = listOf("name")
            )
        )
        .put(
            declaration(
                name = "send_sms",
                description = "Send an SMS text message. Call ONLY after the user explicitly confirmed the recipient number and the exact text. Set confirmed=true only then.",
                properties = JSONObject()
                    .put("to", prop("STRING", "Recipient phone number, with country code if known"))
                    .put("body", prop("STRING", "Exact SMS text"))
                    .put("confirmed", prop("BOOLEAN", "true only when the user explicitly confirmed")),
                required = listOf("to", "body", "confirmed")
            )
        )
        .put(
            declaration(
                name = "read_recent_sms",
                description = "Read the most recent received SMS messages.",
                properties = JSONObject().put("count", prop("INTEGER", "How many messages, 1 to 10")),
                required = listOf("count")
            )
        )

    override suspend fun execute(name: String, args: JSONObject): JSONObject =
        withContext(Dispatchers.IO) {
            try {
                when (name) {
                    "find_contact" -> findContact(args.optString("name"))
                    "send_sms" -> sendSms(args)
                    "read_recent_sms" -> readRecent(args.optInt("count", 5))
                    else -> failure("এই function নেই: $name")
                }
            } catch (e: Exception) {
                failure(e.message ?: "unknown error")
            }
        }

    private fun declaration(
        name: String,
        description: String,
        properties: JSONObject,
        required: List<String>
    ): JSONObject = JSONObject()
        .put("name", name)
        .put("description", description)
        .put(
            "parameters",
            JSONObject()
                .put("type", "OBJECT")
                .put("properties", properties)
                .put("required", JSONArray(required))
        )

    private fun prop(type: String, description: String): JSONObject =
        JSONObject().put("type", type).put("description", description)

    private fun failure(message: String): JSONObject =
        JSONObject().put("ok", false).put("error", message)

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun findContact(name: String): JSONObject {
        if (!granted(Manifest.permission.READ_CONTACTS)) return failure("Contacts অনুমতি নেই")
        val query = name.trim()
        if (query.isEmpty()) return failure("নাম দাও")
        val matches = JSONArray()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.Contacts.DISPLAY_NAME} LIKE ?",
            arrayOf("%$query%"),
            null
        )?.use { cursor ->
            while (cursor.moveToNext() && matches.length() < 5) {
                matches.put(
                    JSONObject()
                        .put("name", cursor.getString(0).orEmpty())
                        .put("number", cursor.getString(1).orEmpty())
                )
            }
        }
        return JSONObject().put("ok", true).put("matches", matches)
    }

    private fun sendSms(args: JSONObject): JSONObject {
        if (!args.optBoolean("confirmed", false)) {
            return failure("আগে user-এর স্পষ্ট সম্মতি নাও, তারপর confirmed=true দাও")
        }
        val to = args.optString("to").trim()
        val body = args.optString("body").trim()
        SmsPolicy.outgoingBlockReason(body)?.let { return failure(it) }
        if (!sender.hasPermission()) return failure("SMS পাঠানোর অনুমতি নেই (Permissions-এ SMS চালু করো)")
        return sender.send(to, body).fold(
            onSuccess = { JSONObject().put("ok", true).put("status", "sent_to_carrier").put("to", to) },
            onFailure = { failure(it.message ?: "SMS পাঠানো যায়নি") }
        )
    }

    private fun readRecent(count: Int): JSONObject {
        if (!granted(Manifest.permission.READ_SMS)) return failure("SMS পড়ার অনুমতি নেই")
        val limit = count.coerceIn(1, 10)
        val items = JSONArray()
        context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY),
            null,
            null,
            "${Telephony.Sms.DATE} DESC"
        )?.use { cursor ->
            while (cursor.moveToNext() && items.length() < limit) {
                items.put(
                    JSONObject()
                        .put("from", cursor.getString(0).orEmpty())
                        .put("text", cursor.getString(1).orEmpty().take(300))
                )
            }
        }
        return JSONObject().put("ok", true).put("messages", items)
    }
}
