package com.aiagent.assistant.data.ai

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AiRouter @Inject constructor(
    private val store: SecureProviderStore,
    private val client: AiClient
) {

    /**
     * Default provider → না হলে backup। আগের error-এ retry হয়; আংশিক stream হলে retry নয়।
     * [tools] দিলে Gemini provider function calling ব্যবহার করে (SMS ইত্যাদি)।
     */
    suspend fun stream(
        messages: List<ChatTurn>,
        onDelta: suspend (String) -> Unit,
        onRestart: suspend () -> Unit,
        tools: ToolBridge? = null
    ): Result<String> {
        val all = store.getProviders().associateBy { it.id }
        val candidates = listOfNotNull(store.defaultId(), store.backupId())
            .distinct()
            .mapNotNull { id -> all[id]?.takeIf { it.enabled } }

        if (candidates.isEmpty()) {
            return Result.failure(
                AiException(-1, "কোনো AI provider সেট করা নেই। Settings → AI Providers-এ যাও।")
            )
        }

        var lastError: Exception? = null
        for ((index, config) in candidates.withIndex()) {
            val key = store.getApiKey(config.id)
            if (config.requiresKey && key.isNullOrBlank()) {
                lastError = AiException(-1, "${config.name}: API key নেই")
                continue
            }
            try {
                val text = AiRetry.withRetry {
                    onRestart()
                    if (tools != null && config.protocol == Protocol.GEMINI) {
                        val full = client.generateWithTools(config, key, messages, tools)
                        onDelta(full)
                        full
                    } else {
                        client.stream(config, key, messages, onDelta)
                    }
                }
                return Result.success(text)
            } catch (e: Exception) {
                lastError = e
                if (index < candidates.lastIndex) onRestart()
            }
        }
        return Result.failure(lastError ?: AiException(-1, "Unknown error"))
    }

    suspend fun describeImage(prompt: String, jpeg: ByteArray): String {
        val all = store.getProviders().associateBy { it.id }
        val candidates = listOfNotNull(store.defaultId(), store.backupId())
            .distinct()
            .mapNotNull { id -> all[id]?.takeIf { it.enabled && it.supportsVision } }

        if (candidates.isEmpty()) {
            return "এই কাজের জন্য vision-সক্ষম provider (Gemini, Anthropic বা OpenAI) সেট করা নেই।"
        }
        var lastError: Exception? = null
        for (config in candidates) {
            val key = store.getApiKey(config.id)
            try {
                return AiRetry.withRetry { client.describeImage(config, key, prompt, jpeg) }
            } catch (e: Exception) {
                lastError = e
            }
        }
        return "উত্তর আনা যায়নি: ${lastError?.message}"
    }
}
