package com.aiagent.assistant.core.sms

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import com.aiagent.assistant.data.repository.ChatRepository
import com.aiagent.assistant.data.settings.SettingsStore
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.first

/** Worker-এর ভেতরে Hilt dependency পেতে ব্যবহৃত entry point। */
@EntryPoint
@InstallIn(SingletonComponent::class)
interface SmsWorkerEntryPoint {
    fun aiRouter(): AiRouter
    fun smsSender(): SmsSender
    fun settingsStore(): SettingsStore
    fun chatRepository(): ChatRepository
}

/** আসা SMS-এর ছোট AI উত্তর তৈরি করে পাঠায়। Auto reply চালু থাকলেই কাজ করে। */
class SmsAutoReplyWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val from = inputData.getString(KEY_FROM).orEmpty()
        val body = inputData.getString(KEY_BODY).orEmpty()
        if (from.isBlank() || body.isBlank()) return Result.success()

        val deps = EntryPointAccessors.fromApplication(applicationContext, SmsWorkerEntryPoint::class.java)
        if (!deps.settingsStore().settings.first().smsAutoReply) return Result.success()
        if (SmsPolicy.autoReplyBlockReason(from, body) != null) return Result.success()
        if (!SmsPolicy.reserveReply(applicationContext, from)) return Result.success()

        val prompt = """
            An SMS arrived on the phone owner's phone from $from:
            "$body"
            Write ONE short reply to send back on the owner's behalf: at most 2 short sentences, in the same language as the incoming SMS.
            Be polite. Do not share personal, banking, OTP or password information. Do not promise money, meetings or commitments.
            Output only the reply text.
        """.trimIndent()

        val reply = deps.aiRouter()
            .stream(listOf(ChatTurn("user", prompt)), onDelta = {}, onRestart = {})
            .getOrNull()
            ?.trim()
            ?.take(300)
        if (reply.isNullOrBlank()) return Result.success()

        val sent = deps.smsSender().send(from, reply)
        runCatching { logToChat(deps.chatRepository(), from, body, reply, sent.isSuccess) }
        return Result.success()
    }

    /** সব auto reply একটি "SMS log" chat-এ দেখায়, যাতে user জানে কী পাঠানো হলো। */
    private suspend fun logToChat(
        repo: ChatRepository,
        from: String,
        incoming: String,
        reply: String,
        delivered: Boolean
    ) {
        val prefs = applicationContext.getSharedPreferences(SmsPolicy.PREFS, Context.MODE_PRIVATE)
        val id = prefs.getString(KEY_LOG_CHAT, null) ?: repo.createChat("SMS log").also {
            prefs.edit().putString(KEY_LOG_CHAT, it).apply()
        }
        repo.addMessage(id, ChatRepository.ROLE_USER, "📩 $from: $incoming")
        val line = if (delivered) "↩️ উত্তর পাঠানো হয়েছে: $reply" else "⚠️ উত্তর পাঠানো যায়নি: $reply"
        repo.addMessage(id, ChatRepository.ROLE_ASSISTANT, line, isError = !delivered)
    }

    companion object {
        const val KEY_FROM = "from"
        const val KEY_BODY = "body"
        private const val KEY_LOG_CHAT = "log_chat_id"
    }
}
