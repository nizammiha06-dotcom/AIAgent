# AI Agent — GitHub দিয়ে APK বানানো

এই repository-তে একটি zip ফাইল (`AIAgent-github.zip`) এবং একটি workflow ফাইল আছে।
GitHub Actions zip খুলে project বানায় এবং debug APK তৈরি করে।

## ধাপ
1. **Actions** tab → Android Debug Build → **Run workflow** চাপো।
2. শেষ হলে run-এ ক্লিক করে নিচে **Artifacts** থেকে `app-debug` ডাউনলোড করো।
3. zip খুলে `app-debug.apk` ফোনে install করো।

Build fail করলে run-এর লাল step-এর error কপি করে পাঠাও।
