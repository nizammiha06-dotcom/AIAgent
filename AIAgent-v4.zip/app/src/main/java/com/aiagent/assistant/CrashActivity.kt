package com.aiagent.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity

class CrashActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent?.getStringExtra(EXTRA_TRACE) ?: "কোনো error তথ্য পাওয়া যায়নি"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        val title = TextView(this).apply {
            text = "অ্যাপে সমস্যা হয়েছে। নিচের লেখাটি কপি করে পাঠাও।"
            textSize = 18f
        }
        val copy = Button(this).apply {
            text = "কপি করো"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", trace))
            }
        }
        val body = TextView(this).apply {
            text = trace
            textSize = 11f
            setTextIsSelectable(true)
        }
        root.addView(title)
        root.addView(copy)
        root.addView(
            ScrollView(this).apply { addView(body, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
    }

    companion object {
        const val EXTRA_TRACE = "trace"
    }
}
