package com.aiagent.assistant

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import com.aiagent.assistant.core.notification.NotificationReplyController
import com.aiagent.assistant.core.notification.ReplyReceiver
import com.aiagent.assistant.data.settings.AppSettings
import com.aiagent.assistant.data.settings.OnboardingStore
import com.aiagent.assistant.data.settings.SettingsStore
import com.aiagent.assistant.data.settings.ThemeMode
import com.aiagent.assistant.presentation.navigation.AppNavHost
import com.aiagent.assistant.presentation.navigation.Screen
import com.aiagent.assistant.presentation.reply.ReplyConfirmDialog
import com.aiagent.assistant.ui.theme.AIAgentTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject lateinit var settingsStore: SettingsStore
    @Inject lateinit var onboardingStore: OnboardingStore
    @Inject lateinit var replyController: dagger.Lazy<NotificationReplyController>

    // null = এখনো পড়া হয়নি; তখন splash দেখাবে
    private val _onboardingDone = MutableStateFlow<Boolean?>(null)
    private val onboardingDone: StateFlow<Boolean?> = _onboardingDone.asStateFlow()

    // Notification reply dialog-এর key (ReplyReceiver থেকে আসে)
    private val replyKeyState = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        replyKeyState.value = intent?.getStringExtra(ReplyReceiver.EXTRA_REPLY_KEY)
        splash.setKeepOnScreenCondition { _onboardingDone.value == null }

        lifecycleScope.launch {
            onboardingStore.completed.collect { _onboardingDone.value = it }
        }

        setContent {
            val settings by settingsStore.settings.collectAsState(initial = AppSettings())
            val done by onboardingDone.collectAsState()
            val replyKey by replyKeyState

            val darkTheme = when (settings.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            AIAgentTheme(darkTheme = darkTheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val isReady = done
                    if (isReady != null) {
                        val navController = rememberNavController()
                        AppNavHost(
                            navController = navController,
                            startDestination = if (isReady) Screen.Home.route else Screen.Onboarding.route
                        )
                    }
                    replyKey?.let { key ->
                        ReplyConfirmDialog(key = key, controller = replyController.get()) { replyKeyState.value = null }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        replyKeyState.value = intent.getStringExtra(ReplyReceiver.EXTRA_REPLY_KEY)
    }
}
