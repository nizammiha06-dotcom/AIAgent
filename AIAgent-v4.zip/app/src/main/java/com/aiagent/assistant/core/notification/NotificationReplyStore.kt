package com.aiagent.assistant.core.notification

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.os.Bundle
import android.service.notification.StatusBarNotification
import javax.inject.Inject
import javax.inject.Singleton
import android.content.Intent

/** Notification-এর reply action মনে রাখে, যাতে পরে AI উত্তর পাঠানো যায়। */
@Singleton
class NotificationReplyStore @Inject constructor() {

    data class ReplyTarget(
        val key: String,
        val packageName: String,
        val sender: String,
        val text: String,
        val action: Notification.Action,
        val remoteInput: RemoteInput
    )

    private val targets = LinkedHashMap<String, ReplyTarget>()

    @Synchronized
    fun remember(sbn: StatusBarNotification): ReplyTarget? {
        val notif = sbn.notification ?: return null
        val actions = notif.actions ?: return null
        val replyAction = actions.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true } ?: return null
        val input = replyAction.remoteInputs.first()
        val extras = notif.extras
        val target = ReplyTarget(
            key = sbn.key,
            packageName = sbn.packageName,
            sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(),
            text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty(),
            action = replyAction,
            remoteInput = input
        )
        targets[sbn.key] = target
        if (targets.size > 50) targets.remove(targets.keys.first())
        return target
    }

    @Synchronized
    fun get(key: String): ReplyTarget? = targets[key]

    /** Reply পাঠায়। সফল হলে true। */
    fun sendReply(context: Context, key: String, text: String): Boolean {
        val t = get(key) ?: return false
        return try {
            val bundle = Bundle().apply { putCharSequence(t.remoteInput.resultKey, text) }
            val intent = android.content.Intent()
            RemoteInput.addResultsToIntent(arrayOf(t.remoteInput), intent, bundle)
            t.action.actionIntent.send(context, 0, intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
