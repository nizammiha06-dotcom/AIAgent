package com.aiagent.assistant.presentation.chat

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.planner.AgentPlanner
import com.aiagent.assistant.core.planner.TaskExecutionEngine
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import com.aiagent.assistant.data.local.ChatEntity
import com.aiagent.assistant.data.local.MessageEntity
import com.aiagent.assistant.data.repository.ChatRepository
import com.aiagent.assistant.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject
import kotlinx.coroutines.withContext

data class ChatUiState(
    val chatId: String? = null,
    val title: String = "",
    val pinned: Boolean = false,
    val messages: List<MessageEntity> = emptyList(),
    val input: String = "",
    val isSending: Boolean = false
)

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val repo: ChatRepository,
    private val tasks: TaskRepository,
    private val router: AiRouter,
    private val planner: AgentPlanner,
    private val executor: TaskExecutionEngine,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val chatId = MutableStateFlow<String?>(savedStateHandle.get<String>("chatId"))
    private val input = MutableStateFlow("")
    private val sending = MutableStateFlow(false)
    private var replyJob: Job? = null

    private val content = chatId.flatMapLatest { id ->
        if (id == null) {
            flowOf(Pair<ChatEntity?, List<MessageEntity>>(null, emptyList()))
        } else {
            combine(repo.observeChat(id), repo.observeMessages(id)) { chat, msgs -> chat to msgs }
        }
    }

    val state: StateFlow<ChatUiState> = combine(chatId, content, input, sending) { id, (chat, msgs), inp, snd ->
        ChatUiState(
            chatId = id,
            title = chat?.title.orEmpty(),
            pinned = chat?.pinned ?: false,
            messages = msgs,
            input = inp,
            isSending = snd
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ChatUiState())

    fun onInputChange(value: String) { input.value = value }

    fun send() {
        val text = input.value.trim()
        if (text.isEmpty() || sending.value) return
        input.value = ""

        replyJob = viewModelScope.launch {
            sending.value = true
            try {
                val id = chatId.value
                    ?: repo.createChat(text.take(40)).also { chatId.value = it }
                repo.addMessage(id, ChatRepository.ROLE_USER, text)

                if (isTaskRequest(text)) handleTask(id, text) else handleChat(id)
            } finally {
                sending.value = false
                replyJob = null
            }
        }
    }

    /** চলমান AI উত্তর থামায়। আংশিক উত্তর রেখে দেয় এবং "থামানো হয়েছে" চিহ্ন দেয়। */
    fun stop() {
        replyJob?.cancel()
        replyJob = null
        sending.value = false
    }

    private fun isTaskRequest(text: String): Boolean {
        val t = text.lowercase()
        return TASK_HINTS.any { t.contains(it) }
    }

    private suspend fun handleTask(chatId: String, goal: String) {
        repo.addMessage(chatId, ChatRepository.ROLE_ASSISTANT, "🧭 পরিকল্পনা তৈরি হচ্ছে…")
        planner.plan(goal)
            .onSuccess { plan ->
                val summary = buildString {
                    appendLine("📋 **${plan.goal}**")
                    appendLine()
                    plan.steps.forEach { s ->
                        appendLine("${s.index + 1}. ${s.title}" + if (s.needsConfirmation) " ⚠️" else "")
                    }
                    appendLine()
                    appendLine("Tasks স্ক্রিনে গিয়ে Run চাপো। (Accessibility চালু থাকতে হবে)")
                }
                repo.addMessage(chatId, ChatRepository.ROLE_ASSISTANT, summary)
                tasks.savePlan(plan)
                executor.start(plan)
            }
            .onFailure { e ->
                repo.addMessage(
                    chatId, ChatRepository.ROLE_ASSISTANT,
                    "⚠️ পরিকল্পনা ব্যর্থ: ${e.message}", isError = true
                )
            }
    }

    private suspend fun handleChat(chatId: String) {
        val turns = repo.history(chatId)
            .filter { !it.isError && it.content.isNotBlank() }
            .takeLast(MAX_HISTORY)
            .map { ChatTurn(it.role, it.content) }

        val draftId = UUID.randomUUID().toString()
        val createdAt = System.currentTimeMillis()
        val buffer = StringBuilder()
        var lastSave = 0L

        repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT, "", createdAt, false)

        try {
            router.stream(
                messages = turns,
                onDelta = { chunk ->
                    buffer.append(chunk)
                    val now = System.currentTimeMillis()
                    if (now - lastSave >= SAVE_INTERVAL_MS) {
                        lastSave = now
                        repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT,
                            buffer.toString(), createdAt, false)
                    }
                },
                onRestart = {
                    buffer.clear()
                    repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT, "", createdAt, false)
                }
            ).onSuccess {
                repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT,
                    buffer.toString().ifBlank { "(খালি উত্তর এসেছে)" }, createdAt, false)
            }.onFailure { e ->
                repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT,
                    "⚠️ উত্তর আনা যায়নি: ${e.message}", createdAt, true)
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            // Stop চাপলে আংশিক উত্তর সেভ রেখে চিহ্ন দেওয়া হয়
            val partial = buffer.toString()
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                repo.saveMessage(draftId, chatId, ChatRepository.ROLE_ASSISTANT,
                    if (partial.isBlank()) "⏹ থামানো হয়েছে" else "$partial\n\n⏹ থামানো হয়েছে",
                    createdAt, false)
            }
            throw e
        }
    }

    fun rename(title: String) {
        viewModelScope.launch { chatId.value?.let { repo.rename(it, title) } }
    }

    fun togglePin() {
        viewModelScope.launch {
            val id = chatId.value ?: return@launch
            repo.setPinned(id, !state.value.pinned)
        }
    }

    fun delete(onDone: () -> Unit) {
        viewModelScope.launch {
            chatId.value?.let { repo.delete(it) }
            onDone()
        }
    }

    fun export(onReady: (String) -> Unit) {
        viewModelScope.launch {
            chatId.value?.let { onReady(repo.exportAsText(it)) }
        }
    }

    companion object {
        private const val MAX_HISTORY = 30
        private const val SAVE_INTERVAL_MS = 300L
        private val TASK_HINTS = listOf(
            "খোলো", "যাও", "করো", "download", "open", "search", "খুঁজ", "click", "ক্লিক", "scroll"
        )
    }
}
