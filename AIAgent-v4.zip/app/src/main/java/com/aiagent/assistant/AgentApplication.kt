package com.aiagent.assistant

import android.app.Application
import android.content.Intent
import android.os.Process
import dagger.hilt.android.HiltAndroidApp
import kotlin.system.exitProcess

@HiltAndroidApp
class AgentApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        installCrashScreen()
    }

    /** Crash হলে error লেখাটি CrashActivity-তে দেখাবে, যাতে কপি করে পাঠানো যায়। */
    private fun installCrashScreen() {
        Thread.setDefaultUncaughtExceptionHandler { _, error ->
            try {
                val intent = Intent(this, CrashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    .putExtra(CrashActivity.EXTRA_TRACE, error.stackTraceToString())
                startActivity(intent)
            } catch (ignored: Throwable) {
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }
}
