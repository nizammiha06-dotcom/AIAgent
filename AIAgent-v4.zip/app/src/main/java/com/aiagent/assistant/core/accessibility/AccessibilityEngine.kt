package com.aiagent.assistant.core.accessibility

import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton
import com.aiagent.assistant.core.planner.AppLauncher
import kotlinx.coroutines.launch

/** একটি action। Planner এই model তৈরি করে। */
sealed interface AgentAction {
    data class Click(val target: String) : AgentAction
    data class LongPress(val target: String) : AgentAction
    data class Type(val target: String, val text: String) : AgentAction
    data class Scroll(val forward: Boolean = true) : AgentAction
    data object Back : AgentAction
    data object Home : AgentAction
    data class Wait(val millis: Long) : AgentAction
    data class Verify(val expectedText: String) : AgentAction
    data class OpenApp(val packageName: String) : AgentAction
}

data class StepOutcome(val action: AgentAction, val ok: Boolean, val message: String)

@Singleton
class AccessibilityEngine @Inject constructor(
    private val reader: ScreenReader,
    private val finder: ElementFinder,
    private val actions: AccessibilityActions,
    private val memory: ScreenContextMemory,
    private val launcher: AppLauncher
) {
    private val service: AgentAccessibilityServiceRef?
        get() = AgentAccessibilityService.instance?.let { AgentAccessibilityServiceRef(it) }

    val isReady: Boolean get() = service != null

    /** একটি app foreground-এ এসেছে কিনা অপেক্ষা করে দেখে। */
    private suspend fun waitForPackage(packages: List<String>, timeoutMs: Long = 12_000L): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            val pkg = currentSnapshot()?.packageName
            if (pkg != null && packages.contains(pkg)) return true
            delay(500)
            waited += 500
        }
        return false
    }

    fun currentSnapshot(): ScreenSnapshot? {
        val s = service ?: return null
        val snap = reader.snapshot(s.raw) ?: return null
        memory.push(snap)
        return snap
    }

    fun previousSnapshot(): ScreenSnapshot? = memory.previous()

    suspend fun execute(action: AgentAction, maxRetries: Int = 2): StepOutcome {
        val svc = service ?: return StepOutcome(action, false, "Accessibility service চালু নেই")

        // OpenApp-এর আগে snapshot লাগে না, কারণ তখন অন্য app-এ থাকা স্বাভাবিক
        if (action !is AgentAction.OpenApp) {
            val snap = currentSnapshot()
            if (snap != null) {
                SafetyGuard.blockReason(snap.packageName)?.let {
                    return StepOutcome(action, false, it)
                }
            }
        }

        var last = StepOutcome(action, false, "Unknown")
        repeat(maxRetries + 1) { attempt ->
            last = runOnce(svc.raw, action)
            if (last.ok) return last
            delay(400L * (attempt + 1))
        }
        return last
    }

    private suspend fun runOnce(
        svc: android.accessibilityservice.AccessibilityService,
        action: AgentAction
    ): StepOutcome {
        if (action is AgentAction.OpenApp) {
            if (!launcher.launch(action.packageName)) {
                return StepOutcome(action, false, "${action.packageName} খোলা যায়নি (installed নেই?)")
            }
            val arrived = waitForPackage(listOf(action.packageName))
            return if (arrived) StepOutcome(action, true, "সফল")
            else StepOutcome(action, false, "${action.packageName} foreground-এ আসেনি")
        }

        val snap = currentSnapshot()
        val result: ActionResult = when (action) {
            is AgentAction.Click -> {
                val el = snap?.let { finder.find(it, action.target, onlyClickable = true) }
                    ?: return StepOutcome(action, false, "'${action.target}' খুঁজে পাওয়া যায়নি")
                actions.clickElement(svc, el)
            }
            is AgentAction.LongPress -> {
                val el = snap?.let { finder.find(it, action.target) }
                    ?: return StepOutcome(action, false, "'${action.target}' খুঁজে পাওয়া যায়নি")
                actions.longPressElement(svc, el)
            }
            is AgentAction.Type -> {
                val el = snap?.let { finder.find(it, action.target, onlyClickable = true) }
                    ?: return StepOutcome(action, false, "Field '${action.target}' পাওয়া যায়নি")
                actions.typeInto(svc, el, action.text)
            }
            is AgentAction.Scroll -> actions.scroll(svc, action.forward)
            AgentAction.Back -> actions.back(svc)
            AgentAction.Home -> actions.home(svc)
            is AgentAction.Wait -> {
                delay(action.millis)
                ActionResult.Ok
            }
            is AgentAction.Verify -> {
                val found = snap?.let { finder.find(it, action.expectedText) } != null
                if (found) ActionResult.Ok
                else ActionResult.Failed("'${action.expectedText}' এখনো দেখা যাচ্ছে না")
            }
            is AgentAction.OpenApp -> ActionResult.Ok // উপরে handled
        }
        return when (result) {
            ActionResult.Ok -> {
                if (action !is AgentAction.Wait && action !is AgentAction.Verify) delay(500)
                StepOutcome(action, true, "সফল")
            }
            is ActionResult.Failed -> StepOutcome(action, false, result.reason)
        }
    }

    data class AgentAccessibilityServiceRef(val raw: android.accessibilityservice.AccessibilityService)
}
