package com.aiagent.assistant.core.bubble

import android.content.Context
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.material3.Button

/** Bubble tap করলে খোলে। Compose না, কারণ overlay-তে Compose-এর lifecycle সমস্যা করে। */
class QuickPanelView(
    context: Context,
    private val onVoice: () -> Unit,
    private val onNewChat: () -> Unit,
    private val onOpenApp: () -> Unit,
    private val onClose: () -> Unit
) : LinearLayout(context) {

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(0xEE14141F.toInt())

        addView(TextView(context).apply {
            text = "AI Agent"
            textSize = 16f
            setTextColor(0xFFEDEDF5.toInt())
            gravity = Gravity.CENTER
        })
        addButton("🎙 Live voice", onVoice)
        addButton("💬 নতুন chat", onNewChat)
        addButton("📱 অ্যাপ খোলো", onOpenApp)
        addButton("✖ বন্ধ", onClose)
    }

    private fun addButton(label: String, action: () -> Unit) {
        addView(Button(context).apply {
            text = label
            setOnClickListener { action() }
        })
    }
}
