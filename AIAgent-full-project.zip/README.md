# AI Agent — সম্পূর্ণ Project (Step 1 থেকে 17d)

এই zip-এ আগের chat-এ লেখা সব code একটি Android project হিসেবে সাজানো আছে।
প্রতিটি ফাইল chat-এর শেষ সংস্করণ থেকে নেওয়া, এবং পরের step-এর পরিবর্তনগুলো (snippet) যথাস্থানে বসানো হয়েছে।

## Project তৈরি ও Build (Android Studio)
1. Android Studio → New Project → **Empty Activity (Compose)**
   - Name: `AIAgent` · Package: `com.aiagent.assistant` · minSdk: `26` · Kotlin DSL
2. এই zip-এর সব ফাইল ও ফোল্ডার project folder-এ copy করো (overwrite করো)।
   Android Studio-র `gradlew` ও `gradle/wrapper/gradle-wrapper.jar` রেখে দাও।
3. File → Sync Project with Gradle Files → Build → Rebuild Project → Run ▶

## GitHub দিয়ে APK
1. GitHub-এ private repository বানাও এবং এই project push করো। `.gitignore` কী-ফাইল (`*.jks`) বাদ দেবে।
2. Actions tab → **Android Build** → Run workflow।
3. শেষ হলে Artifacts থেকে `app-debug` নামাও।

## Release signing (ঐচ্ছিক)
Environment variable বা `gradle.properties`-এ দাও: `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`।
Git-এ এই মানগুলো বা keystore commit করবে না।

## জানা বিষয় (build না হলে এখানে দেখো)
- এই environment-এ Android SDK নেই, তাই এখনো compile করে দেখা হয়নি। প্রথম build-এর error log পাঠালে ঠিক করে দেওয়া হবে।
- মূল chat-এ যে bug ধরা পড়েছিল, সেগুলো ঠিক করা হয়েছে: AppSwitchWaiter-এর circular dependency (AccessibilityEngine-এ inline), MainActivity-র onboarding collect, ChatViewModel-এর stop-এর সময় আংশিক উত্তর সেভ (NonCancellable)।
- Launcher icon: `mipmap-anydpi-v26/ic_launcher.xml` ও `ic_launcher_round.xml` ব্যবহার হচ্ছে। Android Studio-র পুরোনো `mipmap-*` PNG থাকলে থাকুক, সমস্যা নেই।
