# Accessibility ও Notification service Android framework থেকে reflectively চালু হয়
-keep class com.aiagent.assistant.core.accessibility.AgentAccessibilityService { *; }
-keep class com.aiagent.assistant.core.notification.AgentNotificationListener { *; }

# Room ও Hilt নিজেদের consumer rules সরবরাহ করে; এখানে অতিরিক্ত rule লাগে না।
# Release build-এ crash হলে logcat-এ class নাম দেখে এখানে -keep যোগ করো।
