package com.aiagent.assistant.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatEntity::class,
        MessageEntity::class,
        TaskPlanEntity::class,
        TaskStepEntity::class,
        AutomationEntity::class,
        CustomSkillEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun taskDao(): TaskDao
    abstract fun automationDao(): AutomationDao
    abstract fun customSkillDao(): CustomSkillDao
}
