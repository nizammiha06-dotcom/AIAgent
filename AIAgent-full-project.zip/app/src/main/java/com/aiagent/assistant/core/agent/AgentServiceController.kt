package com.aiagent.assistant.core.agent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Agent চালু/বন্ধ নিয়ন্ত্রণ। Wake word toggle-এর সাথে যুক্ত। */
object AgentServiceController {

    private const val PREFS = "agent_runtime"
    private const val KEY_ENABLED = "enabled"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, enabled).apply()
        if (enabled) start(context) else stop(context)
    }

    fun start(context: Context) {
        val hasMic = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasMic) return

        // Background থেকে mic service চালু না হলে crash না করে চুপচাপ থামবে
        runCatching {
            ContextCompat.startForegroundService(
                context,
                Intent(context, AgentService::class.java)
            )
        }
    }

    fun stop(context: Context) {
        context.stopService(Intent(context, AgentService::class.java))
    }
}
