package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CapCutSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.lemon.lvoverseas", "com.lemon.lv")
    override val displayName = "CapCut"

    override val screens = listOf(
        KnownScreen(
            id = "cc_home",
            nameEn = "Home / projects",
            nameBn = "হোম / প্রজেক্ট",
            identifyingTexts = listOf("New project", "Create project", "Drafts")
        ),
        KnownScreen(
            id = "cc_media_picker",
            nameEn = "Media picker",
            nameBn = "মিডিয়া বাছাই",
            identifyingTexts = listOf("Next", "Videos", "Photos")
        ),
        KnownScreen(
            id = "cc_editor",
            nameEn = "Editor timeline",
            nameBn = "এডিটর টাইমলাইন",
            identifyingTexts = listOf("Export", "Add", "Timeline")
        ),
        KnownScreen(
            id = "cc_export",
            nameEn = "Export dialog",
            nameBn = "এক্সপোর্ট",
            identifyingTexts = listOf("Resolution", "Frame rate", "Save to")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "new_project",
            descriptionEn = "Start a new project",
            descriptionBn = "নতুন প্রজেক্ট শুরু",
            targetHints = listOf("New project", "+")
        ),
        SkillAction(
            id = "import_media",
            descriptionEn = "Select a video from the gallery and confirm",
            descriptionBn = "Gallery থেকে ভিডিও বেছে Next",
            targetHints = listOf("Next", "Add")
        ),
        SkillAction(
            id = "add_text",
            descriptionEn = "Add a text overlay on the timeline",
            descriptionBn = "টাইমলাইনে text যোগ",
            targetHints = listOf("Text", "Add text")
        ),
        SkillAction(
            id = "export_hd",
            descriptionEn = "Open export and choose HD resolution (1080p)",
            descriptionBn = "Export খুলে HD (1080p) বেছে নেওয়া",
            targetHints = listOf("Export", "1080", "HD"),
            requiresConfirmation = true
        )
    )

    override val requiresLogin = false
}
