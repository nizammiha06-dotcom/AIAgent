package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MapsSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.google.android.apps.maps")
    override val displayName = "Maps"

    override val screens = listOf(
        KnownScreen(
            id = "maps_home",
            nameEn = "Map home",
            nameBn = "ম্যাপ",
            identifyingTexts = listOf("Search here", "Search Google Maps")
        ),
        KnownScreen(
            id = "maps_place",
            nameEn = "Place details",
            nameBn = "স্থানের বিবরণ",
            identifyingTexts = listOf("Directions", "Start", "Save")
        ),
        KnownScreen(
            id = "maps_navigation",
            nameEn = "Navigation",
            nameBn = "নেভিগেশন",
            identifyingTexts = listOf("Start", "Exit navigation", "ETA")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "search_place",
            descriptionEn = "Type a place name in the search bar",
            descriptionBn = "Search bar-এ জায়গার নাম লেখা",
            targetHints = listOf("Search Google Maps", "Search here")
        ),
        SkillAction(
            id = "start_directions",
            descriptionEn = "Tap Directions to get the route",
            descriptionBn = "রাস্তা পেতে Directions চাপা",
            targetHints = listOf("Directions")
        ),
        SkillAction(
            id = "start_navigation",
            descriptionEn = "Tap Start to begin turn-by-turn navigation",
            descriptionBn = "নেভিগেশন শুরু করতে Start চাপা",
            targetHints = listOf("Start")
        )
    )
}
