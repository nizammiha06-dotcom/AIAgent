package com.aiagent.assistant.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface AutomationDao {

    @Query("SELECT * FROM automations ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<AutomationEntity>>

    @Query("SELECT * FROM automations WHERE enabled = 1")
    suspend fun enabledOnce(): List<AutomationEntity>

    @Query("SELECT * FROM automations WHERE id = :id")
    suspend fun byId(id: String): AutomationEntity?

    @Upsert
    suspend fun upsert(item: AutomationEntity)

    @Query("UPDATE automations SET enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)

    @Query("UPDATE automations SET lastRunAt = :time WHERE id = :id")
    suspend fun markRun(id: String, time: Long)

    @Query("DELETE FROM automations WHERE id = :id")
    suspend fun delete(id: String)
}
