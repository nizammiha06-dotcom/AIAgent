package com.aiagent.assistant.core.planner

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** Sensitive step-এর আগে UI থেকে user-এর সিদ্ধান্ত নেয়। */
@Singleton
class ConfirmationGate @Inject constructor() {

    data class Request(val planId: String, val stepIndex: Int, val title: String)

    private val _pending = MutableStateFlow<Request?>(null)
    val pending: StateFlow<Request?> = _pending.asStateFlow()

    private var deferred: CompletableDeferred<Boolean>? = null

    /** User হ্যাঁ বললে true। অন্য কোনো confirmation চলমান থাকলে সেটি বাতিল হয়। */
    suspend fun ask(planId: String, stepIndex: Int, title: String): Boolean {
        deferred?.complete(false)
        val d = CompletableDeferred<Boolean>()
        deferred = d
        _pending.value = Request(planId, stepIndex, title)
        return try {
            d.await()
        } finally {
            _pending.value = null
            deferred = null
        }
    }

    fun answer(allow: Boolean) {
        deferred?.complete(allow)
    }
}
