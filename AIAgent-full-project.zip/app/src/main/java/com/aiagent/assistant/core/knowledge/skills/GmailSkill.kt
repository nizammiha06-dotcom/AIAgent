package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GmailSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.google.android.gm")
    override val displayName = "Gmail"

    override val requiresLogin = true

    override val screens = listOf(
        KnownScreen(
            id = "gm_inbox",
            nameEn = "Inbox",
            nameBn = "ইনবক্স",
            identifyingTexts = listOf("Primary", "Promotions", "Social")
        ),
        KnownScreen(
            id = "gm_compose",
            nameEn = "Compose",
            nameBn = "নতুন ইমেইল",
            identifyingTexts = listOf("To", "Subject", "Send")
        ),
        KnownScreen(
            id = "gm_search",
            nameEn = "Search",
            nameBn = "সার্চ",
            identifyingTexts = listOf("Search in mail")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "compose",
            descriptionEn = "Tap the compose button to start a new email",
            descriptionBn = "Compose বাটনে চেপে নতুন ইমেইল শুরু",
            targetHints = listOf("Compose")
        ),
        SkillAction(
            id = "fill_recipient",
            descriptionEn = "Type the recipient address into the To field",
            descriptionBn = "To field-এ প্রাপকের ঠিকানা লেখা",
            targetHints = listOf("To")
        ),
        SkillAction(
            id = "fill_subject",
            descriptionEn = "Type the subject line",
            descriptionBn = "Subject লেখা",
            targetHints = listOf("Subject")
        ),
        SkillAction(
            id = "send_email",
            descriptionEn = "Tap Send to deliver the email",
            descriptionBn = "ইমেইল পাঠাতে Send চাপা",
            targetHints = listOf("Send"),
            requiresConfirmation = true
        )
    )
}
