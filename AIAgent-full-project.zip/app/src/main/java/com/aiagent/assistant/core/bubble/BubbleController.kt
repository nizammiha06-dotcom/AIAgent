package com.aiagent.assistant.core.bubble

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import javax.inject.Inject
import javax.inject.Singleton

/** Floating bubble চালু/বন্ধ। Overlay অনুমতি না থাকলে কিছু করে না। */
@Singleton
class BubbleController @Inject constructor() {

    fun canShow(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun show(context: Context) {
        if (!canShow(context)) return
        runCatching {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingBubbleService::class.java)
            )
        }
    }

    fun hide(context: Context) {
        context.stopService(Intent(context, FloatingBubbleService::class.java))
    }
}
