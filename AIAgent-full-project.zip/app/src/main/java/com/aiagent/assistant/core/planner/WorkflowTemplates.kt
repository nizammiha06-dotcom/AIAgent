package com.aiagent.assistant.core.planner

import com.aiagent.assistant.core.accessibility.AgentAction

object WorkflowTemplates {

    val CHROME_TO_CAPCUT = listOf(
        PlanStep(
            index = 0,
            title = "Chrome খোলো",
            app = "Chrome",
            actions = listOf(AgentAction.Wait(800)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 1,
            title = "Download link-এ ট্যাপ করো",
            app = "Chrome",
            actions = listOf(AgentAction.Click("Download")),
            needsConfirmation = true
        ),
        PlanStep(
            index = 2,
            title = "Download শেষ হওয়া পর্যন্ত অপেক্ষা",
            app = "Chrome",
            actions = listOf(AgentAction.Wait(8_000)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 3,
            title = "CapCut খোলো",
            app = "CapCut",
            actions = listOf(AgentAction.Wait(800)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 4,
            title = "নতুন প্রজেক্ট শুরু করো",
            app = "CapCut",
            actions = listOf(AgentAction.Click("New project")),
            needsConfirmation = false
        ),
        PlanStep(
            index = 5,
            title = "ডাউনলোড করা ভিডিও বেছে Next",
            app = "CapCut",
            actions = listOf(AgentAction.Click("Next")),
            needsConfirmation = false
        )
    )

    /** YouTube → Download → Gallery: download শেষে ভিডিও Gallery-তে খুঁজে দেখা। */
    val YOUTUBE_TO_GALLERY = listOf(
        PlanStep(
            index = 0,
            title = "YouTube খোলো",
            app = "YouTube",
            actions = listOf(AgentAction.Wait(800)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 1,
            title = "Search বাটনে ট্যাপ করো",
            app = "YouTube",
            actions = listOf(AgentAction.Click("Search")),
            needsConfirmation = false
        ),
        PlanStep(
            index = 2,
            title = "ভিডিও খুঁজে প্রথম ফলাফল খোলো",
            app = "YouTube",
            actions = listOf(AgentAction.Wait(1_500)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 3,
            title = "Download বাটনে ট্যাপ করো",
            app = "YouTube",
            actions = listOf(AgentAction.Click("Download")),
            needsConfirmation = true
        ),
        PlanStep(
            index = 4,
            title = "Download শেষ হওয়া পর্যন্ত অপেক্ষা",
            app = "YouTube",
            actions = listOf(AgentAction.Wait(8_000)),
            needsConfirmation = false
        ),
        PlanStep(
            index = 5,
            title = "Gallery খোলো এবং Download album দেখো",
            app = "Gallery",
            actions = listOf(
                AgentAction.Wait(800),
                AgentAction.Click("Download")
            ),
            needsConfirmation = false
        )
    )

    fun findFor(goal: String): List<PlanStep>? {
        val g = goal.lowercase()
        return when {
            g.contains("capcut") && (g.contains("chrome") || g.contains("download")) -> CHROME_TO_CAPCUT
            g.contains("youtube") && g.contains("gallery") -> YOUTUBE_TO_GALLERY
            else -> null
        }
    }
}
