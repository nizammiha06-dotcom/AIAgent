package com.aiagent.assistant.presentation.home

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AppDrawerContent(
    onOpenChat: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenSettings: () -> Unit
) {
    ModalDrawerSheet {
        Text(
            text = "AI Agent",
            style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(start = 28.dp, top = 24.dp, bottom = 16.dp)
        )
        NavigationDrawerItem(
            label = { Text("Chat") },
            selected = false,
            onClick = onOpenChat,
            icon = { Icon(Icons.Filled.Chat, null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            label = { Text("Permissions") },
            selected = false,
            onClick = onOpenPermissions,
            icon = { Icon(Icons.Filled.Security, null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            label = { Text("Automations") },
            selected = false,
            onClick = onOpenAutomations,
            icon = { Icon(Icons.Filled.Build, null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            label = { Text("Tasks") },
            selected = false,
            onClick = onOpenTasks,
            icon = { Icon(Icons.Filled.Build, null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            label = { Text("Settings") },
            selected = false,
            onClick = onOpenSettings,
            icon = { Icon(Icons.Filled.Settings, null) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
    }
}
