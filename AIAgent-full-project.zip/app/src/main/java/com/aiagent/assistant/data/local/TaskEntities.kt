package com.aiagent.assistant.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "task_plans")
data class TaskPlanEntity(
    @PrimaryKey val id: String,
    val goal: String,
    val status: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Entity(
    tableName = "task_steps",
    foreignKeys = [
        ForeignKey(
            entity = TaskPlanEntity::class,
            parentColumns = ["id"],
            childColumns = ["planId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("planId")]
)
data class TaskStepEntity(
    @PrimaryKey val id: String,
    val planId: String,
    val stepIndex: Int,
    val title: String,
    val app: String?,
    val status: String,
    val message: String
)
