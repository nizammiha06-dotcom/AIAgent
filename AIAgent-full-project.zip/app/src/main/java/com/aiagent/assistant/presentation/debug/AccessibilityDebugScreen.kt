package com.aiagent.assistant.presentation.debug

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.theme.Spacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccessibilityDebugScreen(
    onBack: () -> Unit,
    viewModel: AccessibilityDebugViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Screen Debug") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            item {
                Text(
                    text = if (state.ready) "Accessibility সক্রিয়"
                    else "Accessibility চালু নেই। Permissions থেকে চালু করো।",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            item {
                Button(onClick = viewModel::refresh, modifier = Modifier.fillMaxWidth()) {
                    Text("Snapshot নাও")
                }
            }
            item {
                OutlinedButton(
                    onClick = { viewModel.analyze("এই screen-এ কী কী আছে? সংক্ষেপে বলো।") },
                    enabled = !state.analyzing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (state.analyzing) "বিশ্লেষণ চলছে…" else "Screen analyze করো (AI)")
                }
            }
            if (state.analysis.isNotBlank()) {
                item {
                    AppCard {
                        Text(
                            text = state.analysis,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(Spacing.md)
                        )
                    }
                }
            }

            val snap = state.snapshot
            if (snap != null) {
                item {
                    Text(
                        text = "App: ${snap.packageName} · ${snap.elements.size} elements",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                items(snap.elements) { e ->
                    AppCard {
                        Column(Modifier.padding(Spacing.sm)) {
                            Text(
                                text = "[${e.index}] ${e.label.ifBlank { "(no label)" }}",
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                text = "${e.className.substringAfterLast('.')} · " +
                                    "click=${e.clickable} edit=${e.editable} scroll=${e.scrollable}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}
