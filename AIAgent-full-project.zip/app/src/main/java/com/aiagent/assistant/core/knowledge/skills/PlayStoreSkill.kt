package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PlayStoreSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.android.vending")
    override val displayName = "Play Store"

    override val screens = listOf(
        KnownScreen(
            id = "ps_home",
            nameEn = "Store home",
            nameBn = "স্টোর হোম",
            identifyingTexts = listOf("Search Google Play", "For you", "Games")
        ),
        KnownScreen(
            id = "ps_app_page",
            nameEn = "App page",
            nameBn = "অ্যাপের পাতা",
            identifyingTexts = listOf("Install", "Uninstall", "Open")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "search_app",
            descriptionEn = "Type an app name in the search bar",
            descriptionBn = "Search bar-এ অ্যাপের নাম লেখা",
            targetHints = listOf("Search Google Play")
        ),
        SkillAction(
            id = "install_app",
            descriptionEn = "Tap Install on the app page",
            descriptionBn = "অ্যাপের পাতায় Install চাপা",
            targetHints = listOf("Install"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "open_app",
            descriptionEn = "Tap Open after installation",
            descriptionBn = "ইনস্টলের পরে Open চাপা",
            targetHints = listOf("Open")
        )
    )
}
