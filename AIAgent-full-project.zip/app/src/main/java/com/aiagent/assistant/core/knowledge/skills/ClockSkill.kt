package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ClockSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.deskclock",
        "com.sec.android.app.clockpackage",
        "com.android.deskclock"
    )
    override val displayName = "Clock"

    override val screens = listOf(
        KnownScreen(
            id = "clk_alarm",
            nameEn = "Alarm list",
            nameBn = "অ্যালার্ম তালিকা",
            identifyingTexts = listOf("Alarm", "Alarms", "Next alarm")
        ),
        KnownScreen(
            id = "clk_timer",
            nameEn = "Timer",
            nameBn = "টাইমার",
            identifyingTexts = listOf("Timer", "Start", "Reset")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "new_alarm",
            descriptionEn = "Tap plus to add a new alarm, then set the time",
            descriptionBn = "+ চাপে নতুন অ্যালার্ম, তারপর সময় সেট",
            targetHints = listOf("Add alarm", "+")
        ),
        SkillAction(
            id = "start_timer",
            descriptionEn = "Tap Start on the timer tab",
            descriptionBn = "টাইমার ট্যাবে Start চাপা",
            targetHints = listOf("Start")
        )
    )

    // Alarm ও timer সাধারণত নিজস্ব API (`alarm_create_v0`, `timer_create_v0`) দিয়ে সহজ, তাই UI fallback মাত্র।
}
