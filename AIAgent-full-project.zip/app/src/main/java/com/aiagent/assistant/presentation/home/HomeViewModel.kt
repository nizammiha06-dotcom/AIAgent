package com.aiagent.assistant.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.voice.LiveVoiceSession
import com.aiagent.assistant.core.voice.VoicePhase
import com.aiagent.assistant.data.repository.ChatRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

data class RecentChat(val id: String, val title: String, val preview: String)

data class HomeUiState(
    val assistantName: String = "AI Agent",
    val isListening: Boolean = false,
    val recentChats: List<RecentChat> = emptyList()
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    repo: ChatRepository,
    private val live: LiveVoiceSession
) : ViewModel() {

    private val formatter = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())

    val state: StateFlow<HomeUiState> = combine(
        repo.observeChats().map { chats ->
            chats.take(10).map {
                RecentChat(
                    id = it.id,
                    title = it.title,
                    preview = "Updated ${formatter.format(Date(it.updatedAt))}"
                )
            }
        },
        live.state
    ) { recent, voice ->
        HomeUiState(
            isListening = voice.phase == VoicePhase.LISTENING ||
                voice.phase == VoicePhase.THINKING ||
                voice.phase == VoicePhase.SPEAKING,
            recentChats = recent
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun toggleListening() {
        if (live.isActive) live.stop() else live.start()
    }
}
