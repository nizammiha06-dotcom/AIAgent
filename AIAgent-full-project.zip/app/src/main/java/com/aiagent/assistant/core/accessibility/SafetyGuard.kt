package com.aiagent.assistant.core.accessibility

/**
 * নিরাপত্তা নীতি: banking, payment, security ও OTP-related screen-এ কোনো action নয়।
 * Password/OTP field দেখলেও সেখানে type করা হবে না।
 */
object SafetyGuard {

    private val blockedPackages = setOf(
        // Banking ও payment (প্যাকেজের নামের অংশ ধরে মিলানো হয়)
        "bkash", "nagad", "rocket", "upay", "dbbl", "bank", "banking",
        "paypal", "wallet", "payment", "pay.", "stripe",
        // Authenticator ও security
        "authenticator", "otp", "securekey", "bitwarden", "1password", "lastpass", "keepass"
    )

    private val sensitiveTextHints = listOf(
        "otp", "one-time", "password", "passcode", "pin", "cvv", "card number",
        "পাসওয়ার্ড", "পিন", "ওটিপি"
    )

    /** এই package-এ কাজ করা নিরাপদ কিনা। */
    fun isPackageAllowed(packageName: String): Boolean {
        val lower = packageName.lowercase()
        return blockedPackages.none { lower.contains(it) }
    }

    /** Element-এ type করা নিরাপদ কিনা। Password ও OTP field-এ কখনো না। */
    fun isFieldSafe(element: UiElement): Boolean {
        if (!element.editable) return false
        val hint = (element.label + " " + element.viewId).lowercase()
        return sensitiveTextHints.none { hint.contains(it) }
    }

    fun blockReason(packageName: String): String? =
        if (!isPackageAllowed(packageName))
            "এই অ্যাপে (ব্যাংকিং/পেমেন্ট/নিরাপত্তা) কাজ করা নিষেধ।"
        else null
}
