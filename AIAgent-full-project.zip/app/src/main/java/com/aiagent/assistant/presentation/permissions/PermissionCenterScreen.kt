package com.aiagent.assistant.presentation.permissions

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.aiagent.assistant.core.permissions.PermissionId
import com.aiagent.assistant.core.permissions.PermissionIntents
import com.aiagent.assistant.core.permissions.PermissionKind
import com.aiagent.assistant.ui.theme.SuccessGreen
import com.aiagent.assistant.ui.theme.WarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionCenterScreen(
    onBack: () -> Unit,
    viewModel: PermissionViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val states by viewModel.state.collectAsState()
    var enableAllRunning by remember { mutableStateOf(false) }

    // Runtime permission launcher (একাধিক permission একসাথে)
    val runtimeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        viewModel.refresh()
        if (enableAllRunning) {
            enableAllRunning = false
            viewModel.startEnableAll()?.let { PermissionIntents.open(context, it) }
        }
    }

    // Settings থেকে ফিরে এলে পরের special permission খোলা
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.onResumed()?.let { PermissionIntents.open(context, it) }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val intent = android.content.Intent(context, com.aiagent.assistant.core.vision.ScreenCaptureService::class.java)
                .setAction(com.aiagent.assistant.core.vision.ScreenCaptureService.ACTION_START)
                .putExtra(com.aiagent.assistant.core.vision.ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(com.aiagent.assistant.core.vision.ScreenCaptureService.EXTRA_DATA, result.data)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
            viewModel.refresh()
        }
    }
    fun onEnable(id: PermissionId) {
        if (id.kind == PermissionKind.PROJECTION) {
            val mgr = context.getSystemService(android.media.projection.MediaProjectionManager::class.java)
            projectionLauncher.launch(mgr.createScreenCaptureIntent())
            return
        }
        if (id.kind == PermissionKind.RUNTIME) {
            val perms = viewModel.runtimePermissions(id)
            if (perms.isEmpty()) viewModel.refresh()
            else runtimeLauncher.launch(perms.toTypedArray())
        } else {
            PermissionIntents.open(context, id)
        }
    }

    fun onEnableAll() {
        val missing = viewModel.missingRuntimePermissions()
        if (missing.isNotEmpty()) {
            enableAllRunning = true
            runtimeLauncher.launch(missing.toTypedArray())
        } else {
            viewModel.startEnableAll()?.let { PermissionIntents.open(context, it) }
        }
    }

    val criticalIds = PermissionId.entries.filter { it.critical }
    val otherSpecial = PermissionId.entries.filter { it.kind == PermissionKind.SPECIAL && !it.critical }
    val runtimeIds = PermissionId.entries.filter { it.kind == PermissionKind.RUNTIME }
    val grantedTotal = states.count { it.value }
    val criticalGranted = criticalIds.count { states[it] == true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permissions · অনুমতি") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = { onEnableAll() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text("Enable All Required Permissions · সব জরুরি অনুমতি চালু করো")
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SummaryCard(
                    criticalGranted = criticalGranted,
                    criticalTotal = criticalIds.size,
                    granted = grantedTotal,
                    total = states.size
                )
            }

            item { SectionTitle("⚡ Full Agent Mode-এর জন্য জরুরি · Critical") }
            items(criticalIds, key = { it.name }) { id ->
                PermissionCard(
                    id = id,
                    granted = states[id] == true,
                    onEnable = { onEnable(id) },
                    onRetry = { if (id.kind == PermissionKind.RUNTIME) onEnable(id) else viewModel.refresh() },
                    onOpenSettings = { PermissionIntents.open(context, id) }
                )
            }

            item { SectionTitle("Other special permissions · অন্যান্য বিশেষ অনুমতি") }
            items(otherSpecial, key = { it.name }) { id ->
                PermissionCard(
                    id = id,
                    granted = states[id] == true,
                    onEnable = { onEnable(id) },
                    onRetry = { viewModel.refresh() },
                    onOpenSettings = { PermissionIntents.open(context, id) }
                )
            }

            item { SectionTitle("Runtime permissions · সাধারণ অনুমতি") }
            items(runtimeIds, key = { it.name }) { id ->
                PermissionCard(
                    id = id,
                    granted = states[id] == true,
                    onEnable = { onEnable(id) },
                    onRetry = { onEnable(id) },
                    onOpenSettings = { PermissionIntents.open(context, id) }
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(
    criticalGranted: Int,
    criticalTotal: Int,
    granted: Int,
    total: Int
) {
    val fraction = if (criticalTotal == 0) 0f else criticalGranted.toFloat() / criticalTotal
    val allReady = criticalGranted == criticalTotal

    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.large) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = if (allReady) "Full Agent Mode প্রস্তুত · Ready"
                else "Full Agent Mode এখনো পুরোপুরি চালু নয়",
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = "Critical: $criticalGranted/$criticalTotal · মোট: $granted/$total",
                style = MaterialTheme.typography.bodyMedium
            )
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
private fun PermissionCard(
    id: PermissionId,
    granted: Boolean,
    onEnable: () -> Unit,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        border = if (id.critical) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(if (isBanglaUi()) id.titleBn else id.titleEn, style = MaterialTheme.typography.titleMedium)
                    Text(
                        id.titleBn,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusChip(granted)
            }

            Text(if (isBanglaUi()) id.reasonBn else id.reasonEn, style = MaterialTheme.typography.bodyMedium)
            Text(
                id.reasonEn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!granted) {
                    Button(onClick = onEnable) { Text("Enable · চালু") }
                }
                OutlinedButton(onClick = onRetry) { Text("Retry") }
                TextButton(onClick = onOpenSettings) { Text("Open Settings") }
            }
        }
    }
}

@Composable
private fun StatusChip(granted: Boolean) {
    val color = if (granted) SuccessGreen else WarningOrange
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.15f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = if (granted) "Granted" else "Not granted",
                style = MaterialTheme.typography.labelLarge,
                color = color
            )
        }
    }
}

@Composable
private fun isBanglaUi(): Boolean {
    val locale = androidx.compose.ui.platform.LocalConfiguration.current.locales[0]
    return locale.language == "bn"
}
