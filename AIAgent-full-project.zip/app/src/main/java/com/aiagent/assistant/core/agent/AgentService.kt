package com.aiagent.assistant.core.agent

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.aiagent.assistant.core.automation.AutomationRunner
import com.aiagent.assistant.core.voice.LiveVoiceSession
import com.aiagent.assistant.core.voice.SpeechInput
import com.aiagent.assistant.core.voice.VoicePhase
import com.aiagent.assistant.data.settings.SettingsStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AgentService : Service() {

    @Inject lateinit var live: LiveVoiceSession
    @Inject lateinit var settings: SettingsStore
    @Inject lateinit var runner: AutomationRunner

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wake: SpeechInput? = null
    private var wakeWord: String = "hey aria"
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AgentNotifications.ensureChannel(this)
        live.onStopped = { startWakeListening() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!started) {
            started = true
            ServiceCompat.startForeground(
                this,
                AgentNotifications.NOTIFICATION_ID,
                AgentNotifications.build(this, "Standby"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
            scope.launch {
                wakeWord = settings.settings.first().wakeWord
                startWakeListening()
            }
            scope.launch {
                live.state.collect { s ->
                    AgentNotifications.update(this@AgentService, phaseText(s.phase))
                }
            }
        }
        return START_STICKY
    }

    private val wakeListener = object : SpeechInput.Listener {
        override fun onPartial(text: String) { detect(text) }

        override fun onFinal(text: String) {
            // Wake word না থাকলে সাধারণ voice text-কে VOICE automation হিসেবে যাচাই করো
            if (!detect(text)) {
                runner.onVoiceText(text)
                startWakeListening()
            }
        }

        override fun onError(code: Int) {
            if (code == SpeechRecognizer.ERROR_NO_MATCH ||
                code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            ) {
                startWakeListening()
            } else {
                scope.launch {
                    delay(2_000)
                    startWakeListening()
                }
            }
        }

        private fun detect(text: String): Boolean {
            if (text.isNotBlank() && text.contains(wakeWord, ignoreCase = true)) {
                wake?.cancel()
                live.start()
                return true
            }
            return false
        }
    }

    private fun startWakeListening() {
        if (live.isActive) return
        val s = wake ?: SpeechInput(this).also {
            wake = it
            it.listener = wakeListener
        }
        s.start("en-US")
    }

    private fun phaseText(phase: VoicePhase): String = when (phase) {
        VoicePhase.IDLE -> "Say \"$wakeWord\" to start"
        VoicePhase.LISTENING -> "Listening…"
        VoicePhase.THINKING -> "Thinking…"
        VoicePhase.SPEAKING -> "Speaking…"
        VoicePhase.ERROR -> "Error · app খুলে দেখো"
    }

    override fun onDestroy() {
        live.onStopped = null
        wake?.release()
        wake = null
        live.stop()
        scope.cancel()
        started = false
        super.onDestroy()
    }
}
