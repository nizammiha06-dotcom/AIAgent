package com.aiagent.assistant.core.knowledge

import com.aiagent.assistant.data.repository.CustomSkillRepository
import javax.inject.Inject
import javax.inject.Singleton

/** Built-in ও custom, সব skill-এর registry। Custom skill প্রতিবার DB থেকে পড়া হয়। */
@Singleton
class AppKnowledgeBase @Inject constructor(
    private val builtIn: Set<@JvmSuppressWildcards AppSkill>,
    private val custom: CustomSkillRepository
) {
    suspend fun all(): List<AppSkill> =
        builtIn.toList() + custom.allOnce().map { CustomSkillAdapter.toAppSkill(it) }

    /** Package name দিয়ে খোঁজে। Built-in আগে, তারপর custom। */
    suspend fun skillFor(packageName: String): AppSkill? =
        all().firstOrNull { packageName in it.packageNames }

    suspend fun skillByName(name: String): AppSkill? =
        all().firstOrNull { it.displayName.equals(name, ignoreCase = true) }

    suspend fun overviewForPrompt(): String =
        all().joinToString("\n\n") { it.promptHints() }
}
