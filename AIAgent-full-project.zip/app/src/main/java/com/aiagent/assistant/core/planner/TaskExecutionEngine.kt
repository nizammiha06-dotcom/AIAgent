package com.aiagent.assistant.core.planner

import com.aiagent.assistant.core.accessibility.AccessibilityEngine
import com.aiagent.assistant.core.accessibility.AgentAction
import com.aiagent.assistant.data.repository.TaskRepository
import com.aiagent.assistant.data.settings.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Plan চালায়। প্রতিটি step-এর আগে যদি `app` থাকে তবে সেই app-এ যায়।
 * Cross-app flow এখানে নিজে থেকে সামলানো হয়।
 */
@Singleton
class TaskExecutionEngine @Inject constructor(
    private val engine: AccessibilityEngine,
    private val gate: ConfirmationGate,
    private val repo: TaskRepository,
    private val settings: SettingsStore,
    private val knowledge: com.aiagent.assistant.core.knowledge.AppKnowledgeBase
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private val _current = MutableStateFlow<TaskPlan?>(null)
    val current: StateFlow<TaskPlan?> = _current.asStateFlow()

    val isRunning: Boolean get() = job?.isActive == true

    fun start(plan: TaskPlan) {
        if (isRunning) return
        job = scope.launch {
            val confirmAll = settings.settings.first().confirmSensitiveActions
            var running = plan.copy(status = PlanStatus.RUNNING)
            _current.value = running
            repo.savePlan(running)

            for (step in plan.steps) {
                if (!isRunning) break
                running = update(running, step.index) { it.copy(status = StepStatus.RUNNING) }

                if (step.needsConfirmation && confirmAll) {
                    val ok = gate.ask(plan.id, step.index, step.title)
                    if (!ok) {
                        running = update(running, step.index) {
                            it.copy(status = StepStatus.SKIPPED, message = "User বাতিল করেছে")
                        }
                        continue
                    }
                }

                val outcome = runStep(step)
                running = update(running, step.index) {
                    it.copy(
                        status = if (outcome.first) StepStatus.DONE else StepStatus.FAILED,
                        message = outcome.second
                    )
                }
                if (!outcome.first) {
                    running = running.copy(status = PlanStatus.FAILED)
                    break
                }
            }

            if (running.status == PlanStatus.RUNNING) {
                running = running.copy(status = PlanStatus.DONE)
            }
            _current.value = running
            repo.savePlan(running)
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        _current.value?.let { p ->
            val cancelled = p.copy(status = PlanStatus.CANCELLED)
            _current.value = cancelled
            scope.launch { repo.savePlan(cancelled) }
        }
    }

    /** Step-এর app বদলাতে হলে আগে সেই app খোলে, তারপর action চালায়। */
    private suspend fun runStep(step: PlanStep): Pair<Boolean, String> {
        val pkg = step.app?.let { knowledge.skillByName(it)?.packageNames?.firstOrNull() }

        if (pkg != null) {
            val open = engine.execute(AgentAction.OpenApp(pkg))
            if (!open.ok) return false to open.message
        }

        for (action in step.actions) {
            if (!isRunning) return false to "বাতিল হয়েছে"
            val result = engine.execute(action)
            if (!result.ok) return false to result.message
        }
        return true to "সফল"
    }

    private fun update(plan: TaskPlan, index: Int, transform: (PlanStep) -> PlanStep): TaskPlan {
        val steps = plan.steps.map { if (it.index == index) transform(it) else it }
        return plan.copy(steps = steps).also { _current.value = it }
    }
}
