package com.aiagent.assistant.presentation.tasks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.core.planner.PlanStatus
import com.aiagent.assistant.core.planner.StepStatus
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.theme.Spacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(
    onBack: () -> Unit,
    viewModel: TasksViewModel = hiltViewModel()
) {
    val plans by viewModel.plans.collectAsState()
    val current by viewModel.current.collectAsState()
    val pending by viewModel.pending.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Tasks · কাজ") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            current?.let { plan ->
                item {
                    AppCard {
                        Column(Modifier.padding(Spacing.md)) {
                            Text("চলমান কাজ · ${plan.goal}", style = MaterialTheme.typography.titleMedium)
                            Text("অবস্থা: ${plan.status.name}", style = MaterialTheme.typography.bodySmall)
                            plan.steps.forEach { s ->
                                Text(
                                    "${s.index + 1}. ${s.title} — ${s.status.label()}" +
                                        if (s.message.isNotBlank()) " (${s.message})" else "",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            if (plan.status == PlanStatus.RUNNING) {
                                TextButton(onClick = viewModel::cancel) { Text("Cancel · বাতিল") }
                            }
                        }
                    }
                }
            }

            item { Text("সব কাজ", style = MaterialTheme.typography.titleSmall) }

            items(plans, key = { it.id }) { p ->
                AppCard {
                    Column(Modifier.padding(Spacing.md)) {
                        Text(p.goal, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "অবস্থা: ${p.status}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                            TextButton(onClick = { viewModel.delete(p.id) }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    pending?.let { req ->
        AlertDialog(
            onDismissRequest = { viewModel.allow(false) },
            title = { Text("নিশ্চিত করো") },
            text = { Text("ধাপ ${req.stepIndex + 1}: ${req.title}\n\nএটি চালাতে চাও?") },
            confirmButton = {
                Button(onClick = { viewModel.allow(true) }) { Text("হ্যাঁ, চালাও") }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.allow(false) }) { Text("না") }
            }
        )
    }
}

private fun StepStatus.label(): String = when (this) {
    StepStatus.PENDING -> "অপেক্ষায়"
    StepStatus.RUNNING -> "চলছে"
    StepStatus.DONE -> "✅ সম্পন্ন"
    StepStatus.FAILED -> "❌ ব্যর্থ"
    StepStatus.SKIPPED -> "⏭ বাদ"
}
