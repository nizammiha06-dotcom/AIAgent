package com.aiagent.assistant.core.planner

import com.aiagent.assistant.core.accessibility.AccessibilityEngine
import com.aiagent.assistant.core.knowledge.AppKnowledgeBase
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentPlanner @Inject constructor(
    private val router: AiRouter,
    private val parser: PlanParser,
    private val knowledge: AppKnowledgeBase,
    private val engine: AccessibilityEngine
) {

    suspend fun plan(goal: String): Result<TaskPlan> {
        // Template থাকলে AI-কে না ডেকেই সরাসরি ব্যবহার হবে
        WorkflowTemplates.findFor(goal)?.let { steps ->
            return Result.success(TaskPlan(id = java.util.UUID.randomUUID().toString(), goal = goal, steps = steps))
        }

        val screen = engine.currentSnapshot()?.toPromptText(maxElements = 80) ?: "(screen তথ্য নেই)"
        val messages = listOf(ChatTurn("user", buildPrompt(goal, screen)))

        val raw = router.stream(messages, onDelta = {}, onRestart = {})
            .getOrElse { return Result.failure(it) }

        val plan = parser.parse(goal, raw)
            ?: return Result.failure(IllegalStateException("AI plan বুঝতে পারেনি। আবার চেষ্টা করো।"))
        return Result.success(plan)
    }

    private fun buildPrompt(goal: String, screen: String): String = """
        You are an Android automation planner. Break the user's goal into small steps.
        Reply with ONLY a JSON object, no explanation.

        Schema:
        {"steps":[{"title":"...","app":"AppName or null","needsConfirmation":false,
          "actions":[{"type":"click|long_press|type|scroll|back|home|wait|verify|open_app",
                      "target":"visible label","text":"for type","forward":true,
                      "millis":1000,"expected":"text to verify","package":"com.example.app"}]}]}

        Rules:
        - To switch to another app, put its name in "app" on the step; the engine opens it first.
        - Use only visible labels from the current screen or known app skills as targets.
        - Mark download, export, call, SMS, delete, payment steps needsConfirmation=true.
        - Never plan actions in banking, payment, OTP or password screens.
        - Keep steps under 12 actions total.

        Known app skills:
        ${knowledge.overviewForPrompt()}

        Current screen:
        $screen

        User goal: $goal
    """.trimIndent()
}
