package com.aiagent.assistant.core.agent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.aiagent.assistant.core.automation.AutomationScheduler
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var scheduler: AutomationScheduler

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // Time automation আবার schedule (boot-এর পরে alarm মুছে যায়)
        scheduler.rescheduleAll()
        if (AgentServiceController.isEnabled(context)) {
            AgentServiceController.start(context)
        }
    }
}
