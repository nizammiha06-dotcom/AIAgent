package com.aiagent.assistant.presentation.reply

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.aiagent.assistant.core.notification.NotificationReplyController

@Composable
fun ReplyConfirmDialog(key: String, controller: NotificationReplyController, onDone: () -> Unit) {
    var draftText by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(key) {
        controller.createDraft(key)
            .onSuccess { draftText = it.reply }
            .onFailure { error = it.message }
    }

    AlertDialog(
        onDismissRequest = { controller.discard(key); onDone() },
        title = { Text("AI reply") },
        text = {
            Text(draftText ?: error ?: "Draft তৈরি হচ্ছে…")
        },
        confirmButton = {
            TextButton(
                enabled = draftText != null,
                onClick = {
                    controller.confirmSend(key)
                    onDone()
                }
            ) { Text("পাঠাও") }
        },
        dismissButton = {
            TextButton(onClick = { controller.discard(key); onDone() }) { Text("বাতিল") }
        }
    )
}

