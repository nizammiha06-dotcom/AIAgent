package com.aiagent.assistant.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import javax.inject.Inject
import javax.inject.Singleton

/** AccessibilityNodeInfo tree থেকে সমতল ScreenSnapshot তৈরি করে। */
@Singleton
class ScreenReader @Inject constructor() {

    fun snapshot(service: AccessibilityService): ScreenSnapshot? {
        val root = service.rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString().orEmpty()
        val elements = mutableListOf<UiElement>()
        try {
            collect(root, depth = 0, out = elements)
        } finally {
            recycleSafely(root)
        }
        return ScreenSnapshot(
            packageName = pkg,
            capturedAt = System.currentTimeMillis(),
            elements = elements.mapIndexed { i, e -> e.copy(index = i) }
        )
    }

    private fun collect(node: AccessibilityNodeInfo, depth: Int, out: MutableList<UiElement>) {
        if (node.isVisibleToUser) {
            val rect = Rect().also { node.getBoundsInScreen(it) }
            val text = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            val isInteresting = text.isNotBlank() || desc.isNotBlank() ||
                node.isClickable || node.isEditable || node.isScrollable
            if (isInteresting && !rect.isEmpty) {
                out += UiElement(
                    index = -1,
                    className = node.className?.toString().orEmpty(),
                    text = text,
                    description = desc,
                    viewId = node.viewIdResourceName.orEmpty(),
                    clickable = node.isClickable,
                    longClickable = node.isLongClickable,
                    editable = node.isEditable,
                    scrollable = node.isScrollable,
                    checked = if (node.isCheckable) node.isChecked else null,
                    enabled = node.isEnabled,
                    bounds = rect,
                    depth = depth
                )
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collect(child, depth + 1, out)
            } finally {
                recycleSafely(child)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun recycleSafely(node: AccessibilityNodeInfo) {
        // Android 13+ এ recycle() no-op, তবু পুরোনো device-এর জন্য রাখা হলো
        try { node.recycle() } catch (_: Exception) {}
    }
}
