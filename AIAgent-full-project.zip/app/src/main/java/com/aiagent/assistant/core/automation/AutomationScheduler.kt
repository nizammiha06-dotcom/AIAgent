package com.aiagent.assistant.core.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.aiagent.assistant.data.repository.AutomationRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/** TIME trigger-এর exact alarm। Boot-এর পরে enabled সবগুলো আবার schedule হয়। */
@Singleton
class AutomationScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repo: AutomationRepository
) {
    private val alarm = context.getSystemService(AlarmManager::class.java)

    fun rescheduleAll() {
        CoroutineScope(Dispatchers.IO).launch {
            repo.enabled()
                .filter { it.triggerType == TriggerType.TIME }
                .forEach { schedule(it) }
        }
    }

    fun schedule(automation: Automation) {
        if (!automation.enabled || automation.triggerType != TriggerType.TIME) return
        val next = nextTriggerMillis(automation) ?: return
        val pi = pendingIntentFor(automation.id)
        val canExact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()
        if (canExact) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        }
    }

    fun cancel(automationId: String) {
        alarm.cancel(pendingIntentFor(automationId))
    }

    private fun pendingIntentFor(automationId: String): PendingIntent {
        val intent = Intent(context, AutomationReceiver::class.java)
            .putExtra(AutomationReceiver.EXTRA_ID, automationId)
        return PendingIntent.getBroadcast(
            context,
            automationId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTriggerMillis(automation: Automation): Long? {
        val parts = automation.triggerValue.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: return null
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: return null
        val mask = if (automation.daysMask == 0) Automation.ALL_DAYS else automation.daysMask

        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val bit = Automation.dayBit(c.get(Calendar.DAY_OF_WEEK))
            if (mask and bit != 0 && c.after(now)) return c.timeInMillis
        }
        return null
    }
}
