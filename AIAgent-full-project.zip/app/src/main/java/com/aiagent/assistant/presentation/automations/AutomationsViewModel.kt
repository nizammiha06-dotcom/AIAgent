package com.aiagent.assistant.presentation.automations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.automation.Automation
import com.aiagent.assistant.core.automation.AutomationScheduler
import com.aiagent.assistant.core.automation.TriggerType
import com.aiagent.assistant.data.repository.AutomationRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AutomationsViewModel @Inject constructor(
    private val repo: AutomationRepository,
    private val scheduler: AutomationScheduler
) : ViewModel() {

    val items: StateFlow<List<Automation>> = repo.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(
        id: String?,
        name: String,
        type: TriggerType,
        value: String,
        daysMask: Int,
        goal: String
    ) {
        viewModelScope.launch {
            val savedId = repo.save(id, name, type, value, daysMask, goal)
            repo.get(savedId)?.let { if (it.triggerType == TriggerType.TIME) scheduler.schedule(it) }
        }
    }

    fun toggle(item: Automation) {
        viewModelScope.launch {
            repo.setEnabled(item.id, !item.enabled)
            if (item.triggerType == TriggerType.TIME) {
                if (!item.enabled) scheduler.schedule(item.copy(enabled = true))
                else scheduler.cancel(item.id)
            }
        }
    }

    fun delete(item: Automation) {
        viewModelScope.launch {
            scheduler.cancel(item.id)
            repo.delete(item.id)
        }
    }
}
