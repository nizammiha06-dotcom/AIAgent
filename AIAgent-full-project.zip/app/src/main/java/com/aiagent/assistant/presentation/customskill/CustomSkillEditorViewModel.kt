package com.aiagent.assistant.presentation.customskill

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.knowledge.CustomSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import com.aiagent.assistant.data.repository.CustomSkillRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Form-এর ভেতরের সম্পাদনাযোগ্য সারি। */
data class ScreenDraft(val name: String = "", val hints: String = "")
data class ActionDraft(
    val id: String = "",
    val description: String = "",
    val hints: String = "",
    val needsConfirm: Boolean = false
)

data class EditorState(
    val id: String = "",
    val displayName: String = "",
    val packages: String = "",
    val screens: List<ScreenDraft> = emptyList(),
    val actions: List<ActionDraft> = emptyList(),
    val error: String? = null,
    val saved: Boolean = false
)

@HiltViewModel
class CustomSkillEditorViewModel @Inject constructor(
    private val repo: CustomSkillRepository
) : ViewModel() {

    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state.asStateFlow()

    fun load(skill: CustomSkill?) {
        if (skill == null) return
        _state.value = EditorState(
            id = skill.id,
            displayName = skill.displayName,
            packages = skill.packageNames.joinToString(", "),
            screens = skill.screens.map {
                ScreenDraft(it.nameEn, it.identifyingTexts.joinToString(", "))
            },
            actions = skill.actions.map {
                ActionDraft(it.id, it.descriptionEn, it.targetHints.joinToString(", "), it.requiresConfirmation)
            }
        )
    }

    fun setName(v: String) = _state.update { it.copy(displayName = v, error = null) }
    fun setPackages(v: String) = _state.update { it.copy(packages = v, error = null) }

    fun addScreen() = _state.update { it.copy(screens = it.screens + ScreenDraft()) }
    fun editScreen(i: Int, d: ScreenDraft) = _state.update { s ->
        s.copy(screens = s.screens.mapIndexed { idx, v -> if (idx == i) d else v })
    }
    fun removeScreen(i: Int) = _state.update { s ->
        s.copy(screens = s.screens.filterIndexed { idx, _ -> idx != i })
    }

    fun addAction() = _state.update { it.copy(actions = it.actions + ActionDraft(id = "act_${it.actions.size + 1}")) }
    fun editAction(i: Int, d: ActionDraft) = _state.update { s ->
        s.copy(actions = s.actions.mapIndexed { idx, v -> if (idx == i) d else v })
    }
    fun removeAction(i: Int) = _state.update { s ->
        s.copy(actions = s.actions.filterIndexed { idx, _ -> idx != i })
    }

    fun save() {
        val s = _state.value
        val packages = s.packages.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        when {
            s.displayName.isBlank() -> return setError("অ্যাপের নাম দাও")
            packages.isEmpty() -> return setError("অন্তত একটি package name দাও")
            s.actions.isEmpty() -> return setError("অন্তত একটি action যোগ করো")
            s.actions.any { it.id.isBlank() || it.hints.isBlank() } ->
                return setError("প্রতিটি action-এ id ও target label দাও")
        }

        val skill = CustomSkill(
            id = s.id,
            displayName = s.displayName.trim(),
            packageNames = packages,
            screens = s.screens
                .filter { it.name.isNotBlank() }
                .mapIndexed { i, d ->
                    KnownScreen(
                        id = "screen_$i",
                        nameEn = d.name.trim(),
                        nameBn = d.name.trim(),
                        identifyingTexts = d.hints.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                    )
                },
            actions = s.actions.map { a ->
                SkillAction(
                    id = a.id.trim(),
                    descriptionEn = a.description.trim(),
                    descriptionBn = a.description.trim(),
                    targetHints = a.hints.split(',').map { it.trim() }.filter { it.isNotEmpty() },
                    requiresConfirmation = a.needsConfirm
                )
            }
        )

        viewModelScope.launch {
            repo.save(skill)
            _state.update { it.copy(saved = true, error = null) }
        }
    }

    fun deleteCurrent() {
        val id = _state.value.id
        if (id.isBlank()) return
        viewModelScope.launch {
            repo.delete(id)
            _state.update { it.copy(saved = true) }
        }
    }

    private fun setError(msg: String) = _state.update { it.copy(error = msg) }

    private fun MutableStateFlow<EditorState>.update(f: (EditorState) -> EditorState) {
        value = f(value)
    }
}
