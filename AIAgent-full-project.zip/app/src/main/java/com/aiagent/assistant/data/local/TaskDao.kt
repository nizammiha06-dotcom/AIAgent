package com.aiagent.assistant.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    @Query("SELECT * FROM task_plans ORDER BY createdAt DESC")
    fun observePlans(): Flow<List<TaskPlanEntity>>

    @Query("SELECT * FROM task_steps WHERE planId = :planId ORDER BY stepIndex ASC")
    fun observeSteps(planId: String): Flow<List<TaskStepEntity>>

    @Upsert
    suspend fun upsertPlan(plan: TaskPlanEntity)

    @Upsert
    suspend fun upsertSteps(steps: List<TaskStepEntity>)

    @Query("DELETE FROM task_plans WHERE id = :id")
    suspend fun deletePlan(id: String)
}
