package com.aiagent.assistant.presentation.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.planner.ConfirmationGate
import com.aiagent.assistant.core.planner.TaskExecutionEngine
import com.aiagent.assistant.core.planner.TaskPlan
import com.aiagent.assistant.data.local.TaskPlanEntity
import com.aiagent.assistant.data.repository.TaskRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TasksViewModel @Inject constructor(
    private val repo: TaskRepository,
    private val executor: TaskExecutionEngine,
    val gate: ConfirmationGate
) : ViewModel() {

    val plans: StateFlow<List<TaskPlanEntity>> = repo.observePlans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val current: StateFlow<TaskPlan?> = executor.current
    val pending = gate.pending

    fun run(plan: TaskPlan) = executor.start(plan)

    fun cancel() = executor.cancel()

    fun allow(allow: Boolean) = gate.answer(allow)

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}
