package com.aiagent.assistant.core.vision

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.aiagent.assistant.core.agent.AgentNotifications
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * MediaProjection-এর জন্য Foreground Service।
 * Android 14+-এ MediaProjection চালানোর আগে এই service চালু থাকতে হবে।
 */
@AndroidEntryPoint
class ScreenCaptureService : Service() {

    @Inject lateinit var holder: ProjectionPermissionHolder

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AgentNotifications.ensureChannel(this)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            AgentNotifications.build(this, "Screen analysis চালু"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        if (intent?.action == ACTION_START && projection == null) {
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
            if (code != 0 && data != null) {
                val mgr = getSystemService(MediaProjectionManager::class.java)
                projection = mgr.getMediaProjection(code, data)
                holder.store(code, data)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        projection?.stop()
        projection = null
        holder.clear()
        super.onDestroy()
    }

    companion object {
        const val NOTIFICATION_ID = 1003
        const val ACTION_START = "com.aiagent.assistant.SCREEN_START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"

        /** Service-এর ভেতরে থাকা projection; অন্য জায়গা থেকে ScreenshotCapture ব্যবহার করে। */
        @Volatile var projection: MediaProjection? = null
    }
}
