package com.aiagent.assistant.data.local

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomSkillDao {

    @Query("SELECT * FROM custom_skills ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<CustomSkillEntity>>

    @Query("SELECT * FROM custom_skills")
    suspend fun allOnce(): List<CustomSkillEntity>

    @Upsert
    suspend fun upsert(skill: CustomSkillEntity)

    @Query("DELETE FROM custom_skills WHERE id = :id")
    suspend fun delete(id: String)
}
