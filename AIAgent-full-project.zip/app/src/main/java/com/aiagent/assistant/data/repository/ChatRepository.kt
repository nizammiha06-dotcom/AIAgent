package com.aiagent.assistant.data.repository

import com.aiagent.assistant.data.local.ChatDao
import com.aiagent.assistant.data.local.ChatEntity
import com.aiagent.assistant.data.local.MessageEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(
    private val dao: ChatDao
) {
    fun observeChats(): Flow<List<ChatEntity>> = dao.observeChats()
    fun observeChat(id: String): Flow<ChatEntity?> = dao.observeChat(id)
    fun observeMessages(chatId: String): Flow<List<MessageEntity>> = dao.observeMessages(chatId)

    suspend fun history(chatId: String): List<MessageEntity> = dao.messagesOnce(chatId)

    suspend fun createChat(title: String): String {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        dao.upsertChat(
            ChatEntity(
                id = id,
                title = title.ifBlank { "New chat" },
                createdAt = now,
                updatedAt = now
            )
        )
        return id
    }

    suspend fun addMessage(chatId: String, role: String, content: String, isError: Boolean = false) {
        val now = System.currentTimeMillis()
        dao.insertMessage(
            MessageEntity(
                id = UUID.randomUUID().toString(),
                chatId = chatId,
                role = role,
                content = content,
                createdAt = now,
                isError = isError
            )
        )
        dao.touch(chatId, now)
    }

    /**
     * একই id-তে বারবার লেখা (streaming draft)। Room REPLACE করে, তাই UI অটো আপডেট হয়।
     */
    suspend fun saveMessage(
        id: String,
        chatId: String,
        role: String,
        content: String,
        createdAt: Long,
        isError: Boolean
    ) {
        dao.insertMessage(
            MessageEntity(
                id = id,
                chatId = chatId,
                role = role,
                content = content,
                createdAt = createdAt,
                isError = isError
            )
        )
        dao.touch(chatId, System.currentTimeMillis())
    }

    suspend fun rename(id: String, title: String) {
        dao.rename(id, title.ifBlank { "Untitled" }, System.currentTimeMillis())
    }

    suspend fun setPinned(id: String, pinned: Boolean) = dao.setPinned(id, pinned)

    suspend fun delete(id: String) = dao.deleteChat(id)

    suspend fun exportAsText(chatId: String): String {
        val chat = dao.chatOnce(chatId) ?: return ""
        val messages = dao.messagesOnce(chatId)
        return buildString {
            appendLine(chat.title)
            appendLine()
            messages.forEach { msg ->
                val who = if (msg.role == ROLE_USER) "You" else "Assistant"
                appendLine("$who: ${msg.content}")
                appendLine()
            }
        }
    }

    companion object {
        const val ROLE_USER = "user"
        const val ROLE_ASSISTANT = "assistant"
    }
}
