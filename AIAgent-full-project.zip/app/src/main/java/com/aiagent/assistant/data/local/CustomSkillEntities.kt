package com.aiagent.assistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custom_skills")
data class CustomSkillEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val packageNames: String,       // comma-separated
    val screensJson: String,        // [{id,nameEn,nameBn,identifyingTexts:[...]}]
    val actionsJson: String,        // [{id,descriptionEn,descriptionBn,targetHints:[...],requiresConfirmation}]
    val createdAt: Long,
    val updatedAt: Long
)
