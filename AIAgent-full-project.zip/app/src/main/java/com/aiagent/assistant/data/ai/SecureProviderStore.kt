package com.aiagent.assistant.data.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/** Provider config ও API key — সব encrypted storage-এ। */
@Singleton
class SecureProviderStore @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_ai_store",
        MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getProviders(): List<AiProviderConfig> {
        val raw = prefs.getString(KEY_PROVIDERS, null) ?: return emptyList()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }
    }

    /** apiKey null বা খালি হলে আগের key অপরিবর্তিত থাকবে। */
    fun saveProvider(config: AiProviderConfig, apiKey: String?) {
        val list = getProviders().toMutableList()
        val idx = list.indexOfFirst { it.id == config.id }
        if (idx >= 0) list[idx] = config else list.add(config)
        writeAll(list)
        if (!apiKey.isNullOrBlank()) {
            prefs.edit().putString(keyFor(config.id), apiKey).apply()
        }
    }

    fun deleteProvider(id: String) {
        writeAll(getProviders().filterNot { it.id == id })
        val editor = prefs.edit().remove(keyFor(id))
        if (defaultId() == id) editor.remove(KEY_DEFAULT)
        if (backupId() == id) editor.remove(KEY_BACKUP)
        editor.apply()
    }

    fun getApiKey(id: String): String? = prefs.getString(keyFor(id), null)

    fun defaultId(): String? = prefs.getString(KEY_DEFAULT, null)
    fun backupId(): String? = prefs.getString(KEY_BACKUP, null)

    fun setDefaultId(id: String) = prefs.edit().putString(KEY_DEFAULT, id).apply()
    fun setBackupId(id: String) = prefs.edit().putString(KEY_BACKUP, id).apply()

    private fun writeAll(list: List<AiProviderConfig>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        prefs.edit().putString(KEY_PROVIDERS, arr.toString()).apply()
    }

    private fun toJson(c: AiProviderConfig): JSONObject = JSONObject()
        .put("id", c.id)
        .put("name", c.name)
        .put("protocol", c.protocol.name)
        .put("baseUrl", c.baseUrl)
        .put("model", c.model)
        .put("requiresKey", c.requiresKey)
        .put("temperature", c.temperature.toDouble())
        .put("maxTokens", c.maxTokens)
        .put("systemPrompt", c.systemPrompt)
        .put("enabled", c.enabled)
        .put("supportsVision", c.supportsVision)

    private fun fromJson(o: JSONObject): AiProviderConfig = AiProviderConfig(
        id = o.getString("id"),
        name = o.getString("name"),
        protocol = Protocol.valueOf(o.getString("protocol")),
        baseUrl = o.getString("baseUrl"),
        model = o.getString("model"),
        requiresKey = o.optBoolean("requiresKey", true),
        temperature = o.optDouble("temperature", 0.7).toFloat(),
        maxTokens = o.optInt("maxTokens", 1024),
        systemPrompt = o.optString("systemPrompt", AiProviderConfig.DEFAULT_SYSTEM_PROMPT),
        enabled = o.optBoolean("enabled", true),
        supportsVision = o.optBoolean("supportsVision", false)
    )

    private fun keyFor(id: String) = "key_$id"

    companion object {
        private const val KEY_PROVIDERS = "providers"
        private const val KEY_DEFAULT = "default_id"
        private const val KEY_BACKUP = "backup_id"
    }
}
