package com.aiagent.assistant.core.agent

import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

enum class TaskStatus { PENDING, RUNNING, DONE, FAILED }

data class AgentTask(
    val id: String,
    val title: String,
    val status: TaskStatus,
    val createdAt: Long
)

/**
 * Background task queue (এখন in-memory)।
 * Step 13 (Autonomous Task Planner)-এ এখান থেকে task নিয়ে execute হবে।
 */
@Singleton
class AgentTaskQueue @Inject constructor() {

    private val _tasks = MutableStateFlow<List<AgentTask>>(emptyList())
    val tasks: StateFlow<List<AgentTask>> = _tasks.asStateFlow()

    fun enqueue(title: String): String {
        val id = UUID.randomUUID().toString()
        _tasks.update {
            it + AgentTask(id, title, TaskStatus.PENDING, System.currentTimeMillis())
        }
        return id
    }

    fun setStatus(id: String, status: TaskStatus) {
        _tasks.update { list ->
            list.map { if (it.id == id) it.copy(status = status) else it }
        }
    }

    fun clearFinished() {
        _tasks.update { list ->
            list.filterNot { it.status == TaskStatus.DONE || it.status == TaskStatus.FAILED }
        }
    }
}
