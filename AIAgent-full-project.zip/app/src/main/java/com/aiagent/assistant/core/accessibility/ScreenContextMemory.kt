package com.aiagent.assistant.core.accessibility

import javax.inject.Inject
import javax.inject.Singleton

/** সর্বশেষ কয়েকটি snapshot মনে রাখে, যাতে Planner আগের screen তুলনা করতে পারে। */
@Singleton
class ScreenContextMemory @Inject constructor() {

    private val history = ArrayDeque<ScreenSnapshot>()

    @Synchronized
    fun push(snapshot: ScreenSnapshot) {
        history.addLast(snapshot)
        while (history.size > MAX) history.removeFirst()
    }

    @Synchronized
    fun latest(): ScreenSnapshot? = history.lastOrNull()

    @Synchronized
    fun previous(): ScreenSnapshot? =
        if (history.size >= 2) history.elementAt(history.size - 2) else null

    /** দুটি snapshot-এর element সংখ্যা ও label-এর সেট তুলনা করে বলে screen বদলেছে কিনা। */
    @Synchronized
    fun screenChanged(): Boolean {
        val a = history.lastOrNull() ?: return true
        val b = previous() ?: return true
        if (a.packageName != b.packageName) return true
        val la = a.elements.map { it.label }.toSet()
        val lb = b.elements.map { it.label }.toSet()
        val diff = (la union lb).size - (la intersect lb).size
        return diff > (la.size + lb.size) / 4
    }

    companion object {
        private const val MAX = 5
    }
}
