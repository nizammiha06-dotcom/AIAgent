package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

/** Notes app ডিভাইস অনুযায়ী ভিন্ন। Google Keep ও সাধারণ নোট অ্যাপ দুটোই ধরা হয়েছে। */
@Singleton
class NotesSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.keep",
        "com.samsung.android.app.notes",
        "com.miui.notes"
    )
    override val displayName = "Notes"

    override val screens = listOf(
        KnownScreen(
            id = "notes_list",
            nameEn = "Notes list",
            nameBn = "নোট তালিকা",
            identifyingTexts = listOf("Notes", "Search your notes", "Take a note")
        ),
        KnownScreen(
            id = "notes_editor",
            nameEn = "Note editor",
            nameBn = "নোট লেখা",
            identifyingTexts = listOf("Title", "Take a note", "Done")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "new_note",
            descriptionEn = "Tap Take a note to create a new note",
            descriptionBn = "Take a note চাপে নতুন নোট",
            targetHints = listOf("Take a note", "New note", "+")
        ),
        SkillAction(
            id = "type_note",
            descriptionEn = "Type the note text",
            descriptionBn = "নোটের লেখা বসানো",
            targetHints = listOf("Take a note", "Title")
        ),
        SkillAction(
            id = "save_note",
            descriptionEn = "Tap Done or back to save the note",
            descriptionBn = "Done চাপে বা back করে নোট সেভ",
            targetHints = listOf("Done")
        )
    )
}
