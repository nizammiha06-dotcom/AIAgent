package com.aiagent.assistant.core.voice

import android.content.Context
import android.speech.SpeechRecognizer
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import com.aiagent.assistant.data.repository.ChatRepository
import com.aiagent.assistant.data.settings.AppSettings
import com.aiagent.assistant.data.settings.SettingsStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

enum class VoicePhase { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

data class VoiceUiState(
    val phase: VoicePhase = VoicePhase.IDLE,
    val partial: String = "",
    val lastReply: String = "",
    val error: String? = null
)

/**
 * Live conversation loop: শোনা → AI → বলা → আবার শোনা।
 * Chat-এর কথাবার্তা Room-এ সেভ হয়।
 */
@Singleton
class LiveVoiceSession @Inject constructor(
    @ApplicationContext private val context: Context,
    private val router: AiRouter,
    private val repo: ChatRepository,
    private val settingsStore: SettingsStore
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow(VoiceUiState())
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    private val input = SpeechInput(context)
    private val output = SpeechOutput(context)
    private var chatId: String? = null
    private var running = false
    private var current = AppSettings()

    /** Session শেষ হলে কল হয় (Background Agent wake word শোনা আবার শুরু করতে)। */
    var onStopped: (() -> Unit)? = null

    val isActive: Boolean get() = running

    init {
        scope.launch { settingsStore.settings.collect { current = it } }

        input.listener = object : SpeechInput.Listener {
            override fun onPartial(text: String) {
                _state.update { it.copy(partial = text) }
            }

            override fun onFinal(text: String) = onUserSpoke(text)

            override fun onError(code: Int) {
                when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> listenAgain()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> scope.launch {
                        delay(800)
                        listenAgain()
                    }
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        fail("মাইক্রোফোন অনুমতি নেই। Permissions থেকে চালু করো।")
                    else -> fail("Speech error code: $code")
                }
            }
        }

        output.onDone = { if (running) listenAgain() }
    }

    fun start() {
        if (running) return
        running = true
        listenAgain()
    }

    fun stop() {
        running = false
        input.cancel()
        output.stop()
        _state.value = VoiceUiState()
        onStopped?.invoke()
    }

    private fun listenAgain() {
        if (!running) return
        _state.update { it.copy(phase = VoicePhase.LISTENING, partial = "", error = null) }
        input.start(languageTag(current.language))
    }

    private fun onUserSpoke(text: String) {
        if (!running) return
        if (text.isBlank()) {
            listenAgain()
            return
        }
        scope.launch {
            _state.update { it.copy(phase = VoicePhase.THINKING, partial = text) }
            try {
                val id = chatId ?: repo.createChat(text.take(40)).also { chatId = it }
                repo.addMessage(id, ChatRepository.ROLE_USER, text)

                val turns = repo.history(id)
                    .filter { !it.isError && it.content.isNotBlank() }
                    .takeLast(MAX_HISTORY)
                    .map { ChatTurn(it.role, it.content) }

                router.stream(turns, onDelta = {}, onRestart = {})
                    .onSuccess { reply ->
                        repo.addMessage(id, ChatRepository.ROLE_ASSISTANT, reply)
                        _state.update { it.copy(phase = VoicePhase.SPEAKING, lastReply = reply) }
                        val spoke = output.speak(
                            reply,
                            languageTag(current.language),
                            current.voiceStyle,
                            current.voiceSpeed,
                            current.voicePitch
                        )
                        if (!spoke) listenAgain()
                    }
                    .onFailure { e ->
                        repo.addMessage(id, ChatRepository.ROLE_ASSISTANT,
                            "⚠️ উত্তর আনা যায়নি: ${e.message}", isError = true)
                        _state.update { it.copy(error = e.message) }
                        listenAgain()
                    }
            } catch (e: Exception) {
                fail("Voice error: ${e.message}")
            }
        }
    }

    private fun fail(message: String) {
        running = false
        input.cancel()
        _state.update { it.copy(phase = VoicePhase.ERROR, error = message) }
        onStopped?.invoke()
    }

    companion object {
        private const val MAX_HISTORY = 30
    }
}
