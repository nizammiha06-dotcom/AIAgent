package com.aiagent.assistant.core.automation

import com.aiagent.assistant.core.planner.AgentPlanner
import com.aiagent.assistant.core.planner.TaskExecutionEngine
import com.aiagent.assistant.data.repository.AutomationRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutomationRunner @Inject constructor(
    private val repo: AutomationRepository,
    private val planner: AgentPlanner,
    private val executor: TaskExecutionEngine,
    private val scheduler: AutomationScheduler
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lastRun = mutableMapOf<String, Long>()

    fun run(automationId: String) {
        scope.launch {
            val automation = repo.get(automationId) ?: return@launch
            if (!automation.enabled) return@launch

            // একই automation ৩০ সেকেন্ডের মধ্যে আবার চলবে না
            val now = System.currentTimeMillis()
            synchronized(lastRun) {
                val last = lastRun[automationId] ?: 0L
                if (now - last < COOLDOWN_MS) return@launch
                lastRun[automationId] = now
            }

            if (automation.triggerType == TriggerType.TIME) {
                scheduler.schedule(automation)
            }
            if (executor.isRunning) return@launch

            planner.plan(automation.goal).onSuccess { plan ->
                repo.markRun(automationId)
                executor.start(plan)
            }
        }
    }

    fun onAppOpened(packageName: String) {
        scope.launch {
            repo.enabled()
                .filter { it.triggerType == TriggerType.APP_OPENED && it.triggerValue == packageName }
                .forEach { run(it.id) }
        }
    }

    fun onNotification(packageName: String) {
        scope.launch {
            repo.enabled()
                .filter { it.triggerType == TriggerType.NOTIFICATION && it.triggerValue == packageName }
                .forEach { run(it.id) }
        }
    }

    /** Voice বা wake word-এর লেখা থেকে VOICE automation খোঁজে। */
    fun onVoiceText(text: String) {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return
        scope.launch {
            repo.enabled()
                .filter { it.triggerType == TriggerType.VOICE && t.contains(it.triggerValue.lowercase()) }
                .forEach { run(it.id) }
        }
    }

    companion object {
        private const val COOLDOWN_MS = 30_000L
    }
}
