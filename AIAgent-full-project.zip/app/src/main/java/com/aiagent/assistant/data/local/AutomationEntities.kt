package com.aiagent.assistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val triggerType: String,      // TIME | APP_OPENED | NOTIFICATION | VOICE
    val triggerValue: String,     // TIME: "HH:mm", APP: package, NOTIFICATION: package, VOICE: phrase
    val daysMask: Int,            // বিট মাস্ক: bit0=Sun ... bit6=Sat, 0 মানে প্রতিদিন নয়, 127 মানে প্রতিদিন
    val goal: String,             // AI-কে পাঠানোর কাজের বর্ণনা
    val enabled: Boolean,
    val createdAt: Long,
    val lastRunAt: Long = 0L
)
