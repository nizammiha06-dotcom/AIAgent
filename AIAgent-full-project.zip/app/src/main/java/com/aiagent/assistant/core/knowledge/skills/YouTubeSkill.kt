package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YouTubeSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.google.android.youtube")
    override val displayName = "YouTube"

    override val screens = listOf(
        KnownScreen(
            id = "yt_home",
            nameEn = "Home feed",
            nameBn = "হোম ফিড",
            identifyingTexts = listOf("Home", "Shorts", "Subscriptions")
        ),
        KnownScreen(
            id = "yt_search",
            nameEn = "Search",
            nameBn = "সার্চ",
            identifyingTexts = listOf("Search YouTube")
        ),
        KnownScreen(
            id = "yt_player",
            nameEn = "Video player",
            nameBn = "ভিডিও প্লেয়ার",
            identifyingTexts = listOf("Subscribe", "Share", "Download")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "search",
            descriptionEn = "Open search and type a query",
            descriptionBn = "সার্চে গিয়ে query লেখা",
            targetHints = listOf("Search", "Search YouTube")
        ),
        SkillAction(
            id = "open_first_result",
            descriptionEn = "Open the first video in search results",
            descriptionBn = "সার্চ ফলাফলের প্রথম ভিডিও খোলা",
            targetHints = listOf("video title")
        ),
        SkillAction(
            id = "download_video",
            descriptionEn = "Use the Download button under the player (YouTube Premium-এ offline)",
            descriptionBn = "প্লেয়ারের নিচে Download বাটন",
            targetHints = listOf("Download"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "share",
            descriptionEn = "Open the share sheet for the current video",
            descriptionBn = "বর্তমান ভিডিওর share sheet",
            targetHints = listOf("Share")
        )
    )
}
