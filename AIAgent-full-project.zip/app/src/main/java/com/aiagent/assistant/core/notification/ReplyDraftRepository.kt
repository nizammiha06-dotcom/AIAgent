package com.aiagent.assistant.core.notification

import javax.inject.Inject
import javax.inject.Singleton

/** AI-র তৈরি reply draft মেমোরিতে রাখে, যাতে user confirm করার আগে পর্যন্ত অপেক্ষা করা যায়। */
@Singleton
class ReplyDraftRepository @Inject constructor() {

    data class Draft(val key: String, val sender: String, val originalText: String, val reply: String)

    private val _drafts = LinkedHashMap<String, Draft>()

    @Synchronized
    fun put(draft: Draft) {
        _drafts[draft.key] = draft
        if (_drafts.size > 20) _drafts.remove(_drafts.keys.first())
    }

    @Synchronized
    fun get(key: String): Draft? = _drafts[key]

    @Synchronized
    fun remove(key: String) {
        _drafts.remove(key)
    }
}
