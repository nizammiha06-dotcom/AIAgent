package com.aiagent.assistant.presentation.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.agent.AgentServiceController
import com.aiagent.assistant.data.settings.AppSettings
import com.aiagent.assistant.data.settings.SettingsStore
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val store: SettingsStore,
    private val locale: com.aiagent.assistant.core.locale.LocaleController,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val settings: StateFlow<AppSettings> = store.settings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        AppSettings()
    )

    fun setLanguage(code: String) {
        update { it.copy(language = code) }
        locale.apply(code)
    }
    fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch {
            val before = store.settings.first()
            store.update(transform)
            val after = store.settings.first()
            // Wake word toggle বদলালে Background Agent চালু/বন্ধ হবে
            if (before.wakeWordEnabled != after.wakeWordEnabled) {
                AgentServiceController.setEnabled(context, after.wakeWordEnabled)
            }
        }
    }
}
