package com.aiagent.assistant.presentation.home

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.Composable

enum class BottomTab(val label: String) {
    HOME("Home"),
    CHAT("Chat"),
    TASKS("Tasks"),
    SETTINGS("Settings")
}

@Composable
fun BottomNavBar(
    selected: BottomTab,
    onSelect: (BottomTab) -> Unit
) {
    NavigationBar {
        BottomTab.entries.forEach { tab ->
            NavigationBarItem(
                selected = selected == tab,
                onClick = { onSelect(tab) },
                icon = {
                    Icon(
                        imageVector = when (tab) {
                            BottomTab.HOME -> Icons.Filled.Home
                            BottomTab.CHAT -> Icons.Filled.Chat
                            BottomTab.TASKS -> Icons.Filled.Build
                            BottomTab.SETTINGS -> Icons.Filled.Settings
                        },
                        contentDescription = tab.label
                    )
                },
                label = { Text(tab.label) }
            )
        }
    }
}
