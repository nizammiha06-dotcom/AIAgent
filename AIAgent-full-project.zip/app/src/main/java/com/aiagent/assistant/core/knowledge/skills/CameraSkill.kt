package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

/** Camera package ডিভাইস অনুযায়ী ভিন্ন হয়; সাধারণ AOSP ও কিছু OEM নাম যোগ করা হলো। */
@Singleton
class CameraSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.android.camera",
        "com.android.camera2",
        "com.sec.android.app.camera",
        "com.google.android.GoogleCamera",
        "com.miui.camera"
    )
    override val displayName = "Camera"

    override val screens = listOf(
        KnownScreen(
            id = "cam_viewfinder",
            nameEn = "Viewfinder",
            nameBn = "ক্যামেরা ভিউ",
            identifyingTexts = listOf("Photo", "Video", "Portrait")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "take_photo",
            descriptionEn = "Tap the shutter button to take a photo",
            descriptionBn = "শাটার বাটনে চেপে ছবি তোলা",
            targetHints = listOf("Shutter", "Take photo", "Capture")
        ),
        SkillAction(
            id = "switch_mode",
            descriptionEn = "Switch between Photo, Video, Portrait modes",
            descriptionBn = "Photo, Video, Portrait মোড বদলানো",
            targetHints = listOf("Video", "Photo", "Portrait")
        ),
        SkillAction(
            id = "flip_camera",
            descriptionEn = "Switch between front and back camera",
            descriptionBn = "সামনে ও পেছনের ক্যামেরা বদলানো",
            targetHints = listOf("Switch camera", "Flip")
        )
    )
}
