package com.aiagent.assistant.core.vision

import android.content.Context
import com.aiagent.assistant.core.accessibility.AccessibilityEngine
import com.aiagent.assistant.core.accessibility.ScreenSnapshot
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Screen তথ্যের fallback চেইন:
 * 1) Accessibility snapshot (সবচেয়ে নির্ভরযোগ্য)
 * 2) অপর্যাপ্ত হলে OCR text
 * 3) তাও না হলে screenshot সহ vision AI
 */
@Singleton
class VisionAnalyzer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val engine: AccessibilityEngine,
    private val capture: ScreenshotCapture,
    private val ocr: OcrEngine,
    private val router: AiRouter,
    private val holder: ProjectionPermissionHolder
) {

    /** বর্তমান screen-এর বর্ণনা (text) ফেরত দেয়। */
    suspend fun describeScreen(question: String): String {
        val snap = engine.currentSnapshot()
        if (snap != null && snap.elements.size >= MIN_ELEMENTS) {
            return ask(question, snap.toPromptText(), image = null)
        }

        val pkg = snap?.packageName.orEmpty()
        val jpeg = if (holder.hasPermission()) capture.capture(context, pkg) else null
        if (jpeg == null) {
            return snap?.toPromptText() ?: "Screen তথ্য পাওয়া যায়নি।"
        }

        val text = ocr.recognize(jpeg)
        if (text.length >= MIN_OCR_CHARS) {
            return ask(question, "OCR text:\n$text", image = null)
        }

        return ask(question, snap?.toPromptText().orEmpty(), image = jpeg)
    }

    private suspend fun ask(question: String, screen: String, image: ByteArray?): String {
        val prompt = buildString {
            appendLine("Describe or answer based on the current Android screen.")
            appendLine("Reply in the user's language (Bangla or English).")
            appendLine()
            appendLine("Screen:")
            appendLine(screen)
            appendLine()
            append("Question: $question")
        }
        return if (image != null) {
            router.describeImage(prompt, image)
        } else {
            router.stream(listOf(ChatTurn("user", prompt)), onDelta = {}, onRestart = {})
                .getOrElse { "উত্তর আনা যায়নি: ${it.message}" }
        }
    }

    companion object {
        private const val MIN_ELEMENTS = 5
        private const val MIN_OCR_CHARS = 20
    }
}
