package com.aiagent.assistant.data.repository

import com.aiagent.assistant.core.automation.Automation
import com.aiagent.assistant.core.automation.TriggerType
import com.aiagent.assistant.data.local.AutomationDao
import com.aiagent.assistant.data.local.AutomationEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutomationRepository @Inject constructor(
    private val dao: AutomationDao
) {
    fun observeAll(): Flow<List<Automation>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    suspend fun enabled(): List<Automation> = dao.enabledOnce().map { it.toDomain() }

    suspend fun get(id: String): Automation? = dao.byId(id)?.toDomain()

    suspend fun save(
        id: String?,
        name: String,
        triggerType: TriggerType,
        triggerValue: String,
        daysMask: Int,
        goal: String
    ): String {
        val finalId = id ?: UUID.randomUUID().toString()
        val existing = id?.let { dao.byId(it) }
        dao.upsert(
            AutomationEntity(
                id = finalId,
                name = name.ifBlank { goal.take(30) },
                triggerType = triggerType.name,
                triggerValue = triggerValue,
                daysMask = daysMask,
                goal = goal,
                enabled = existing?.enabled ?: true,
                createdAt = existing?.createdAt ?: System.currentTimeMillis(),
                lastRunAt = existing?.lastRunAt ?: 0L
            )
        )
        return finalId
    }

    suspend fun setEnabled(id: String, enabled: Boolean) = dao.setEnabled(id, enabled)

    suspend fun markRun(id: String) = dao.markRun(id, System.currentTimeMillis())

    suspend fun delete(id: String) = dao.delete(id)

    private fun AutomationEntity.toDomain() = Automation(
        id = id,
        name = name,
        triggerType = runCatching { TriggerType.valueOf(triggerType) }.getOrDefault(TriggerType.TIME),
        triggerValue = triggerValue,
        daysMask = daysMask,
        goal = goal,
        enabled = enabled,
        lastRunAt = lastRunAt
    )
}
