package com.aiagent.assistant.presentation.automations

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.core.automation.Automation
import com.aiagent.assistant.core.automation.TriggerType
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.theme.Spacing

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomationsScreen(
    onBack: () -> Unit,
    viewModel: AutomationsViewModel = hiltViewModel()
) {
    val items by viewModel.items.collectAsState()
    var editing by remember { mutableStateOf<Automation?>(null) }
    var creating by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Automations · স্বয়ংক্রিয়") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { creating = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            if (items.isEmpty()) {
                item {
                    Text(
                        "কোনো automation নেই। + চাপো এবং সময়, app বা notification বেছে কাজ লেখো।",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            items(items, key = { it.id }) { a ->
                AppCard {
                    Column(Modifier.padding(Spacing.md)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(a.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${a.triggerType.label()}: ${a.triggerValue}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(a.goal, style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = a.enabled, onCheckedChange = { viewModel.toggle(a) })
                        }
                        Row {
                            TextButton(onClick = { editing = a }) { Text("Edit") }
                            IconButton(onClick = { viewModel.delete(a) }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    if (creating || editing != null) {
        AutomationEditor(
            initial = editing,
            onSave = { name, type, value, days, goal ->
                viewModel.save(editing?.id, name, type, value, days, goal)
                creating = false
                editing = null
            },
            onDismiss = {
                creating = false
                editing = null
            }
        )
    }
}

@Composable
private fun AutomationEditor(
    initial: Automation?,
    onSave: (name: String, type: TriggerType, value: String, daysMask: Int, goal: String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var type by remember { mutableStateOf(initial?.triggerType ?: TriggerType.TIME) }
    var value by remember { mutableStateOf(initial?.triggerValue.orEmpty()) }
    var goal by remember { mutableStateOf(initial?.goal.orEmpty()) }
    val days = initial?.daysMask ?: Automation.ALL_DAYS

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন automation" else "Automation সম্পাদনা") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it },
                    label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
                    TriggerType.entries.forEach { t ->
                        TextButton(onClick = { type = t }) {
                            Text(if (t == type) "✓ ${t.label()}" else t.label())
                        }
                    }
                }
                OutlinedTextField(
                    value = value, onValueChange = { value = it },
                    label = { Text(hintFor(type)) }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = goal, onValueChange = { goal = it },
                    label = { Text("কী করতে হবে (বাংলা/English)") }, modifier = Modifier.fillMaxWidth(), maxLines = 4
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (goal.isNotBlank() && value.isNotBlank()) {
                    onSave(name, type, value.trim(), days, goal.trim())
                }
            }) { Text("Save · সেভ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun TriggerType.label(): String = when (this) {
    TriggerType.TIME -> "সময়"
    TriggerType.APP_OPENED -> "App খুললে"
    TriggerType.NOTIFICATION -> "Notification"
    TriggerType.VOICE -> "Voice"
}

private fun hintFor(type: TriggerType): String = when (type) {
    TriggerType.TIME -> "সময় (HH:mm, যেমন 07:30)"
    TriggerType.APP_OPENED -> "Package name (যেমন com.android.chrome)"
    TriggerType.NOTIFICATION -> "Package name (যেমন com.whatsapp)"
    TriggerType.VOICE -> "বাক্যাংশ (যেমন 'আমার কাজ শুরু')"
}
