package com.aiagent.assistant.core.notification

import android.content.Context
import com.aiagent.assistant.data.ai.AiRouter
import com.aiagent.assistant.data.ai.ChatTurn
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** AI দিয়ে draft বানায়, এবং confirm পেলে পাঠায়। */
@Singleton
class NotificationReplyController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val replies: NotificationReplyStore,
    private val drafts: ReplyDraftRepository,
    private val router: AiRouter
) {

    /** Notification-এর জন্য AI reply draft তৈরি করে সংরক্ষণ করে। */
    suspend fun createDraft(key: String): Result<ReplyDraftRepository.Draft> {
        val target = replies.get(key)
            ?: return Result.failure(IllegalStateException("এই notification-এ reply করা যাবে না"))

        val prompt = """
            Write a short, polite reply to this chat message. Reply in the same language as the message.
            Output only the reply text, no explanation.
            From: ${target.sender}
            Message: ${target.text}
        """.trimIndent()

        val reply = router.stream(listOf(ChatTurn("user", prompt)), onDelta = {}, onRestart = {})
            .getOrElse { return Result.failure(it) }
            .trim()

        if (reply.isBlank()) return Result.failure(IllegalStateException("খালি উত্তর এসেছে"))

        val draft = ReplyDraftRepository.Draft(key, target.sender, target.text, reply)
        drafts.put(draft)
        return Result.success(draft)
    }

    /** User confirm করলে পাঠায়। */
    fun confirmSend(key: String): Boolean {
        val draft = drafts.get(key) ?: return false
        val ok = replies.sendReply(context, key, draft.reply)
        if (ok) drafts.remove(key)
        return ok
    }

    fun discard(key: String) = drafts.remove(key)
}
