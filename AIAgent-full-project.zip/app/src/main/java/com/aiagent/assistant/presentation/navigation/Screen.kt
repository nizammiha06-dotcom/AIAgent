package com.aiagent.assistant.presentation.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Chat : Screen("chat?chatId={chatId}")
    data object Settings : Screen("settings")
    data object Permissions : Screen("permissions")
    data object Providers : Screen("providers")
    data object Automations : Screen("automations")
    data object Tasks : Screen("tasks")
    data object Debug : Screen("debug")
    data object Onboarding : Screen("onboarding")
    data object CustomSkills : Screen("custom_skills")
    data object CustomSkillEditor : Screen("custom_skill_editor?skillId={skillId}")
}

/** নতুন chat হলে chatId = null, বিদ্যমান chat হলে তার id। */
fun chatRoute(chatId: String? = null): String =
    if (chatId == null) "chat" else "chat?chatId=$chatId"

fun customSkillEditorRoute(skillId: String? = null): String =
    if (skillId == null) "custom_skill_editor" else "custom_skill_editor?skillId=$skillId"
