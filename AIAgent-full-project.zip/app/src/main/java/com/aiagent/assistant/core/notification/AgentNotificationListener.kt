package com.aiagent.assistant.core.notification

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.aiagent.assistant.core.automation.AutomationRunner
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Notification পড়ে:
 * 1) Reply action সংরক্ষণ করে (AI reply-র জন্য)
 * 2) Notification-based automation চালায়
 */
@AndroidEntryPoint
class AgentNotificationListener : NotificationListenerService() {

    @Inject lateinit var replies: NotificationReplyStore
    @Inject lateinit var runner: AutomationRunner

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        // নিজের app-এর notification ও ongoing agent notification বাদ
        if (sbn.packageName == packageName) return
        replies.remember(sbn)
        runner.onNotification(sbn.packageName)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        // Reply target-এর key মুছতে চাইলে NotificationReplyStore-এ remove যোগ করা যাবে
    }
}
