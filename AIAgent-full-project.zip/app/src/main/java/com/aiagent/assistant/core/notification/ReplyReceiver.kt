package com.aiagent.assistant.core.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.aiagent.assistant.MainActivity

class ReplyReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra(EXTRA_KEY) ?: return
        val open = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(EXTRA_REPLY_KEY, key)
        context.startActivity(open)
    }

    companion object {
        const val ACTION = "com.aiagent.assistant.REPLY_AI"
        const val EXTRA_KEY = "notif_key"
        const val EXTRA_REPLY_KEY = "reply_key"
    }
}
