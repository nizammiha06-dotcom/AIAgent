package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InstagramSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.instagram.android")
    override val displayName = "Instagram"

    override val screens = listOf(
        KnownScreen(
            id = "ig_feed",
            nameEn = "Home feed",
            nameBn = "হোম ফিড",
            identifyingTexts = listOf("Reels", "Shop", "Instagram")
        ),
        KnownScreen(
            id = "ig_new_post",
            nameEn = "New post",
            nameBn = "নতুন পোস্ট",
            identifyingTexts = listOf("New post", "Next", "Share")
        ),
        KnownScreen(
            id = "ig_search",
            nameEn = "Search & explore",
            nameBn = "সার্চ ও এক্সপ্লোর",
            identifyingTexts = listOf("Search", "Explore")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "new_post",
            descriptionEn = "Tap the plus button to start a new post",
            descriptionBn = "+ চাপে নতুন পোস্ট শুরু",
            targetHints = listOf("New post", "+", "Create")
        ),
        SkillAction(
            id = "share_post",
            descriptionEn = "Tap Share to publish the post",
            descriptionBn = "পোস্ট প্রকাশের জন্য Share চাপা",
            targetHints = listOf("Share"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "search",
            descriptionEn = "Open search and type a query",
            descriptionBn = "সার্চে গিয়ে query লেখা",
            targetHints = listOf("Search")
        )
    )
}
