package com.aiagent.assistant.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.aiagent.assistant.core.automation.AutomationRunner
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Accessibility Service। Window বদলালে App-opened automation trigger করে।
 */
@AndroidEntryPoint
class AgentAccessibilityService : AccessibilityService() {

    @Inject lateinit var runner: AutomationRunner

    private var lastPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // একই app-এর ভেতরে window বদলালে বারবার trigger না হওয়ার জন্য
        if (pkg == lastPackage) return
        lastPackage = pkg
        if (pkg != packageName) runner.onAppOpened(pkg)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: AgentAccessibilityService? = null
            private set
    }
}
