package com.aiagent.assistant.data.ai

import kotlinx.coroutines.delay

/** সাময়িক error (429, 5xx, network) হলে exponential backoff-এ আবার চেষ্টা। */
object AiRetry {

    private val transientCodes = setOf(408, 429, 500, 502, 503, 504)

    fun isTransient(e: Throwable): Boolean = when (e) {
        is AiException -> e.code in transientCodes || e.code == -1 && e.message?.contains("timeout", true) == true
        is java.io.IOException -> true
        else -> false
    }

    suspend fun <T> withRetry(
        maxAttempts: Int = 3,
        baseDelayMs: Long = 800L,
        block: suspend () -> T
    ): T {
        var attempt = 0
        while (true) {
            try {
                return block()
            } catch (e: Exception) {
                attempt++
                if (attempt >= maxAttempts || !isTransient(e)) throw e
                delay(baseDelayMs * (1L shl (attempt - 1)))
            }
        }
    }
}
