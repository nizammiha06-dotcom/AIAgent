package com.aiagent.assistant.core.vision

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import android.graphics.Rect
import com.aiagent.assistant.core.accessibility.SafetyGuard
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import javax.inject.Inject
import javax.inject.Singleton

/** একটি frame নিয়ে JPEG bytes ফেরত দেয়। Safety block হলে null। */
@Singleton
class ScreenshotCapture @Inject constructor() {

    suspend fun capture(
        context: android.content.Context,
        packageName: String,
        maxWidth: Int = 720
    ): ByteArray? {
        if (!SafetyGuard.isPackageAllowed(packageName)) return null
        val projection = ScreenCaptureService.projection ?: return null

        val wm = context.getSystemService(WindowManager::class.java)
        val metrics = DisplayMetrics().also {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(it)
        }
        val scale = maxWidth.toFloat() / metrics.widthPixels
        val w = maxWidth
        val h = (metrics.heightPixels * scale).toInt()

        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val done = CompletableDeferred<Bitmap?>()

        val display = projection.createVirtualDisplay(
            "agent-capture", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )

        reader.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * w
                val bmp = Bitmap.createBitmap(
                    w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888
                )
                bmp.copyPixelsFromBuffer(plane.buffer)
                done.complete(Bitmap.createBitmap(bmp, 0, 0, w, h))
            } finally {
                image.close()
            }
        }, Handler(Looper.getMainLooper()))

        val bitmap = withTimeoutOrNull(3_000L) { done.await() }
        display.release()
        reader.close()
        if (bitmap == null) return null

        return ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out)
            bitmap.recycle()
            out.toByteArray()
        }
    }
}
