package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Gallery ও Files app। Downloaded ভিডিও এখান থেকে খুঁজে পাওয়া যায়।
 * Package নাম ডিভাইস অনুযায়ী ভিন্ন হয় (Google Photos, Samsung Gallery ইত্যাদি)।
 */
@Singleton
class GallerySkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.apps.photos",
        "com.sec.android.gallery3d",
        "com.miui.gallery",
        "com.android.gallery3d"
    )
    override val displayName = "Gallery"

    override val screens = listOf(
        KnownScreen(
            id = "gal_photos",
            nameEn = "Photos grid",
            nameBn = "ছবি তালিকা",
            identifyingTexts = listOf("Photos", "Albums", "Recent")
        ),
        KnownScreen(
            id = "gal_album",
            nameEn = "Album / folder",
            nameBn = "ফোল্ডার",
            identifyingTexts = listOf("Download", "Downloads", "Camera")
        ),
        KnownScreen(
            id = "gal_viewer",
            nameEn = "Media viewer",
            nameBn = "মিডিয়া দেখা",
            identifyingTexts = listOf("Share", "Edit", "Delete")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "open_downloads",
            descriptionEn = "Open the Download album to find downloaded videos",
            descriptionBn = "Download album খুলে ডাউনলোড করা ভিডিও খোঁজা",
            targetHints = listOf("Download", "Downloads")
        ),
        SkillAction(
            id = "open_media",
            descriptionEn = "Open a photo or video from the grid",
            descriptionBn = "ছবি/ভিডিও খোলা",
            targetHints = listOf("video", "Video")
        ),
        SkillAction(
            id = "share_media",
            descriptionEn = "Share the open media to another app",
            descriptionBn = "খোলা মিডিয়া অন্য অ্যাপে share",
            targetHints = listOf("Share")
        ),
        SkillAction(
            id = "delete_media",
            descriptionEn = "Delete the open media",
            descriptionBn = "খোলা মিডিয়া মোছা",
            targetHints = listOf("Delete"),
            requiresConfirmation = true
        )
    )
}
