package com.aiagent.assistant.data.repository

import com.aiagent.assistant.core.knowledge.CustomSkill
import com.aiagent.assistant.core.knowledge.CustomSkillAdapter
import com.aiagent.assistant.data.local.CustomSkillDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CustomSkillRepository @Inject constructor(
    private val dao: CustomSkillDao
) {
    fun observeAll(): Flow<List<CustomSkill>> =
        dao.observeAll().map { list -> list.map { CustomSkillAdapter.toDomain(it) } }

    suspend fun allOnce(): List<CustomSkill> =
        dao.allOnce().map { CustomSkillAdapter.toDomain(it) }

    suspend fun save(skill: CustomSkill, createdAt: Long? = null): String {
        val id = skill.id.ifBlank { UUID.randomUUID().toString() }
        val now = System.currentTimeMillis()
        dao.upsert(
            CustomSkillAdapter.toEntity(
                skill.copy(id = id),
                createdAt = createdAt ?: now,
                now = now
            )
        )
        return id
    }

    suspend fun delete(id: String) = dao.delete(id)
}
