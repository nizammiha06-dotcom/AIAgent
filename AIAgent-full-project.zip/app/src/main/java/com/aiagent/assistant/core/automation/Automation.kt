package com.aiagent.assistant.core.automation

enum class TriggerType { TIME, APP_OPENED, NOTIFICATION, VOICE }

data class Automation(
    val id: String,
    val name: String,
    val triggerType: TriggerType,
    val triggerValue: String,
    val daysMask: Int,
    val goal: String,
    val enabled: Boolean,
    val lastRunAt: Long
) {
    companion object {
        const val ALL_DAYS = 127

        fun dayBit(calendarDay: Int): Int = 1 shl (calendarDay - 1) // Calendar.SUNDAY = 1
    }
}
