package com.aiagent.assistant.data.ai

enum class Protocol { OPENAI_COMPATIBLE, ANTHROPIC }

data class AiProviderConfig(
    val id: String,
    val name: String,
    val protocol: Protocol,
    val baseUrl: String,
    val model: String,
    val requiresKey: Boolean = true,
    val temperature: Float = 0.7f,
    val maxTokens: Int = 1024,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val enabled: Boolean = true,
    val supportsVision: Boolean = false
) {
    companion object {
        const val DEFAULT_SYSTEM_PROMPT =
            "You are a helpful Android AI assistant. Reply in the same language the user uses (Bangla or English). Be concise."

        fun presets(): List<AiProviderConfig> = listOf(
            AiProviderConfig("groq", "Groq", Protocol.OPENAI_COMPATIBLE,
                "https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
            AiProviderConfig("openrouter", "OpenRouter", Protocol.OPENAI_COMPATIBLE,
                "https://openrouter.ai/api/v1", "openai/gpt-4o-mini", supportsVision = true),
            AiProviderConfig("openai", "OpenAI", Protocol.OPENAI_COMPATIBLE,
                "https://api.openai.com/v1", "gpt-4o-mini", supportsVision = true),
            AiProviderConfig("anthropic", "Anthropic Claude", Protocol.ANTHROPIC,
                "https://api.anthropic.com", "claude-sonnet-4-5", supportsVision = true),
            AiProviderConfig("mistral", "Mistral", Protocol.OPENAI_COMPATIBLE,
                "https://api.mistral.ai/v1", "mistral-small-latest"),
            AiProviderConfig("together", "Together AI", Protocol.OPENAI_COMPATIBLE,
                "https://api.together.xyz/v1", "meta-llama/Llama-3.3-70B-Instruct-Turbo"),
            AiProviderConfig("deepseek", "DeepSeek", Protocol.OPENAI_COMPATIBLE,
                "https://api.deepseek.com/v1", "deepseek-chat"),
            AiProviderConfig("ollama", "Ollama (local)", Protocol.OPENAI_COMPATIBLE,
                "http://10.0.2.2:11434/v1", "llama3.2", requiresKey = false),
            AiProviderConfig("custom", "Custom OpenAI-compatible", Protocol.OPENAI_COMPATIBLE,
                "https://", "")
        )
    }
}
