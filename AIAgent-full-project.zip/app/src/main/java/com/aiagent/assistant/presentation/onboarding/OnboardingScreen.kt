package com.aiagent.assistant.presentation.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.ui.components.GradientBackground
import com.aiagent.assistant.ui.theme.Spacing
import kotlinx.coroutines.launch

private data class OnboardingPage(
    val titleBn: String,
    val titleEn: String,
    val bodyBn: String,
    val bodyEn: String
)

private val pages = listOf(
    OnboardingPage(
        "স্বাগতম", "Welcome",
        "আমি আপনার AI সহকারী। কথা বলে, লিখে বা স্ক্রিন দেখে কাজ করতে পারি।",
        "I am your AI assistant. I can help by talking, typing, or reading your screen."
    ),
    OnboardingPage(
        "অনুমতি কেন লাগে", "Why permissions",
        "অন্য অ্যাপে কাজ করতে Accessibility ও Overlay লাগে। কোনো অনুমতি ছাড়া কিছু চলবে না।",
        "Accessibility and Overlay are needed to work in other apps. Nothing runs without your permission."
    ),
    OnboardingPage(
        "নিরাপত্তা", "Safety",
        "Banking, OTP ও password screen-এ আমি কাজ করি না। Call, SMS ও download-এর আগে জিজ্ঞেস করি।",
        "I never work in banking, OTP or password screens. I ask before calls, SMS and downloads."
    )
)

@Composable
fun OnboardingScreen(
    onOpenPermissions: () -> Unit,
    onFinish: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val isLast = pagerState.currentPage == pages.lastIndex

    GradientBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = Spacing.lg),
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                val p = pages[page]
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(Spacing.lg),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(p.titleBn, style = MaterialTheme.typography.headlineMedium)
                    Text(p.titleEn, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(Spacing.md))
                    Text(p.bodyBn, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(Spacing.xs))
                    Text(
                        p.bodyEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = Spacing.lg),
                verticalArrangement = Arrangement.spacedBy(Spacing.xs)
            ) {
                if (isLast) {
                    Button(
                        onClick = { viewModel.complete(onFinish) },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("শুরু করো · Get started") }

                    TextButton(
                        onClick = {
                            viewModel.complete {
                                onOpenPermissions()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Permission Center খুলো · Open permissions") }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { viewModel.complete(onFinish) }) {
                            Text("Skip · বাদ দাও")
                        }
                        Button(onClick = {
                            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                        }) { Text("Next · পরে") }
                    }
                }
            }
        }
    }
}
