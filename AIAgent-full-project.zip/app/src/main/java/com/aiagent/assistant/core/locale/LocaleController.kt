package com.aiagent.assistant.core.locale

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import javax.inject.Inject
import javax.inject.Singleton

/** অ্যাপের ভেতরের ভাষা। "system" মানে ডিভাইসের ভাষা অনুসরণ। */
@Singleton
class LocaleController @Inject constructor() {

    fun apply(language: String) {
        val locales = when (language) {
            "bn" -> LocaleListCompat.forLanguageTags("bn")
            "en" -> LocaleListCompat.forLanguageTags("en")
            else -> LocaleListCompat.getEmptyLocaleList()
        }
        AppCompatDelegate.setApplicationLocales(locales)
    }
}
