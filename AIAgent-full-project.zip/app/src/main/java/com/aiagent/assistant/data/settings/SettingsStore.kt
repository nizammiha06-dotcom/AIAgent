package com.aiagent.assistant.data.settings

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.settingsDataStore by preferencesDataStore(name = "app_settings")

@Singleton
class SettingsStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object K {
        val APP_NAME = stringPreferencesKey("app_name")
        val ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        val WAKE_WORD = stringPreferencesKey("wake_word")
        val WAKE_ENABLED = booleanPreferencesKey("wake_enabled")
        val THEME = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val VOICE_STYLE = stringPreferencesKey("voice_style")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
        val VOICE_PITCH = floatPreferencesKey("voice_pitch")
        val CONFIRM = booleanPreferencesKey("confirm_sensitive")
        val AUTO_EXEC = booleanPreferencesKey("agent_auto_execute")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { it.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val new = transform(prefs.toSettings())
            prefs[K.APP_NAME] = new.appName
            prefs[K.ASSISTANT_NAME] = new.assistantName
            prefs[K.WAKE_WORD] = new.wakeWord
            prefs[K.WAKE_ENABLED] = new.wakeWordEnabled
            prefs[K.THEME] = new.themeMode.name
            prefs[K.LANGUAGE] = new.language
            prefs[K.VOICE_STYLE] = new.voiceStyle
            prefs[K.VOICE_SPEED] = new.voiceSpeed
            prefs[K.VOICE_PITCH] = new.voicePitch
            prefs[K.CONFIRM] = new.confirmSensitiveActions
            prefs[K.AUTO_EXEC] = new.agentAutoExecute
        }
    }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            appName = this[K.APP_NAME] ?: d.appName,
            assistantName = this[K.ASSISTANT_NAME] ?: d.assistantName,
            wakeWord = this[K.WAKE_WORD] ?: d.wakeWord,
            wakeWordEnabled = this[K.WAKE_ENABLED] ?: d.wakeWordEnabled,
            themeMode = this[K.THEME]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: d.themeMode,
            language = this[K.LANGUAGE] ?: d.language,
            voiceStyle = this[K.VOICE_STYLE] ?: d.voiceStyle,
            voiceSpeed = this[K.VOICE_SPEED] ?: d.voiceSpeed,
            voicePitch = this[K.VOICE_PITCH] ?: d.voicePitch,
            confirmSensitiveActions = this[K.CONFIRM] ?: d.confirmSensitiveActions,
            agentAutoExecute = this[K.AUTO_EXEC] ?: d.agentAutoExecute
        )
    }
}
