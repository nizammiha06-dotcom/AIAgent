package com.aiagent.assistant.presentation.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.ui.components.AnimatedOrb
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.components.GlassCard
import com.aiagent.assistant.ui.components.GradientBackground
import com.aiagent.assistant.ui.theme.Spacing
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenChat: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenAutomations: () -> Unit,
    onOpenTasks: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppDrawerContent(
                onOpenChat = { scope.launch { drawerState.close() }; onOpenChat() },
                onOpenPermissions = { scope.launch { drawerState.close() }; onOpenPermissions() },
                onOpenAutomations = { scope.launch { drawerState.close() }; onOpenAutomations() },
                onOpenTasks = { scope.launch { drawerState.close() }; onOpenTasks() },
                onOpenSettings = { scope.launch { drawerState.close() }; onOpenSettings() }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(state.assistantName) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu")
                        }
                    }
                )
            },
            bottomBar = {
                BottomNavBar(
                    selected = BottomTab.HOME,
                    onSelect = { tab ->
                        when (tab) {
                            BottomTab.HOME -> Unit
                            BottomTab.CHAT -> onOpenChat()
                            BottomTab.TASKS -> onOpenTasks()
                            BottomTab.SETTINGS -> onOpenSettings()
                        }
                    }
                )
            }
        ) { padding ->
            GradientBackground {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(Spacing.lg))

                    // Animated AI orb
                    Box(
                        modifier = Modifier.clickable { viewModel.toggleListening() },
                        contentAlignment = Alignment.Center
                    ) {
                        AnimatedOrb(size = 180.dp)
                    }

                    Spacer(Modifier.height(Spacing.md))

                    Text(
                        text = if (state.isListening) "শুনছি… · Listening" else "Tap orb to talk · কথা বলতে ট্যাপ করুন",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(Spacing.lg))

                    // Live voice button
                    GlassCard(modifier = Modifier.fillMaxWidth(0.9f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(Spacing.sm)
                        ) {
                            Icon(
                                imageVector = if (state.isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column {
                                Text("Live Voice", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Real-time voice conversation",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(Spacing.lg))

                    // Quick actions
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = Spacing.md),
                        horizontalArrangement = Arrangement.spacedBy(Spacing.xs)
                    ) {
                        items(listOf("Set alarm", "Search web", "Open YouTube", "Send SMS", "Maps")) { label ->
                            FilterChip(
                                selected = false,
                                onClick = { },
                                label = { Text(label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(Spacing.lg))

                    // Recent chats
                    Text(
                        text = "Recent chats",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = Spacing.md)
                    )
                    Spacer(Modifier.height(Spacing.xs))

                    LazyColumn(
                        contentPadding = PaddingValues(horizontal = Spacing.md),
                        verticalArrangement = Arrangement.spacedBy(Spacing.xs)
                    ) {
                        items(state.recentChats, key = { it.id }) { chat ->
                            AppCard(modifier = Modifier.clickable { onOpenChat() }) {
                                Column(modifier = Modifier.padding(Spacing.md)) {
                                    Text(chat.title, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        chat.preview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
