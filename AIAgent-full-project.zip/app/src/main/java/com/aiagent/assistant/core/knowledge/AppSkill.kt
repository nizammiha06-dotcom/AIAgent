package com.aiagent.assistant.core.knowledge

/** একটি screen-এর পরিচয়। Hint দিয়ে screen চেনা হয় (title বা কোনো unique text)। */
data class KnownScreen(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val identifyingTexts: List<String>
)

/** একটি common action-এর বর্ণনা। Planner এটি পড়ে কোন কাজ কোথায় করতে হবে জানে। */
data class SkillAction(
    val id: String,
    val descriptionEn: String,
    val descriptionBn: String,
    val targetHints: List<String>,
    val requiresConfirmation: Boolean = false
)

/**
 * প্রতিটি app-এর জন্য একটি skill।
 * Skill কোড-এ hard-coded coordinate রাখে না। শুধু text hint ও screen চেনার নিয়ম রাখে।
 */
interface AppSkill {
    val packageNames: List<String>
    val displayName: String
    val screens: List<KnownScreen>
    val actions: List<SkillAction>

    /** এই app-এ login লাগে কিনা। */
    val requiresLogin: Boolean get() = false

    /** Skill-এর জন্য ছোট নির্দেশনা (AI prompt-এ যাবে)। */
    fun promptHints(): String = buildString {
        appendLine("App: $displayName")
        appendLine("Known screens: ${screens.joinToString { it.nameEn }}")
        appendLine("Common actions:")
        actions.forEach { a ->
            appendLine("- ${a.id}: ${a.descriptionEn} (targets: ${a.targetHints.joinToString()})" +
                if (a.requiresConfirmation) " [needs confirmation]" else "")
        }
    }

    /** বর্তমান screen কোনটি তা text দেখে নির্ণয় করে। না মিললে null। */
    fun identifyScreen(visibleTexts: Collection<String>): KnownScreen? {
        val lower = visibleTexts.map { it.lowercase() }
        return screens.firstOrNull { screen ->
            screen.identifyingTexts.any { hint ->
                lower.any { it.contains(hint.lowercase()) }
            }
        }
    }
}
