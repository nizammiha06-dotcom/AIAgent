package com.aiagent.assistant.core.knowledge

import com.aiagent.assistant.data.local.CustomSkillEntity
import org.json.JSONArray
import org.json.JSONObject

/** Entity ↔ domain ↔ AppSkill রূপান্তর। JSON parse ব্যর্থ হলে খালি তালিকা। */
object CustomSkillAdapter {

    fun toDomain(e: CustomSkillEntity): CustomSkill = CustomSkill(
        id = e.id,
        displayName = e.displayName,
        packageNames = e.packageNames.split(',').map { it.trim() }.filter { it.isNotEmpty() },
        screens = parseScreens(e.screensJson),
        actions = parseActions(e.actionsJson)
    )

    fun toEntity(s: CustomSkill, createdAt: Long, now: Long): CustomSkillEntity = CustomSkillEntity(
        id = s.id,
        displayName = s.displayName,
        packageNames = s.packageNames.joinToString(","),
        screensJson = JSONArray().also { arr ->
            s.screens.forEach { sc ->
                arr.put(JSONObject()
                    .put("id", sc.id)
                    .put("nameEn", sc.nameEn)
                    .put("nameBn", sc.nameBn)
                    .put("identifyingTexts", JSONArray(sc.identifyingTexts)))
            }
        }.toString(),
        actionsJson = JSONArray().also { arr ->
            s.actions.forEach { a ->
                arr.put(JSONObject()
                    .put("id", a.id)
                    .put("descriptionEn", a.descriptionEn)
                    .put("descriptionBn", a.descriptionBn)
                    .put("targetHints", JSONArray(a.targetHints))
                    .put("requiresConfirmation", a.requiresConfirmation))
            }
        }.toString(),
        createdAt = createdAt,
        updatedAt = now
    )

    /** Planner-কে দেওয়ার জন্য AppSkill-এ রূপান্তর। */
    fun toAppSkill(s: CustomSkill): AppSkill = object : AppSkill {
        override val packageNames = s.packageNames
        override val displayName = s.displayName
        override val screens = s.screens
        override val actions = s.actions
    }

    private fun parseScreens(raw: String): List<KnownScreen> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            KnownScreen(
                id = o.getString("id"),
                nameEn = o.optString("nameEn"),
                nameBn = o.optString("nameBn"),
                identifyingTexts = jsonStrings(o.optJSONArray("identifyingTexts"))
            )
        }
    }.getOrDefault(emptyList())

    private fun parseActions(raw: String): List<SkillAction> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SkillAction(
                id = o.getString("id"),
                descriptionEn = o.optString("descriptionEn"),
                descriptionBn = o.optString("descriptionBn"),
                targetHints = jsonStrings(o.optJSONArray("targetHints")),
                requiresConfirmation = o.optBoolean("requiresConfirmation", false)
            )
        }
    }.getOrDefault(emptyList())

    private fun jsonStrings(arr: JSONArray?): List<String> =
        arr?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
}
