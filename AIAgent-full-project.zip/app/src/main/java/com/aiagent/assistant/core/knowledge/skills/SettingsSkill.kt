package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.android.settings")
    override val displayName = "Settings"

    override val screens = listOf(
        KnownScreen(
            id = "set_home",
            nameEn = "Settings home",
            nameBn = "সেটিংস হোম",
            identifyingTexts = listOf("Search settings", "Network & internet", "Connected devices")
        ),
        KnownScreen(
            id = "set_network",
            nameEn = "Network & internet",
            nameBn = "নেটওয়ার্ক ও ইন্টারনেট",
            identifyingTexts = listOf("Internet", "Wi-Fi", "Mobile network")
        ),
        KnownScreen(
            id = "set_display",
            nameEn = "Display",
            nameBn = "ডিসপ্লে",
            identifyingTexts = listOf("Dark theme", "Brightness", "Screen timeout")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "open_wifi",
            descriptionEn = "Open Wi-Fi settings",
            descriptionBn = "Wi-Fi সেটিংস খোলা",
            targetHints = listOf("Wi-Fi", "Internet")
        ),
        SkillAction(
            id = "toggle_switch",
            descriptionEn = "Turn a switch on or off (Wi-Fi, Bluetooth, Dark theme)",
            descriptionBn = "Switch চালু বা বন্ধ করা",
            targetHints = listOf("Use Wi-Fi", "Bluetooth", "Dark theme")
        ),
        SkillAction(
            id = "search_setting",
            descriptionEn = "Use the Search settings bar to find an option",
            descriptionBn = "Search settings bar দিয়ে option খোঁজা",
            targetHints = listOf("Search settings")
        )
    )
}
