package com.aiagent.assistant.presentation.debug

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.core.accessibility.AccessibilityEngine
import com.aiagent.assistant.core.accessibility.ScreenSnapshot
import com.aiagent.assistant.core.vision.VisionAnalyzer
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DebugUiState(
    val ready: Boolean = false,
    val snapshot: ScreenSnapshot? = null,
    val analysis: String = "",
    val analyzing: Boolean = false
)

@HiltViewModel
class AccessibilityDebugViewModel @Inject constructor(
    private val engine: AccessibilityEngine,
    private val vision: VisionAnalyzer
) : ViewModel() {

    private val _state = MutableStateFlow(DebugUiState())
    val state: StateFlow<DebugUiState> = _state.asStateFlow()

    fun refresh() {
        _state.value = _state.value.copy(
            ready = engine.isReady,
            snapshot = engine.currentSnapshot()
        )
    }

    fun analyze(question: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(analyzing = true, analysis = "")
            val answer = vision.describeScreen(question)
            _state.value = _state.value.copy(analyzing = false, analysis = answer)
        }
    }
}
