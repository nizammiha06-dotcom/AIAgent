package com.aiagent.assistant.presentation.chat

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.aiagent.assistant.ui.theme.Spacing

sealed interface MdBlock {
    data class Text(val value: String) : MdBlock
    data class Code(val lang: String, val code: String) : MdBlock
}

fun parseMarkdownBlocks(input: String): List<MdBlock> {
    val result = mutableListOf<MdBlock>()
    val text = StringBuilder()
    val code = StringBuilder()
    var inCode = false
    var lang = ""

    for (line in input.lines()) {
        val trimmed = line.trimStart()
        if (trimmed.startsWith("```")) {
            if (!inCode) {
                if (text.isNotBlank()) {
                    result += MdBlock.Text(text.toString().trim())
                    text.clear()
                }
                inCode = true
                lang = trimmed.removePrefix("```").trim()
                code.clear()
            } else {
                result += MdBlock.Code(lang, code.toString().trimEnd())
                inCode = false
            }
        } else if (inCode) {
            code.appendLine(line)
        } else {
            text.appendLine(line)
        }
    }
    if (inCode && code.isNotEmpty()) result += MdBlock.Code(lang, code.toString().trimEnd())
    if (text.isNotBlank()) result += MdBlock.Text(text.toString().trim())
    return result
}

/** **bold** ও `inline code` সাপোর্ট করে একটি AnnotatedString বানায়। */
fun inlineMarkdown(raw: String) = buildAnnotatedString {
    var i = 0
    while (i < raw.length) {
        when {
            raw.startsWith("**", i) -> {
                val end = raw.indexOf("**", i + 2)
                if (end > 0) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(raw.substring(i + 2, end))
                    }
                    i = end + 2
                } else {
                    append(raw[i]); i++
                }
            }
            raw[i] == '`' -> {
                val end = raw.indexOf('`', i + 1)
                if (end > 0) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x22888888))) {
                        append(raw.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(raw[i]); i++
                }
            }
            else -> { append(raw[i]); i++ }
        }
    }
}

@Composable
fun MarkdownMessage(text: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(Spacing.xs)
    ) {
        parseMarkdownBlocks(text).forEach { block ->
            when (block) {
                is MdBlock.Text -> TextBlock(block.value)
                is MdBlock.Code -> CodeBlock(block.lang, block.code)
            }
        }
    }
}

@Composable
private fun TextBlock(value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
        value.lines().forEach { raw ->
            val line = raw.trimEnd()
            when {
                line.isBlank() -> Text(" ", style = MaterialTheme.typography.bodyLarge)
                line.startsWith("### ") -> Text(
                    inlineMarkdown(line.removePrefix("### ")),
                    style = MaterialTheme.typography.titleMedium
                )
                line.startsWith("## ") -> Text(
                    inlineMarkdown(line.removePrefix("## ")),
                    style = MaterialTheme.typography.titleLarge
                )
                line.startsWith("# ") -> Text(
                    inlineMarkdown(line.removePrefix("# ")),
                    style = MaterialTheme.typography.headlineSmall
                )
                line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ") -> Row {
                    Text("•  ", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        inlineMarkdown(line.trimStart().drop(2)),
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                else -> Text(inlineMarkdown(line), style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
private fun CodeBlock(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    val muted = Color(0xFF9E9EB8)

    Surface(
        shape = MaterialTheme.shapes.small,
        color = Color(0xFF0E0E18)
    ) {
        Column(modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = lang.ifBlank { "code" },
                    style = MaterialTheme.typography.labelSmall,
                    color = muted,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = "Copy code", tint = muted)
                }
            }
            Text(
                text = code,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFEDEDF5),
                modifier = Modifier.horizontalScroll(rememberScrollState())
            )
        }
    }
}
