package com.aiagent.assistant.core.accessibility

import android.graphics.Rect

/** একটি UI element-এর হালকা, serialize-যোগ্য representation। AI-কে এটাই পাঠানো হবে। */
data class UiElement(
    val index: Int,
    val className: String,
    val text: String,
    val description: String,
    val viewId: String,
    val clickable: Boolean,
    val longClickable: Boolean,
    val editable: Boolean,
    val scrollable: Boolean,
    val checked: Boolean?,
    val enabled: Boolean,
    val bounds: Rect,
    val depth: Int
) {
    /** নাম হিসেবে যা দেখানো যায় সেটাই: text > description > viewId শেষ অংশ। */
    val label: String
        get() = text.ifBlank { description }.ifBlank { viewId.substringAfterLast('/') }

    val center: Pair<Int, Int>
        get() = bounds.centerX() to bounds.centerY()
}

data class ScreenSnapshot(
    val packageName: String,
    val capturedAt: Long,
    val elements: List<UiElement>
) {
    val isEmpty: Boolean get() = elements.isEmpty()

    /** AI prompt-এর জন্য ছোট text রূপ। */
    fun toPromptText(maxElements: Int = 120): String = buildString {
        appendLine("App: $packageName")
        appendLine("Elements (${elements.size}):")
        elements.take(maxElements).forEach { e ->
            val flags = buildList {
                if (e.clickable) add("click")
                if (e.editable) add("edit")
                if (e.scrollable) add("scroll")
                if (!e.enabled) add("disabled")
                if (e.checked == true) add("checked")
            }.joinToString(",")
            appendLine("[${e.index}] ${e.className.substringAfterLast('.')} \"${e.label.take(60)}\" ${if (flags.isNotEmpty()) "($flags)" else ""}".trimEnd())
        }
    }
}
