package com.aiagent.assistant.data.repository

import com.aiagent.assistant.core.planner.TaskPlan
import com.aiagent.assistant.data.local.TaskDao
import com.aiagent.assistant.data.local.TaskPlanEntity
import com.aiagent.assistant.data.local.TaskStepEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepository @Inject constructor(
    private val dao: TaskDao
) {
    fun observePlans(): Flow<List<TaskPlanEntity>> = dao.observePlans()
    fun observeSteps(planId: String): Flow<List<TaskStepEntity>> = dao.observeSteps(planId)

    suspend fun savePlan(plan: TaskPlan) {
        val now = System.currentTimeMillis()
        dao.upsertPlan(
            TaskPlanEntity(
                id = plan.id,
                goal = plan.goal,
                status = plan.status.name,
                createdAt = plan.createdAt,
                updatedAt = now
            )
        )
        dao.upsertSteps(
            plan.steps.map {
                TaskStepEntity(
                    id = "${plan.id}_${it.index}",
                    planId = plan.id,
                    stepIndex = it.index,
                    title = it.title,
                    app = it.app,
                    status = it.status.name,
                    message = it.message
                )
            }
        )
    }

    suspend fun delete(planId: String) = dao.deletePlan(planId)
}
