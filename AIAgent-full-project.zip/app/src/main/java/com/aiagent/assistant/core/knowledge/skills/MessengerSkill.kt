package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessengerSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.facebook.orca")
    override val displayName = "Messenger"

    override val screens = listOf(
        KnownScreen(
            id = "ms_chats",
            nameEn = "Chats list",
            nameBn = "চ্যাট তালিকা",
            identifyingTexts = listOf("Chats", "People", "Communities")
        ),
        KnownScreen(
            id = "ms_conversation",
            nameEn = "Conversation",
            nameBn = "কথোপকথন",
            identifyingTexts = listOf("Aa", "Message", "Type a message")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "open_chat",
            descriptionEn = "Open a chat by contact name",
            descriptionBn = "Contact নামে chat খোলা",
            targetHints = listOf("contact name")
        ),
        SkillAction(
            id = "type_message",
            descriptionEn = "Type text into the message field",
            descriptionBn = "Message field-এ লেখা",
            targetHints = listOf("Aa", "Type a message")
        ),
        SkillAction(
            id = "send_message",
            descriptionEn = "Tap Send to deliver the message",
            descriptionBn = "বার্তা পাঠাতে Send চাপা",
            targetHints = listOf("Send"),
            requiresConfirmation = true
        )
    )
}
