package com.aiagent.assistant.presentation.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.data.settings.OnboardingStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val store: OnboardingStore
) : ViewModel() {

    fun complete(onDone: () -> Unit) {
        viewModelScope.launch {
            store.setCompleted()
            onDone()
        }
    }
}
