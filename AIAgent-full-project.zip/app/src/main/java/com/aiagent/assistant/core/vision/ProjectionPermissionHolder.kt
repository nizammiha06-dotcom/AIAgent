package com.aiagent.assistant.core.vision

import android.content.Intent
import javax.inject.Inject
import javax.inject.Singleton

/** MediaProjection-এর user অনুমতি (resultCode + Intent) মেমোরিতে রাখে। App বন্ধ হলে মুছে যায়। */
@Singleton
class ProjectionPermissionHolder @Inject constructor() {

    @Volatile private var resultCode: Int? = null
    @Volatile private var data: Intent? = null

    fun store(resultCode: Int, data: Intent) {
        this.resultCode = resultCode
        this.data = Intent(data)
    }

    fun hasPermission(): Boolean = resultCode != null && data != null

    fun resultCode(): Int = resultCode ?: 0
    fun data(): Intent? = data?.let { Intent(it) }

    fun clear() {
        resultCode = null
        data = null
    }
}
