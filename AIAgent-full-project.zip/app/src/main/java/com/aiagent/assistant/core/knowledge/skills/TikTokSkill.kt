package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

/**
 * TikTok: শুধু search ও খোলা পর্যন্ত। Download বা watermark বাদ দেওয়ার কোনো action এখানে নেই।
 */
@Singleton
class TikTokSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    override val displayName = "TikTok"

    override val screens = listOf(
        KnownScreen(
            id = "tt_feed",
            nameEn = "For You feed",
            nameBn = "ফর ইউ ফিড",
            identifyingTexts = listOf("For You", "Following", "Friends")
        ),
        KnownScreen(
            id = "tt_search",
            nameEn = "Search",
            nameBn = "সার্চ",
            identifyingTexts = listOf("Search", "Accounts", "Videos")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "search",
            descriptionEn = "Open search and type a query",
            descriptionBn = "সার্চে গিয়ে query লেখা",
            targetHints = listOf("Search")
        ),
        SkillAction(
            id = "open_video",
            descriptionEn = "Open a video from search results",
            descriptionBn = "সার্চ ফলাফল থেকে ভিডিও খোলা",
            targetHints = listOf("Videos")
        )
    )
}
