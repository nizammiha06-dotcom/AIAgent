package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WhatsAppSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.whatsapp", "com.whatsapp.w4b")
    override val displayName = "WhatsApp"

    override val screens = listOf(
        KnownScreen(
            id = "wa_chats",
            nameEn = "Chats list",
            nameBn = "চ্যাট তালিকা",
            identifyingTexts = listOf("Chats", "Updates", "Communities")
        ),
        KnownScreen(
            id = "wa_conversation",
            nameEn = "Conversation",
            nameBn = "কথোপকথন",
            identifyingTexts = listOf("Type a message", "Message")
        ),
        KnownScreen(
            id = "wa_search",
            nameEn = "Search",
            nameBn = "সার্চ",
            identifyingTexts = listOf("Search")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "open_chat",
            descriptionEn = "Open a chat by contact name from the chats list",
            descriptionBn = "চ্যাট তালিকা থেকে contact নামে chat খোলা",
            targetHints = listOf("contact name")
        ),
        SkillAction(
            id = "type_message",
            descriptionEn = "Type text into the 'Type a message' field",
            descriptionBn = "'Type a message' field-এ লেখা",
            targetHints = listOf("Type a message", "Message")
        ),
        SkillAction(
            id = "send_message",
            descriptionEn = "Tap the send button to send the typed message",
            descriptionBn = "Send বাটনে চাপ দিয়ে বার্তা পাঠানো",
            targetHints = listOf("Send"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "search_chat",
            descriptionEn = "Open search to find a chat or message",
            descriptionBn = "সার্চ খুলে chat বা বার্তা খোঁজা",
            targetHints = listOf("Search")
        )
    )
}
