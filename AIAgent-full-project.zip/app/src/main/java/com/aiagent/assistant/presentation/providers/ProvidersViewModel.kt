package com.aiagent.assistant.presentation.providers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aiagent.assistant.data.ai.AiClient
import com.aiagent.assistant.data.ai.AiProviderConfig
import com.aiagent.assistant.data.ai.SecureProviderStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProvidersUiState(
    val providers: List<AiProviderConfig> = emptyList(),
    val defaultId: String? = null,
    val backupId: String? = null
)

@HiltViewModel
class ProvidersViewModel @Inject constructor(
    private val store: SecureProviderStore,
    private val client: AiClient
) : ViewModel() {

    private val _state = MutableStateFlow(load())
    val state: StateFlow<ProvidersUiState> = _state.asStateFlow()

    private val _testResult = MutableStateFlow<String?>(null)
    val testResult: StateFlow<String?> = _testResult.asStateFlow()

    private fun load() = ProvidersUiState(
        providers = store.getProviders(),
        defaultId = store.defaultId(),
        backupId = store.backupId()
    )

    private fun refresh() {
        _state.value = load()
    }

    fun apiKeyFor(id: String): String = store.getApiKey(id).orEmpty()

    fun save(config: AiProviderConfig, apiKey: String) {
        store.saveProvider(config, apiKey)
        // Default না থাকলে প্রথম enabled provider-কে default করো
        if (store.defaultId() == null && config.enabled) store.setDefaultId(config.id)
        refresh()
    }

    fun delete(id: String) {
        store.deleteProvider(id)
        refresh()
    }

    fun setDefault(id: String) {
        store.setDefaultId(id)
        refresh()
    }

    fun setBackup(id: String) {
        store.setBackupId(id)
        refresh()
    }

    fun clearTest() {
        _testResult.value = null
    }

    fun test(config: AiProviderConfig, apiKey: String) {
        viewModelScope.launch {
            _testResult.value = "Testing… · পরীক্ষা চলছে"
            _testResult.value = try {
                val reply = client.ping(config, apiKey.ifBlank { store.getApiKey(config.id) })
                "✅ Connected · উত্তর: ${reply.take(60)}"
            } catch (e: Exception) {
                "❌ ব্যর্থ: ${e.message ?: "Unknown error"}"
            }
        }
    }
}
