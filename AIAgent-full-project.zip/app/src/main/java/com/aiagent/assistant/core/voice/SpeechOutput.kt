package com.aiagent.assistant.core.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** ভাষা setting ("bn", "en", "system") কে language tag-এ রূপান্তর। */
fun languageTag(setting: String): String = when (setting) {
    "bn" -> "bn-BD"
    "en" -> "en-US"
    else -> Locale.getDefault().toLanguageTag()
}

/**
 * TextToSpeech wrapper।
 * Male/female আসল voice বদলানোর বদলে pitch দিয়ে approximate করা হয়েছে।
 * ভবিষ্যতে TextToSpeech.getVoices() দিয়ে আসল voice বাছা যাবে।
 */
class SpeechOutput(context: Context) {

    var onDone: (() -> Unit)? = null
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { onDone?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { onDone?.invoke() }
        })
    }

    /** Speak সফলভাবে শুরু হলে true। TTS প্রস্তুত না থাকলে false। */
    fun speak(text: String, languageTag: String, style: String, speed: Float, pitch: Float): Boolean {
        if (!ready) return false
        tts.language = Locale.forLanguageTag(languageTag)
        tts.setSpeechRate(speed)
        tts.setPitch(pitch * stylePitch(style))
        return tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt-${System.nanoTime()}") ==
            TextToSpeech.SUCCESS
    }

    fun stop() { tts.stop() }

    fun shutdown() { tts.shutdown() }

    private fun stylePitch(style: String): Float = when (style) {
        "child" -> 1.35f
        "robot" -> 0.85f
        "deep" -> 0.7f
        "soft" -> 0.95f
        "male" -> 0.85f
        else -> 1f
    }
}
