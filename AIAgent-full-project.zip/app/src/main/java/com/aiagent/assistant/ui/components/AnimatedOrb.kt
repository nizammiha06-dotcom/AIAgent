package com.aiagent.assistant.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aiagent.assistant.ui.theme.AppTheme

/** AI orb: ধীরে pulse করে, gradient ঘোরে। পরে voice level দিয়ে amplitude বদলানো যাবে। */
@Composable
fun AnimatedOrb(
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000)
        ),
        label = "rotation"
    )

    val extra = AppTheme.extra

    Canvas(modifier = modifier.size(size)) {
        val radius = (this.size.minDimension / 2f) * pulse
        val brush = Brush.sweepGradient(
            colors = listOf(
                extra.gradientStart,
                extra.gradientMid,
                extra.gradientEnd,
                extra.gradientStart
            ),
            center = center
        )
        rotate(rotation) {
            drawCircle(brush = brush, radius = radius)
        }
        drawCircle(
            color = Color.White.copy(alpha = 0.10f),
            radius = radius * 0.55f,
            center = center
        )
    }
}
