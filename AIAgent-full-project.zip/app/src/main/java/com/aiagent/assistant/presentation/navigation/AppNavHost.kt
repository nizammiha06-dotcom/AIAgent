package com.aiagent.assistant.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.aiagent.assistant.core.knowledge.CustomSkill
import com.aiagent.assistant.data.repository.CustomSkillRepository
import com.aiagent.assistant.presentation.automations.AutomationsScreen
import com.aiagent.assistant.presentation.chat.ChatScreen
import com.aiagent.assistant.presentation.customskill.CustomSkillEditorScreen
import com.aiagent.assistant.presentation.customskill.CustomSkillListScreen
import com.aiagent.assistant.presentation.debug.AccessibilityDebugScreen
import com.aiagent.assistant.presentation.home.HomeScreen
import com.aiagent.assistant.presentation.onboarding.OnboardingScreen
import com.aiagent.assistant.presentation.permissions.PermissionCenterScreen
import com.aiagent.assistant.presentation.providers.ProvidersScreen
import com.aiagent.assistant.presentation.settings.SettingsScreen
import com.aiagent.assistant.presentation.tasks.TasksScreen
import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@HiltViewModel
class SkillLookupViewModel @Inject constructor(
    private val repo: CustomSkillRepository
) : ViewModel() {
    suspend fun find(id: String): CustomSkill? = repo.allOnce().firstOrNull { it.id == id }
}

@Composable
fun AppNavHost(
    navController: NavHostController,
    startDestination: String = Screen.Home.route
) {
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onOpenPermissions = {
                    navController.navigate(Screen.Permissions.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                },
                onFinish = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Home.route) {
            HomeScreen(
                onOpenChat = { navController.navigate(chatRoute()) },
                onOpenSettings = { navController.navigate(Screen.Settings.route) },
                onOpenPermissions = { navController.navigate(Screen.Permissions.route) },
                onOpenAutomations = { navController.navigate(Screen.Automations.route) },
                onOpenTasks = { navController.navigate(Screen.Tasks.route) }
            )
        }

        composable(
            route = Screen.Chat.route,
            arguments = listOf(
                navArgument("chatId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) {
            ChatScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenPermissions = { navController.navigate(Screen.Permissions.route) },
                onOpenProviders = { navController.navigate(Screen.Providers.route) },
                onOpenDebug = { navController.navigate(Screen.Debug.route) },
                onOpenCustomSkills = { navController.navigate(Screen.CustomSkills.route) }
            )
        }

        composable(Screen.Permissions.route) {
            PermissionCenterScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Providers.route) {
            ProvidersScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Debug.route) {
            AccessibilityDebugScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Tasks.route) {
            TasksScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Automations.route) {
            AutomationsScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.CustomSkills.route) {
            CustomSkillListScreen(
                onBack = { navController.popBackStack() },
                onAdd = { navController.navigate(customSkillEditorRoute()) },
                onEdit = { id -> navController.navigate(customSkillEditorRoute(id)) }
            )
        }

        composable(
            route = Screen.CustomSkillEditor.route,
            arguments = listOf(
                navArgument("skillId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                }
            )
        ) { entry ->
            val skillId = entry.arguments?.getString("skillId")
            val lookup: SkillLookupViewModel = hiltViewModel()
            val existing by produceState<CustomSkill?>(initialValue = null, skillId) {
                value = skillId?.let { lookup.find(it) }
            }
            CustomSkillEditorScreen(
                skillId = skillId,
                existing = existing,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
