package com.aiagent.assistant.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

/** Custom token, যেগুলো Material colorScheme-এ নেই (gradient, glass ইত্যাদি)। */
data class AppExtraColors(
    val gradientStart: Color,
    val gradientMid: Color,
    val gradientEnd: Color,
    val glass: Color,
    val glassBorder: Color,
    val success: Color,
    val warning: Color
)

val LocalAppExtraColors = staticCompositionLocalOf {
    AppExtraColors(
        gradientStart = GradientStart,
        gradientMid = GradientMid,
        gradientEnd = GradientEnd,
        glass = GlassWhite,
        glassBorder = GlassBorder,
        success = SuccessGreen,
        warning = WarningOrange
    )
}

private val DarkColors = darkColorScheme(
    primary = PrimaryPurpleDark,
    secondary = SecondaryCyanDark,
    tertiary = AccentPink,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceVariant = DarkSurfaceVariant,
    onBackground = DarkOnSurface,
    onSurface = DarkOnSurface,
    onSurfaceVariant = DarkOnSurfaceVariant,
    error = ErrorRed
)

private val LightColors = lightColorScheme(
    primary = PrimaryPurple,
    secondary = SecondaryCyan,
    tertiary = AccentPink,
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightSurfaceVariant,
    onBackground = LightOnSurface,
    onSurface = LightOnSurface,
    onSurfaceVariant = LightOnSurfaceVariant,
    error = ErrorRed
)

private val DarkExtra = AppExtraColors(
    gradientStart = GradientStart,
    gradientMid = GradientMid,
    gradientEnd = GradientEnd,
    glass = GlassWhite,
    glassBorder = GlassBorder,
    success = SuccessGreen,
    warning = WarningOrange
)

private val LightExtra = DarkExtra.copy(glass = Color(0x1A000000), glassBorder = Color(0x1F000000))

object AppTheme {
    val extra: AppExtraColors
        @Composable get() = LocalAppExtraColors.current
}

@Composable
fun AIAgentTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    CompositionLocalProvider(
        LocalAppExtraColors provides if (darkTheme) DarkExtra else LightExtra
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
