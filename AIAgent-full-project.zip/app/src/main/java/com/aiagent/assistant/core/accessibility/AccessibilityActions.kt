package com.aiagent.assistant.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume

sealed interface ActionResult {
    data object Ok : ActionResult
    data class Failed(val reason: String) : ActionResult
}

/** সব low-level action। প্রতিটি suspend, তাই ExecutionEngine এগুলো ধারাবাহিকভাবে চালায়। */
@Singleton
class AccessibilityActions @Inject constructor() {

    fun clickElement(service: AccessibilityService, element: UiElement): ActionResult {
        // Node-এ সরাসরি click, না হলে coordinates-এ tap
        val node = findNode(service, element)
        if (node != null && node.isClickable) {
            val ok = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            return if (ok) ActionResult.Ok else ActionResult.Failed("Click ব্যর্থ")
        }
        return ActionResult.Failed("Clickable node পাওয়া যায়নি")
            .takeIf { node == null }
            ?: tap(service, element.center.first.toFloat(), element.center.second.toFloat())
    }

    fun longPressElement(service: AccessibilityService, element: UiElement): ActionResult {
        val node = findNode(service, element)
        if (node != null && node.isLongClickable) {
            return if (node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK))
                ActionResult.Ok else ActionResult.Failed("Long press ব্যর্থ")
        }
        return gesture(service, element.center.first.toFloat(), element.center.second.toFloat(), 700L)
    }

    fun typeInto(service: AccessibilityService, element: UiElement, text: String): ActionResult {
        if (!SafetyGuard.isFieldSafe(element)) {
            return ActionResult.Failed("এই field-এ লেখা নিরাপদ নয় (password/OTP সন্দেহ)")
        }
        val node = findNode(service, element) ?: return ActionResult.Failed("Input field পাওয়া যায়নি")
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args))
            ActionResult.Ok else ActionResult.Failed("Text বসানো যায়নি")
    }

    fun scroll(service: AccessibilityService, forward: Boolean): ActionResult {
        val root = service.rootInActiveWindow ?: return ActionResult.Failed("Screen নেই")
        val scrollable = findFirstScrollable(root)
        if (scrollable != null) {
            val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            return if (scrollable.performAction(action)) ActionResult.Ok
            else ActionResult.Failed("Scroll ব্যর্থ")
        }
        // Scrollable node না থাকলে screen-এর মাঝে swipe
        val (w, h) = screenSize(service)
        val midX = w / 2f
        return if (forward) swipe(service, midX, h * 0.75f, midX, h * 0.25f, 350L)
        else swipe(service, midX, h * 0.25f, midX, h * 0.75f, 350L)
    }

    fun swipe(service: AccessibilityService, x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long): ActionResult {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatch(service, path, durationMs)
    }

    fun tap(service: AccessibilityService, x: Float, y: Float): ActionResult {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        return dispatch(service, path, 60L)
    }

    private fun gesture(service: AccessibilityService, x: Float, y: Float, durationMs: Long): ActionResult {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        return dispatch(service, path, durationMs)
    }

    fun back(service: AccessibilityService): ActionResult =
        if (service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) ActionResult.Ok
        else ActionResult.Failed("Back ব্যর্থ")

    fun home(service: AccessibilityService): ActionResult =
        if (service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) ActionResult.Ok
        else ActionResult.Failed("Home ব্যর্থ")

    /** Element-কে নতুন করে খুঁজে বের করে (snapshot পুরোনো হলে bounds দিয়ে মেলানো হয়)। */
    private fun findNode(service: AccessibilityService, element: UiElement): AccessibilityNodeInfo? {
        val root = service.rootInActiveWindow ?: return null
        return findByBounds(root, element.bounds)
    }

    private fun findByBounds(node: AccessibilityNodeInfo, target: android.graphics.Rect): AccessibilityNodeInfo? {
        val r = android.graphics.Rect().also { node.getBoundsInScreen(it) }
        if (r == target) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findByBounds(child, target)?.let { return it }
        }
        return null
    }

    private fun findFirstScrollable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findFirstScrollable(child)?.let { return it }
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun screenSize(service: AccessibilityService): Pair<Float, Float> {
        val dm = service.resources.displayMetrics
        return dm.widthPixels.toFloat() to dm.heightPixels.toFloat()
    }

    private fun dispatch(service: AccessibilityService, path: Path, durationMs: Long): ActionResult {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        // Gesture সাধারণত async; এখানে সফলভাবে dispatch হওয়াকে সফল ধরা হয়
        return if (service.dispatchGesture(gesture, null, null)) ActionResult.Ok
        else ActionResult.Failed("Gesture dispatch ব্যর্থ")
    }
}
