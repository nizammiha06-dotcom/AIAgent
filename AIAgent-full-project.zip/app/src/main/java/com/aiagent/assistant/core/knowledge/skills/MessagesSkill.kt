package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MessagesSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.android.mms"
    )
    override val displayName = "Messages"

    override val screens = listOf(
        KnownScreen(
            id = "msg_list",
            nameEn = "Conversations list",
            nameBn = "মেসেজ তালিকা",
            identifyingTexts = listOf("Start chat", "Conversations", "Messages")
        ),
        KnownScreen(
            id = "msg_thread",
            nameEn = "Message thread",
            nameBn = "মেসেজ থ্রেড",
            identifyingTexts = listOf("Text message", "RCS message", "Send SMS")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "start_chat",
            descriptionEn = "Tap Start chat to write a new message",
            descriptionBn = "নতুন মেসেজ লিখতে Start chat চাপা",
            targetHints = listOf("Start chat", "New message")
        ),
        SkillAction(
            id = "type_sms",
            descriptionEn = "Type the message text",
            descriptionBn = "মেসেজ লেখা",
            targetHints = listOf("Text message", "RCS message")
        ),
        SkillAction(
            id = "send_sms",
            descriptionEn = "Tap the send button to send the SMS",
            descriptionBn = "SMS পাঠাতে send বাটনে চাপা",
            targetHints = listOf("Send"),
            requiresConfirmation = true
        )
    )
}
