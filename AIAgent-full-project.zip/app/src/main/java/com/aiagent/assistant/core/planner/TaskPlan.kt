package com.aiagent.assistant.core.planner

import com.aiagent.assistant.core.accessibility.AgentAction

enum class StepStatus { PENDING, RUNNING, DONE, FAILED, SKIPPED }

enum class PlanStatus { DRAFT, CONFIRMED, RUNNING, DONE, FAILED, CANCELLED }

/** একটি plan-এর একটি ধাপ। */
data class PlanStep(
    val index: Int,
    val title: String,
    val app: String?,               // skill-এর displayName, না থাকলে null
    val actions: List<AgentAction>,
    val needsConfirmation: Boolean,
    val status: StepStatus = StepStatus.PENDING,
    val message: String = ""
)

data class TaskPlan(
    val id: String,
    val goal: String,
    val steps: List<PlanStep>,
    val status: PlanStatus = PlanStatus.DRAFT,
    val createdAt: Long = System.currentTimeMillis()
)
