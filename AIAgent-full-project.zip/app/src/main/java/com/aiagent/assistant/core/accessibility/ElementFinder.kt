package com.aiagent.assistant.core.accessibility

import javax.inject.Inject
import javax.inject.Singleton

/** নাম বা text দিয়ে element খোঁজে। প্রথমে exact, তারপর contains, তারপর token match। */
@Singleton
class ElementFinder @Inject constructor() {

    fun find(snapshot: ScreenSnapshot, query: String, onlyClickable: Boolean = false): UiElement? {
        val q = normalize(query)
        if (q.isEmpty()) return null
        val pool = snapshot.elements.filter { !onlyClickable || it.clickable || it.editable }

        pool.firstOrNull { normalize(it.label) == q }?.let { return it }
        pool.firstOrNull { normalize(it.label).contains(q) }?.let { return it }
        pool.firstOrNull { normalize(it.description).contains(q) }?.let { return it }

        val tokens = q.split(' ').filter { it.length > 1 }
        return pool.maxByOrNull { e ->
            val target = normalize(e.label + " " + e.description)
            tokens.count { target.contains(it) }
        }?.takeIf { e ->
            val target = normalize(e.label + " " + e.description)
            tokens.any { target.contains(it) }
        }
    }

    private fun normalize(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()
}
