package com.aiagent.assistant.core.permissions

enum class PermissionKind { RUNTIME, SPECIAL, PROJECTION }

enum class PermissionId(
    val kind: PermissionKind,
    val critical: Boolean,
    val titleEn: String,
    val titleBn: String,
    val reasonEn: String,
    val reasonBn: String
) {
    ACCESSIBILITY(
        PermissionKind.SPECIAL, true,
        "Accessibility Service", "অ্যাক্সেসিবিলিটি সার্ভিস",
        "Read other apps' screens, find buttons and fields, then click, scroll, swipe or type.",
        "অন্য অ্যাপের screen পড়া, button/field চেনা এবং click, scroll, swipe বা type করা।"
    ),
    OVERLAY(
        PermissionKind.SPECIAL, true,
        "Display over other apps", "অন্য অ্যাপের উপরে দেখানো",
        "Show the floating assistant bubble and quick action panel while you use other apps.",
        "অন্য অ্যাপ ব্যবহারের সময় floating bubble ও quick action panel দেখানো।"
    ),
    NOTIFICATION_LISTENER(
        PermissionKind.SPECIAL, true,
        "Notification Access", "Notification অ্যাক্সেস",
        "Read and reply to notifications from WhatsApp, Messenger, Instagram and others.",
        "WhatsApp, Messenger, Instagram সহ সব notification পড়া ও reply করা।"
    ),
    BATTERY_OPTIMIZATION(
        PermissionKind.SPECIAL, true,
        "Battery Optimization Exemption", "ব্যাটারি অপ্টিমাইজেশন বাদ",
        "Keep the agent, alarms and voice listening running in Doze and sleep mode.",
        "Doze ও sleep মোডেও agent, alarm ও voice listening চালু রাখা।"
    ),
    SCREEN_CAPTURE(
        PermissionKind.PROJECTION, false,
        "Screen capture", "স্ক্রিন ক্যাপচার",
        "Take screenshots of the current screen so the assistant can read it when accessibility is not enough. Asked each time you start it.",
        "Accessibility যথেষ্ট না হলে screenshot নিয়ে screen বোঝা। প্রতিবার চালুর সময় জিজ্ঞেস করা হবে।"
    ),
    USAGE_ACCESS(
        PermissionKind.SPECIAL, false,
        "Usage Access", "অ্যাপ ব্যবহারের তথ্য",
        "Installed app list, app usage info and app open/close automation.",
        "ইনস্টল করা অ্যাপের তালিকা, ব্যবহারের তথ্য ও app open/close automation।"
    ),
    EXACT_ALARM(
        PermissionKind.SPECIAL, false,
        "Exact Alarms", "সঠিক সময়ের অ্যালার্ম",
        "Make reminders and alarms ring at the exact time.",
        "Reminder ও alarm ঠিক সময়ে বাজানো।"
    ),
    INSTALL_UNKNOWN_APPS(
        PermissionKind.SPECIAL, false,
        "Install Unknown Apps", "অজানা অ্যাপ ইনস্টল",
        "Only to guide an APK install when you ask for it. Never installs without your approval.",
        "শুধু আপনি চাইলে APK ইনস্টল guide করার জন্য। আপনার অনুমোদন ছাড়া কিছু ইনস্টল হবে না।"
    ),
    MICROPHONE(
        PermissionKind.RUNTIME, false,
        "Microphone", "মাইক্রোফোন",
        "Voice commands, live conversation and wake word listening.",
        "Voice command, live conversation ও wake word শোনা।"
    ),
    NOTIFICATIONS(
        PermissionKind.RUNTIME, false,
        "Post Notifications", "Notification দেখানো",
        "Show the agent's persistent notification and task updates.",
        "Agent-এর persistent notification ও task update দেখানো।"
    ),
    MEDIA_STORAGE(
        PermissionKind.RUNTIME, false,
        "Photos, Videos & Audio", "ছবি, ভিডিও ও অডিও",
        "Read gallery and downloaded media, and save exported files.",
        "Gallery ও download করা media পড়া এবং export করা ফাইল save করা।"
    ),
    CAMERA(
        PermissionKind.RUNTIME, false,
        "Camera", "ক্যামেরা",
        "Photo/video capture, QR/barcode scan and vision-based screen help.",
        "ছবি/ভিডিও তোলা, QR/barcode scan ও vision-based সাহায্য।"
    ),
    CONTACTS(
        PermissionKind.RUNTIME, false,
        "Contacts", "কন্টাক্ট",
        "Search contacts, then start a call or draft an SMS.",
        "Contact খোঁজা, তারপর call বা SMS draft শুরু করা।"
    ),
    PHONE(
        PermissionKind.RUNTIME, false,
        "Phone", "ফোন",
        "Start calls and detect call state.",
        "Call শুরু করা ও call-এর অবস্থা বোঝা।"
    ),
    SMS(
        PermissionKind.RUNTIME, false,
        "SMS", "এসএমএস",
        "Read SMS, draft messages and send them after your confirmation.",
        "SMS পড়া, draft করা এবং আপনার confirmation-এর পরে পাঠানো।"
    ),
    CALENDAR(
        PermissionKind.RUNTIME, false,
        "Calendar", "ক্যালেন্ডার",
        "Create, read, update and delete calendar events.",
        "Event তৈরি, পড়া, পরিবর্তন ও মুছে ফেলা।"
    ),
    LOCATION(
        PermissionKind.RUNTIME, false,
        "Location", "লোকেশন",
        "Current location, Google Maps navigation and nearby search.",
        "বর্তমান লোকেশন, Google Maps navigation ও কাছের জায়গা খোঁজা।"
    ),
    BACKGROUND_LOCATION(
        PermissionKind.RUNTIME, false,
        "Background Location", "ব্যাকগ্রাউন্ড লোকেশন",
        "Location automations and geofencing while the app is closed. Enable Location first.",
        "অ্যাপ বন্ধ থাকলেও location-based automation ও geofencing। আগে Location চালু করুন।"
    ),
    BLUETOOTH(
        PermissionKind.RUNTIME, false,
        "Nearby Devices (Bluetooth)", "কাছের ডিভাইস (Bluetooth)",
        "Scan, connect and disconnect Bluetooth devices.",
        "Bluetooth ডিভাইস scan, connect ও disconnect করা।"
    )
}
