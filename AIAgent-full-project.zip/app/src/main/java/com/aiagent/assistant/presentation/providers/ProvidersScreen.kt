package com.aiagent.assistant.presentation.providers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.data.ai.AiProviderConfig
import com.aiagent.assistant.data.ai.Protocol
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.theme.Spacing
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProvidersScreen(
    onBack: () -> Unit,
    viewModel: ProvidersViewModel = hiltViewModel()
) {
    val ui by viewModel.state.collectAsState()
    var editing by remember { mutableStateOf<AiProviderConfig?>(null) }
    var editingKey by remember { mutableStateOf("") }
    var showPresets by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Providers") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showPresets = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add provider")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            if (ui.providers.isEmpty()) {
                item {
                    Text(
                        "কোনো provider নেই। + চাপো, তারপর API key দিয়ে যোগ করো।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(ui.providers, key = { it.id }) { p ->
                ProviderCard(
                    config = p,
                    isDefault = p.id == ui.defaultId,
                    isBackup = p.id == ui.backupId,
                    onEdit = {
                        editingKey = viewModel.apiKeyFor(p.id)
                        viewModel.clearTest()
                        editing = p
                    },
                    onDefault = { viewModel.setDefault(p.id) },
                    onBackup = { viewModel.setBackup(p.id) },
                    onDelete = { viewModel.delete(p.id) }
                )
            }
        }
    }

    if (showPresets) {
        AlertDialog(
            onDismissRequest = { showPresets = false },
            title = { Text("Provider বেছে নাও") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
                    AiProviderConfig.presets().forEach { preset ->
                        TextButton(onClick = {
                            showPresets = false
                            editingKey = ""
                            viewModel.clearTest()
                            editing = preset.copy(id = UUID.randomUUID().toString())
                        }) { Text(preset.name) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showPresets = false }) { Text("Cancel") } }
        )
    }

    editing?.let { target ->
        key(target.id) {
            ProviderEditor(
                initial = target,
                initialKey = editingKey,
                testResult = viewModel.testResult.collectAsState().value,
                onTest = { cfg, k -> viewModel.test(cfg, k) },
                onSave = { cfg, k ->
                    viewModel.save(cfg, k)
                    editing = null
                },
                onDismiss = {
                    viewModel.clearTest()
                    editing = null
                }
            )
        }
    }
}

@Composable
private fun ProviderCard(
    config: AiProviderConfig,
    isDefault: Boolean,
    isBackup: Boolean,
    onEdit: () -> Unit,
    onDefault: () -> Unit,
    onBackup: () -> Unit,
    onDelete: () -> Unit
) {
    AppCard {
        Column(Modifier.padding(Spacing.md)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    config.name,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                if (isDefault) {
                    Text("DEFAULT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(Spacing.xs))
                }
                if (isBackup) {
                    Text("BACKUP", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
                }
            }
            Text(
                "${config.model} · ${if (config.enabled) "enabled" else "disabled"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
                TextButton(onClick = onDefault) { Text("Default") }
                TextButton(onClick = onBackup) { Text("Backup") }
                TextButton(onClick = onEdit) { Text("Edit") }
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProviderEditor(
    initial: AiProviderConfig,
    initialKey: String,
    testResult: String?,
    onTest: (AiProviderConfig, String) -> Unit,
    onSave: (AiProviderConfig, String) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var protocol by remember { mutableStateOf(initial.protocol) }
    var baseUrl by remember { mutableStateOf(initial.baseUrl) }
    var model by remember { mutableStateOf(initial.model) }
    var apiKey by remember { mutableStateOf(initialKey) }
    var temperature by remember { mutableStateOf(initial.temperature.toString()) }
    var maxTokens by remember { mutableStateOf(initial.maxTokens.toString()) }
    var systemPrompt by remember { mutableStateOf(initial.systemPrompt) }
    var enabled by remember { mutableStateOf(initial.enabled) }
    var supportsVision by remember { mutableStateOf(initial.supportsVision) }

    fun buildConfig() = AiProviderConfig(
        id = initial.id,
        name = name.trim().ifBlank { "Provider" },
        protocol = protocol,
        baseUrl = baseUrl.trim(),
        model = model.trim(),
        requiresKey = initial.requiresKey,
        temperature = temperature.toFloatOrNull()?.coerceIn(0f, 2f) ?: 0.7f,
        maxTokens = maxTokens.toIntOrNull()?.coerceIn(16, 8192) ?: 1024,
        systemPrompt = systemPrompt.ifBlank { AiProviderConfig.DEFAULT_SYSTEM_PROMPT },
        supportsVision = supportsVision,
        enabled = enabled
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Provider সম্পাদনা") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(Spacing.xs)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(Spacing.xs)) {
                    AssistChip(
                        onClick = { protocol = Protocol.OPENAI_COMPATIBLE },
                        label = { Text(if (protocol == Protocol.OPENAI_COMPATIBLE) "✓ OpenAI-style" else "OpenAI-style") }
                    )
                    AssistChip(
                        onClick = { protocol = Protocol.ANTHROPIC },
                        label = { Text(if (protocol == Protocol.ANTHROPIC) "✓ Anthropic" else "Anthropic") }
                    )
                }
                OutlinedTextField(value = baseUrl, onValueChange = { baseUrl = it }, label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (initial.requiresKey) {
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text("API key") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enabled", modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { enabled = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Vision (ছবি বোঝে)", modifier = Modifier.weight(1f))
                    Switch(checked = supportsVision, onCheckedChange = { supportsVision = it })
                }
                OutlinedTextField(value = temperature, onValueChange = { temperature = it }, label = { Text("Temperature (0–2)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = maxTokens, onValueChange = { maxTokens = it }, label = { Text("Max tokens") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = systemPrompt, onValueChange = { systemPrompt = it }, label = { Text("System prompt") }, modifier = Modifier.fillMaxWidth(), maxLines = 6)

                TextButton(onClick = { onTest(buildConfig(), apiKey) }) { Text("Test connection") }
                testResult?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(buildConfig(), apiKey.trim()) }) { Text("Save · সেভ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel · বাতিল") }
        }
    )
}
