package com.aiagent.assistant.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val PrimaryPurple = Color(0xFF7C4DFF)
val PrimaryPurpleDark = Color(0xFFB39DFF)
val SecondaryCyan = Color(0xFF00E5FF)
val SecondaryCyanDark = Color(0xFF00B8D4)
val AccentPink = Color(0xFFFF4081)

// Light
val LightBackground = Color(0xFFF7F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1A1A2E)
val LightSurfaceVariant = Color(0xFFEDEBF7)
val LightOnSurfaceVariant = Color(0xFF5C5A70)

// Dark
val DarkBackground = Color(0xFF0B0B14)
val DarkSurface = Color(0xFF14141F)
val DarkOnSurface = Color(0xFFEDEDF5)
val DarkSurfaceVariant = Color(0xFF1E1E2D)
val DarkOnSurfaceVariant = Color(0xFFA6A4BD)

// Status
val SuccessGreen = Color(0xFF00C853)
val WarningOrange = Color(0xFFFFAB00)
val ErrorRed = Color(0xFFFF5252)

// Glass & gradient
val GlassWhite = Color(0x33FFFFFF)
val GlassBorder = Color(0x40FFFFFF)
val GradientStart = Color(0xFF7C4DFF)
val GradientMid = Color(0xFF4F7CFF)
val GradientEnd = Color(0xFF00E5FF)
