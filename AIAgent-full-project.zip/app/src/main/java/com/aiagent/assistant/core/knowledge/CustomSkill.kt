package com.aiagent.assistant.core.knowledge

/** User-এর নিজের বানানো skill-এর domain model। */
data class CustomSkill(
    val id: String,
    val displayName: String,
    val packageNames: List<String>,
    val screens: List<KnownScreen>,
    val actions: List<SkillAction>
)
