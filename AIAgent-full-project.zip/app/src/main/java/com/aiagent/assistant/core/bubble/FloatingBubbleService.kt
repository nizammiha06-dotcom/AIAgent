package com.aiagent.assistant.core.bubble

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.content.ComponentName
import androidx.core.app.ServiceCompat
import com.aiagent.assistant.MainActivity
import com.aiagent.assistant.core.agent.AgentNotifications
import com.aiagent.assistant.core.voice.LiveVoiceSession
import com.aiagent.assistant.core.voice.VoicePhase
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * অন্য app-এর উপরে ছোট bubble। Drag করা যায়, tap করলে quick panel খোলে।
 */
@AndroidEntryPoint
class FloatingBubbleService : Service() {

    @Inject lateinit var live: LiveVoiceSession

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: View? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ServiceCompat.startForeground(
            this,
            BUBBLE_NOTIFICATION_ID,
            AgentNotifications.build(this, "Bubble চালু আছে"),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        addBubble()
        scope.launch {
            live.state.collectLatest { s ->
                bubble?.text = when (s.phase) {
                    VoicePhase.LISTENING -> "🎙"
                    VoicePhase.THINKING -> "…"
                    VoicePhase.SPEAKING -> "🔊"
                    else -> "AI"
                }
            }
        }
    }

    private fun addBubble() {
        val view = TextView(this).apply {
            text = "AI"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF7C4DFF.toInt())
            setPadding(24, 24, 24, 24)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 300
        }

        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    // END gravity-তে x উল্টো দিকে বাড়ে
                    params.x = startX - dx
                    params.y = startY + dy
                    wm.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }

        wm.addView(view, params)
        bubble = view
    }

    private fun togglePanel() {
        if (panel != null) {
            hidePanel()
            return
        }
        val p = QuickPanelView(
            context = this,
            onVoice = {
                if (live.isActive) live.stop() else live.start()
                hidePanel()
            },
            onNewChat = {
                openApp("chat")
                hidePanel()
            },
            onOpenApp = {
                openApp(null)
                hidePanel()
            },
            onClose = { hidePanel() }
        )
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 420
        }
        wm.addView(p, params)
        panel = p
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
    }

    /** Chat route বা শুধু app খোলার জন্য MainActivity-তে intent পাঠায়। */
    private fun openApp(route: String?) {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(EXTRA_ROUTE, route)
        startActivity(intent)
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val BUBBLE_NOTIFICATION_ID = 1002
        const val EXTRA_ROUTE = "route"
    }
}
