package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PhoneSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.dialer",
        "com.samsung.android.dialer",
        "com.android.dialer"
    )
    override val displayName = "Phone"

    override val screens = listOf(
        KnownScreen(
            id = "ph_keypad",
            nameEn = "Keypad",
            nameBn = "কীপ্যাড",
            identifyingTexts = listOf("Dial", "Keypad", "Recents")
        ),
        KnownScreen(
            id = "ph_incall",
            nameEn = "In call",
            nameBn = "কল চলছে",
            identifyingTexts = listOf("End call", "Mute", "Speaker")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "dial_number",
            descriptionEn = "Type a phone number on the keypad",
            descriptionBn = "কীপ্যাডে নম্বর লেখা",
            targetHints = listOf("Keypad", "Dial")
        ),
        SkillAction(
            id = "call",
            descriptionEn = "Tap the call button to start the call",
            descriptionBn = "কল বাটনে চেপে কল শুরু",
            targetHints = listOf("Call", "Dial"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "end_call",
            descriptionEn = "Tap End call to hang up",
            descriptionBn = "কল কাটতে End call চাপা",
            targetHints = listOf("End call")
        )
    )
}
