package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CalendarSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf(
        "com.google.android.calendar",
        "com.samsung.android.calendar",
        "com.android.calendar"
    )
    override val displayName = "Calendar"

    override val screens = listOf(
        KnownScreen(
            id = "cal_agenda",
            nameEn = "Agenda / day view",
            nameBn = "দিনের সূচি",
            identifyingTexts = listOf("Today", "Agenda", "Month")
        ),
        KnownScreen(
            id = "cal_new_event",
            nameEn = "New event",
            nameBn = "নতুন ইভেন্ট",
            identifyingTexts = listOf("Add title", "Save", "Event")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "new_event",
            descriptionEn = "Tap the plus or Create button to start a new event",
            descriptionBn = "+ বা Create চাপে নতুন ইভেন্ট শুরু",
            targetHints = listOf("Create", "+", "Event")
        ),
        SkillAction(
            id = "fill_title",
            descriptionEn = "Type the event title",
            descriptionBn = "ইভেন্টের শিরোনাম লেখা",
            targetHints = listOf("Add title")
        ),
        SkillAction(
            id = "save_event",
            descriptionEn = "Tap Save to create the event",
            descriptionBn = "ইভেন্ট তৈরিতে Save চাপা",
            targetHints = listOf("Save"),
            requiresConfirmation = true
        )
    )
}
