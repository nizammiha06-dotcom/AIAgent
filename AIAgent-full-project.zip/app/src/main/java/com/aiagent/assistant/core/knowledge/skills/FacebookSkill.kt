package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FacebookSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.facebook.katana")
    override val displayName = "Facebook"

    override val screens = listOf(
        KnownScreen(
            id = "fb_feed",
            nameEn = "News feed",
            nameBn = "নিউজ ফিড",
            identifyingTexts = listOf("What's on your mind", "Watch", "Marketplace")
        ),
        KnownScreen(
            id = "fb_composer",
            nameEn = "Create post",
            nameBn = "পোস্ট তৈরি",
            identifyingTexts = listOf("Create post", "Post")
        ),
        KnownScreen(
            id = "fb_search",
            nameEn = "Search",
            nameBn = "সার্চ",
            identifyingTexts = listOf("Search Facebook")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "write_post",
            descriptionEn = "Tap 'What's on your mind' and type the post text",
            descriptionBn = "'What's on your mind' চাপো, তারপর লেখা বসাও",
            targetHints = listOf("What's on your mind")
        ),
        SkillAction(
            id = "publish_post",
            descriptionEn = "Tap Post to publish the composed post",
            descriptionBn = "পোস্ট প্রকাশ করতে Post চাপো",
            targetHints = listOf("Post"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "search",
            descriptionEn = "Open search and type a query",
            descriptionBn = "সার্চে গিয়ে query লেখা",
            targetHints = listOf("Search Facebook", "Search")
        )
    )
}
