package com.aiagent.assistant.core.planner

import com.aiagent.assistant.core.accessibility.AgentAction
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

/** AI-এর JSON উত্তর থেকে TaskPlan বানায়। ভুল format হলে null ফেরত দেয়। */
@Singleton
class PlanParser @Inject constructor() {

    fun parse(goal: String, raw: String): TaskPlan? {
        val json = extractJson(raw) ?: return null
        return try {
            val obj = JSONObject(json)
            val arr: JSONArray = obj.getJSONArray("steps")
            val steps = (0 until arr.length()).mapNotNull { i ->
                parseStep(i, arr.getJSONObject(i))
            }
            if (steps.isEmpty()) null
            else TaskPlan(id = UUID.randomUUID().toString(), goal = goal, steps = steps)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseStep(index: Int, o: JSONObject): PlanStep? {
        val title = o.optString("title").takeIf { it.isNotBlank() } ?: return null
        val actionsArr = o.optJSONArray("actions") ?: return null
        val actions = (0 until actionsArr.length()).mapNotNull { parseAction(actionsArr.getJSONObject(it)) }
        if (actions.isEmpty()) return null
        return PlanStep(
            index = index,
            title = title,
            app = o.optString("app").ifBlank { null },
            actions = actions,
            needsConfirmation = o.optBoolean("needsConfirmation", false)
        )
    }

    private fun parseAction(o: JSONObject): AgentAction? = when (o.optString("type")) {
        "click" -> AgentAction.Click(o.optString("target"))
        "long_press" -> AgentAction.LongPress(o.optString("target"))
        "type" -> AgentAction.Type(o.optString("target"), o.optString("text"))
        "scroll" -> AgentAction.Scroll(o.optBoolean("forward", true))
        "back" -> AgentAction.Back
        "home" -> AgentAction.Home
        "wait" -> AgentAction.Wait(o.optLong("millis", 1000L).coerceIn(100L, 15_000L))
        "verify" -> AgentAction.Verify(o.optString("expected"))
        else -> null
    }

    /** AI কখনো ```json ব্লকে বা লেখার ভেতরে JSON দেয়; সেখান থেকে {...} বের করে। */
    private fun extractJson(raw: String): String? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start >= 0 && end > start) raw.substring(start, end + 1) else null
    }
}
