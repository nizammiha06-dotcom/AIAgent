package com.aiagent.assistant.core.knowledge.skills

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.KnownScreen
import com.aiagent.assistant.core.knowledge.SkillAction
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChromeSkill @Inject constructor() : AppSkill {

    override val packageNames = listOf("com.android.chrome")
    override val displayName = "Chrome"

    override val screens = listOf(
        KnownScreen(
            id = "chrome_home",
            nameEn = "New tab / home",
            nameBn = "নতুন ট্যাব",
            identifyingTexts = listOf("Search or type URL", "Search or type web address")
        ),
        KnownScreen(
            id = "chrome_page",
            nameEn = "Web page",
            nameBn = "ওয়েব পেজ",
            identifyingTexts = listOf("More options", "Open tabs")
        ),
        KnownScreen(
            id = "chrome_download",
            nameEn = "Downloads",
            nameBn = "ডাউনলোড",
            identifyingTexts = listOf("Downloads", "Download complete")
        )
    )

    override val actions = listOf(
        SkillAction(
            id = "open_url",
            descriptionEn = "Type a URL into the address bar and open it",
            descriptionBn = "Address bar-এ URL লিখে খোলা",
            targetHints = listOf("Search or type URL", "Search or type web address")
        ),
        SkillAction(
            id = "open_menu",
            descriptionEn = "Open the three-dot menu",
            descriptionBn = "তিন বিন্দুর মেনু খোলা",
            targetHints = listOf("More options", "Menu")
        ),
        SkillAction(
            id = "download_link",
            descriptionEn = "Tap a download button or a download link on the page",
            descriptionBn = "পেজের download বাটন বা লিংকে ট্যাপ",
            targetHints = listOf("Download", "Save", "Download video"),
            requiresConfirmation = true
        ),
        SkillAction(
            id = "open_downloads",
            descriptionEn = "Open the Downloads list from the menu",
            descriptionBn = "মেনু থেকে Downloads খোলা",
            targetHints = listOf("Downloads")
        )
    )
}
