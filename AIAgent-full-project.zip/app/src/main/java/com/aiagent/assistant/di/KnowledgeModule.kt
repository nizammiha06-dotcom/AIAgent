package com.aiagent.assistant.di

import com.aiagent.assistant.core.knowledge.AppSkill
import com.aiagent.assistant.core.knowledge.skills.CalendarSkill
import com.aiagent.assistant.core.knowledge.skills.CameraSkill
import com.aiagent.assistant.core.knowledge.skills.CapCutSkill
import com.aiagent.assistant.core.knowledge.skills.ChromeSkill
import com.aiagent.assistant.core.knowledge.skills.ClockSkill
import com.aiagent.assistant.core.knowledge.skills.FacebookSkill
import com.aiagent.assistant.core.knowledge.skills.GallerySkill
import com.aiagent.assistant.core.knowledge.skills.GmailSkill
import com.aiagent.assistant.core.knowledge.skills.InstagramSkill
import com.aiagent.assistant.core.knowledge.skills.MapsSkill
import com.aiagent.assistant.core.knowledge.skills.MessagesSkill
import com.aiagent.assistant.core.knowledge.skills.MessengerSkill
import com.aiagent.assistant.core.knowledge.skills.NotesSkill
import com.aiagent.assistant.core.knowledge.skills.PhoneSkill
import com.aiagent.assistant.core.knowledge.skills.PlayStoreSkill
import com.aiagent.assistant.core.knowledge.skills.SettingsSkill
import com.aiagent.assistant.core.knowledge.skills.TikTokSkill
import com.aiagent.assistant.core.knowledge.skills.WhatsAppSkill
import com.aiagent.assistant.core.knowledge.skills.YouTubeSkill
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.IntoSet

@Module
@InstallIn(SingletonComponent::class)
abstract class KnowledgeModule {

    @Binds @IntoSet abstract fun bindChrome(skill: ChromeSkill): AppSkill
    @Binds @IntoSet abstract fun bindYouTube(skill: YouTubeSkill): AppSkill
    @Binds @IntoSet abstract fun bindCapCut(skill: CapCutSkill): AppSkill
    @Binds @IntoSet abstract fun bindFacebook(skill: FacebookSkill): AppSkill
    @Binds @IntoSet abstract fun bindGallery(skill: GallerySkill): AppSkill
    @Binds @IntoSet abstract fun bindWhatsApp(skill: WhatsAppSkill): AppSkill
    @Binds @IntoSet abstract fun bindInstagram(skill: InstagramSkill): AppSkill
    @Binds @IntoSet abstract fun bindGmail(skill: GmailSkill): AppSkill
    @Binds @IntoSet abstract fun bindMaps(skill: MapsSkill): AppSkill
    @Binds @IntoSet abstract fun bindPlayStore(skill: PlayStoreSkill): AppSkill
    @Binds @IntoSet abstract fun bindMessenger(skill: MessengerSkill): AppSkill
    @Binds @IntoSet abstract fun bindSettings(skill: SettingsSkill): AppSkill
    @Binds @IntoSet abstract fun bindCamera(skill: CameraSkill): AppSkill
    @Binds @IntoSet abstract fun bindPhone(skill: PhoneSkill): AppSkill
    @Binds @IntoSet abstract fun bindMessages(skill: MessagesSkill): AppSkill
    @Binds @IntoSet abstract fun bindCalendar(skill: CalendarSkill): AppSkill
    @Binds @IntoSet abstract fun bindClock(skill: ClockSkill): AppSkill
    @Binds @IntoSet abstract fun bindNotes(skill: NotesSkill): AppSkill
    @Binds @IntoSet abstract fun bindTikTok(skill: TikTokSkill): AppSkill
}
