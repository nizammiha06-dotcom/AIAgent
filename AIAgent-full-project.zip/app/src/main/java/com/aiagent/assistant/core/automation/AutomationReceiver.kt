package com.aiagent.assistant.core.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/** Alarm বাজলে এখানে আসে, তারপর runner চালু হয়। */
@AndroidEntryPoint
class AutomationReceiver : BroadcastReceiver() {

    @Inject lateinit var runner: AutomationRunner

    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(EXTRA_ID) ?: return
        runner.run(id)
    }

    companion object {
        const val EXTRA_ID = "automation_id"
    }
}
