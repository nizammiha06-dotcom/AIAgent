package com.aiagent.assistant.data.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import javax.inject.Inject
import javax.inject.Singleton

data class ChatTurn(val role: String, val content: String)

class AiException(val code: Int, message: String) : Exception(message)

@Singleton
class AiClient @Inject constructor(
    private val http: OkHttpClient
) {

    suspend fun stream(
        config: AiProviderConfig,
        apiKey: String?,
        messages: List<ChatTurn>,
        onDelta: suspend (String) -> Unit
    ): String = streamRaw(config, apiKey, buildTextMessages(messages), onDelta)

    /** Image সহ একটি প্রশ্ন (vision)। Non-streaming। */
    suspend fun describeImage(
        config: AiProviderConfig,
        apiKey: String?,
        prompt: String,
        jpeg: ByteArray
    ): String = withContext(Dispatchers.IO) {
        val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val msgs = JSONArray()
        when (config.protocol) {
            Protocol.OPENAI_COMPATIBLE -> msgs.put(
                JSONObject().put("role", "user").put("content", JSONArray()
                    .put(JSONObject().put("type", "text").put("text", prompt))
                    .put(JSONObject().put("type", "image_url")
                        .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
                )
            )
            Protocol.ANTHROPIC -> msgs.put(
                JSONObject().put("role", "user").put("content", JSONArray()
                    .put(JSONObject().put("type", "image")
                        .put("source", JSONObject()
                            .put("type", "base64")
                            .put("media_type", "image/jpeg")
                            .put("data", b64)))
                    .put(JSONObject().put("type", "text").put("text", prompt))
                )
            )
        }
        val body = JSONObject().put("model", config.model).put("max_tokens", config.maxTokens)
        val url: String
        val builder = Request.Builder()
        when (config.protocol) {
            Protocol.OPENAI_COMPATIBLE -> {
                body.put("messages", msgs)
                url = config.baseUrl.trimEnd('/') + "/chat/completions"
                if (config.requiresKey && !apiKey.isNullOrBlank()) {
                    builder.header("Authorization", "Bearer $apiKey")
                }
            }
            Protocol.ANTHROPIC -> {
                body.put("messages", msgs)
                url = config.baseUrl.trimEnd('/') + "/v1/messages"
                builder.header("x-api-key", apiKey.orEmpty())
                builder.header("anthropic-version", "2023-06-01")
            }
        }
        val req = builder.url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (!res.isSuccessful) throw AiException(res.code, text.take(300))
            val json = JSONObject(text)
            when (config.protocol) {
                Protocol.OPENAI_COMPATIBLE -> json.getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message").getString("content")
                Protocol.ANTHROPIC -> json.getJSONArray("content")
                    .getJSONObject(0).getString("text")
            }
        }
    }

    private fun buildTextMessages(messages: List<ChatTurn>) = messages

    private suspend fun streamRaw(
        config: AiProviderConfig,
        apiKey: String?,
        messages: List<ChatTurn>,
        onDelta: suspend (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val request = buildRequest(config, apiKey, messages, stream = true)
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw AiException(response.code, response.body?.string().orEmpty().take(300))
            }
            val source = response.body?.source() ?: throw AiException(-1, "Empty response")
            val full = StringBuilder()
            while (true) {
                val line = source.readUtf8Line() ?: break
                if (!line.startsWith("data:")) continue
                val data = line.removePrefix("data:").trim()
                if (data == "[DONE]") break
                val delta = parseDelta(config.protocol, data) ?: continue
                full.append(delta)
                onDelta(delta)
            }
            full.toString()
        }
    }

    suspend fun ping(config: AiProviderConfig, apiKey: String?): String = withContext(Dispatchers.IO) {
        val request = buildRequest(
            config, apiKey,
            listOf(ChatTurn("user", "Reply with the single word OK.")),
            stream = false,
            maxTokensOverride = 16
        )
        http.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw AiException(response.code, body.take(300))
            val json = JSONObject(body)
            when (config.protocol) {
                Protocol.OPENAI_COMPATIBLE -> json.getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message").getString("content")
                Protocol.ANTHROPIC -> json.getJSONArray("content")
                    .getJSONObject(0).getString("text")
            }
        }
    }

    private fun parseDelta(protocol: Protocol, data: String): String? {
        val json = JSONObject(data)
        return when (protocol) {
            Protocol.OPENAI_COMPATIBLE -> {
                if (json.has("error")) {
                    throw AiException(-1, json.optJSONObject("error")?.optString("message") ?: "API error")
                }
                json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("delta")?.optString("content")
                    ?.takeIf { it.isNotEmpty() }
            }
            Protocol.ANTHROPIC -> when (json.optString("type")) {
                "content_block_delta" -> json.optJSONObject("delta")?.optString("text")
                    ?.takeIf { it.isNotEmpty() }
                "error" -> throw AiException(
                    -1, json.optJSONObject("error")?.optString("message") ?: "Anthropic error"
                )
                else -> null
            }
        }
    }

    private fun buildRequest(
        config: AiProviderConfig,
        apiKey: String?,
        messages: List<ChatTurn>,
        stream: Boolean,
        maxTokensOverride: Int? = null
    ): Request {
        val msgs = JSONArray()
        messages.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val maxTokens = maxTokensOverride ?: config.maxTokens
        val body = JSONObject().put("model", config.model).put("stream", stream)
        val url: String
        val builder = Request.Builder()

        when (config.protocol) {
            Protocol.OPENAI_COMPATIBLE -> {
                val withSystem = JSONArray()
                withSystem.put(JSONObject().put("role", "system").put("content", config.systemPrompt))
                for (i in 0 until msgs.length()) withSystem.put(msgs.get(i))
                body.put("messages", withSystem)
                    .put("temperature", config.temperature.toDouble())
                    .put("max_tokens", maxTokens)
                url = config.baseUrl.trimEnd('/') + "/chat/completions"
                if (config.requiresKey && !apiKey.isNullOrBlank()) {
                    builder.header("Authorization", "Bearer $apiKey")
                }
            }
            Protocol.ANTHROPIC -> {
                body.put("system", config.systemPrompt)
                    .put("messages", msgs)
                    .put("max_tokens", maxTokens)
                    .put("temperature", config.temperature.toDouble())
                url = config.baseUrl.trimEnd('/') + "/v1/messages"
                builder.header("x-api-key", apiKey.orEmpty())
                builder.header("anthropic-version", "2023-06-01")
            }
        }

        return builder.url(url)
            .header("Accept", if (stream) "text/event-stream" else "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
    }
}
