package com.aiagent.assistant.core.vision

import android.graphics.BitmapFactory
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/** On-device OCR। ইন্টারনেট লাগে না। Bangla script ML Kit-এর পৃথক model লাগে, তাই এটি Latin + Bangla-র জন্য fallback হিসেবে কাজ করে। */
@Singleton
class OcrEngine @Inject constructor() {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(jpeg: ByteArray): String {
        val bitmap = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return ""
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            recognizer.process(image).await().text
        } catch (_: Exception) {
            ""
        } finally {
            bitmap.recycle()
        }
    }
}
