package com.aiagent.assistant.di

import android.content.Context
import androidx.room.Room
import com.aiagent.assistant.data.local.AppDatabase
import com.aiagent.assistant.data.local.AutomationDao
import com.aiagent.assistant.data.local.ChatDao
import com.aiagent.assistant.data.local.CustomSkillDao
import com.aiagent.assistant.data.local.TaskDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "agent.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideChatDao(db: AppDatabase): ChatDao = db.chatDao()
    @Provides fun provideTaskDao(db: AppDatabase): TaskDao = db.taskDao()
    @Provides fun provideAutomationDao(db: AppDatabase): AutomationDao = db.automationDao()
    @Provides fun provideCustomSkillDao(db: AppDatabase): CustomSkillDao = db.customSkillDao()
}
