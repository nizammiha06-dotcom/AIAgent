package com.aiagent.assistant.core.permissions

import android.Manifest.permission.*
import android.app.AlarmManager
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.aiagent.assistant.core.accessibility.AgentAccessibilityService
import com.aiagent.assistant.core.vision.ProjectionPermissionHolder
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PermissionChecker @Inject constructor(
    @ApplicationContext private val context: Context,
    private val projection: ProjectionPermissionHolder
) {
    private val pkg: String = context.packageName
    private val sdk: Int = Build.VERSION.SDK_INT

    fun isGranted(id: PermissionId): Boolean = when (id.kind) {
        PermissionKind.SPECIAL -> isSpecialGranted(id)
        PermissionKind.PROJECTION -> projection.hasPermission()
        PermissionKind.RUNTIME -> runtimePermissions(id).all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun snapshot(): Map<PermissionId, Boolean> =
        PermissionId.entries.associateWith { isGranted(it) }

    fun runtimePermissions(id: PermissionId): List<String> = when (id) {
        PermissionId.MICROPHONE -> listOf(RECORD_AUDIO)
        PermissionId.NOTIFICATIONS ->
            if (sdk >= Build.VERSION_CODES.TIRAMISU) listOf(POST_NOTIFICATIONS) else emptyList()
        PermissionId.MEDIA_STORAGE ->
            if (sdk >= Build.VERSION_CODES.TIRAMISU)
                listOf(READ_MEDIA_IMAGES, READ_MEDIA_VIDEO, READ_MEDIA_AUDIO)
            else listOf(READ_EXTERNAL_STORAGE)
        PermissionId.CAMERA -> listOf(CAMERA)
        PermissionId.CONTACTS -> listOf(READ_CONTACTS)
        PermissionId.PHONE -> listOf(CALL_PHONE, READ_PHONE_STATE)
        PermissionId.SMS -> listOf(SEND_SMS, READ_SMS, RECEIVE_SMS)
        PermissionId.CALENDAR -> listOf(READ_CALENDAR, WRITE_CALENDAR)
        PermissionId.LOCATION -> listOf(ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION)
        PermissionId.BACKGROUND_LOCATION -> listOf(ACCESS_BACKGROUND_LOCATION)
        PermissionId.BLUETOOTH ->
            if (sdk >= Build.VERSION_CODES.S) listOf(BLUETOOTH_SCAN, BLUETOOTH_CONNECT)
            else emptyList()
        else -> emptyList()
    }

    private fun isSpecialGranted(id: PermissionId): Boolean = when (id) {
        PermissionId.ACCESSIBILITY -> isAccessibilityEnabled()
        PermissionId.OVERLAY -> Settings.canDrawOverlays(context)
        PermissionId.NOTIFICATION_LISTENER ->
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(pkg)
        PermissionId.BATTERY_OPTIMIZATION ->
            context.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg)
        PermissionId.USAGE_ACCESS -> hasUsageAccess()
        PermissionId.EXACT_ALARM ->
            if (sdk >= Build.VERSION_CODES.S)
                context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
            else true
        PermissionId.INSTALL_UNKNOWN_APPS -> context.packageManager.canRequestPackageInstalls()
        else -> false
    }

    private fun isAccessibilityEnabled(): Boolean {
        val expected = ComponentName(context, AgentAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (sdk >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), pkg)
        } else {
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), pkg)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
