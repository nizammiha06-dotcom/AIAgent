package com.aiagent.assistant.presentation.customskill

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.core.knowledge.CustomSkill
import com.aiagent.assistant.data.repository.CustomSkillRepository
import com.aiagent.assistant.ui.components.AppCard
import com.aiagent.assistant.ui.theme.Spacing
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import javax.inject.Inject

@HiltViewModel
class CustomSkillListViewModel @Inject constructor(
    private val repo: CustomSkillRepository
) : ViewModel() {

    val skills: StateFlow<List<CustomSkill>> = repo.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun delete(id: String) {
        viewModelScope.launch { repo.delete(id) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomSkillListScreen(
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onEdit: (String) -> Unit,
    viewModel: CustomSkillListViewModel = hiltViewModel()
) {
    val skills by viewModel.skills.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Custom skills") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) {
                Icon(Icons.Filled.Add, contentDescription = "Add skill")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            if (skills.isEmpty()) {
                item {
                    Text(
                        "কোনো custom skill নেই। + চাপে নতুন তৈরি করো।",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            items(skills, key = { it.id }) { s ->
                AppCard {
                    Column(Modifier.padding(Spacing.md)) {
                        Text(s.displayName, style = MaterialTheme.typography.titleMedium)
                        Text(
                            s.packageNames.joinToString(),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Actions: ${s.actions.size}", style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { onEdit(s.id) }) { Text("Edit") }
                        TextButton(onClick = { viewModel.delete(s.id) }) { Text("Delete") }
                    }
                }
            }
        }
    }
}
