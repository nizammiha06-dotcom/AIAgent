package com.aiagent.assistant.presentation.permissions

import androidx.lifecycle.ViewModel
import com.aiagent.assistant.core.permissions.PermissionChecker
import com.aiagent.assistant.core.permissions.PermissionId
import com.aiagent.assistant.core.permissions.PermissionKind
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject

@HiltViewModel
class PermissionViewModel @Inject constructor(
    private val checker: PermissionChecker
) : ViewModel() {

    private val _state = MutableStateFlow(checker.snapshot())
    val state: StateFlow<Map<PermissionId, Boolean>> = _state.asStateFlow()

    // Enable All-এর special permission queue
    private val queue = ArrayDeque<PermissionId>()
    private var awaitingReturn = false

    fun refresh() {
        _state.value = checker.snapshot()
    }

    fun runtimePermissions(id: PermissionId): List<String> =
        checker.runtimePermissions(id)

    /** Background Location বাদে সব runtime permission-এর Android permission string। */
    fun missingRuntimePermissions(): List<String> =
        PermissionId.entries
            .filter {
                it.kind == PermissionKind.RUNTIME &&
                    it != PermissionId.BACKGROUND_LOCATION &&
                    !checker.isGranted(it)
            }
            .flatMap { checker.runtimePermissions(it) }
            .distinct()

    /** সব বাকি special permission-এর queue তৈরি করে প্রথমটি ফেরত দেয়। */
    fun startEnableAll(): PermissionId? {
        queue.clear()
        queue.addAll(
            PermissionId.entries.filter {
                it.kind == PermissionKind.SPECIAL && !checker.isGranted(it)
            }
        )
        awaitingReturn = queue.isNotEmpty()
        return queue.firstOrNull()
    }

    /** Settings থেকে ফিরে এলে status refresh করে পরের permission ফেরত দেয়। */
    fun onResumed(): PermissionId? {
        refresh()
        if (!awaitingReturn) return null
        if (queue.isNotEmpty()) queue.removeFirst()
        val next = queue.firstOrNull()
        awaitingReturn = next != null
        return next
    }
}
