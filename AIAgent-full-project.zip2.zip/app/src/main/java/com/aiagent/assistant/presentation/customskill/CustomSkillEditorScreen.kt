package com.aiagent.assistant.presentation.customskill

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.aiagent.assistant.core.knowledge.CustomSkill
import com.aiagent.assistant.ui.theme.Spacing
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomSkillEditorScreen(
    skillId: String?,
    existing: CustomSkill?,
    onBack: () -> Unit,
    viewModel: CustomSkillEditorViewModel = hiltViewModel()
) {
    val s by viewModel.state.collectAsState()

    LaunchedEffect(skillId) { viewModel.load(existing) }
    LaunchedEffect(s.saved) { if (s.saved) onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (skillId == null) "নতুন skill" else "Skill সম্পাদনা") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(Spacing.md),
            verticalArrangement = Arrangement.spacedBy(Spacing.xs)
        ) {
            item {
                OutlinedTextField(
                    value = s.displayName,
                    onValueChange = viewModel::setName,
                    label = { Text("অ্যাপের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = s.packages,
                    onValueChange = viewModel::setPackages,
                    label = { Text("Package name (কমা দিয়ে)") },
                    supportingText = { Text("যেমন: com.example.app") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item { Text("Screens", style = MaterialTheme.typography.titleSmall) }
            itemsIndexed(s.screens) { i, sc ->
                Column(verticalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
                    OutlinedTextField(
                        value = sc.name,
                        onValueChange = { viewModel.editScreen(i, sc.copy(name = it)) },
                        label = { Text("Screen নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = sc.hints,
                        onValueChange = { viewModel.editScreen(i, sc.copy(hints = it)) },
                        label = { Text("স্ক্রিন চেনার text (কমা দিয়ে)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButtonRow("Remove screen") { viewModel.removeScreen(i) }
                }
            }
            item {
                OutlinedButton(onClick = viewModel::addScreen, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Screen যোগ")
                }
            }

            item { Text("Actions", style = MaterialTheme.typography.titleSmall) }
            itemsIndexed(s.actions) { i, a ->
                Column(verticalArrangement = Arrangement.spacedBy(Spacing.xxs)) {
                    OutlinedTextField(
                        value = a.id,
                        onValueChange = { viewModel.editAction(i, a.copy(id = it)) },
                        label = { Text("Action id (যেমন: open_menu)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = a.description,
                        onValueChange = { viewModel.editAction(i, a.copy(description = it)) },
                        label = { Text("কী করে") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = a.hints,
                        onValueChange = { viewModel.editAction(i, a.copy(hints = it)) },
                        label = { Text("Button/field-এর label (কমা দিয়ে)") },
                        supportingText = { Text("Debug স্ক্রিনে দেখা label হুবহু লেখো") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(
                            checked = a.needsConfirm,
                            onCheckedChange = { viewModel.editAction(i, a.copy(needsConfirm = it)) }
                        )
                        Text("নিশ্চিতকরণ লাগবে", modifier = Modifier.fillMaxWidth(0.6f))
                        IconButton(onClick = { viewModel.removeAction(i) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Remove action")
                        }
                    }
                }
            }
            item {
                OutlinedButton(onClick = viewModel::addAction, modifier = Modifier.fillMaxWidth()) {
                    Text("+ Action যোগ")
                }
            }

            item {
                s.error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                Button(onClick = viewModel::save, modifier = Modifier.fillMaxWidth()) {
                    Text("Save · সেভ")
                }
            }
            if (skillId != null) {
                item {
                    OutlinedButton(onClick = viewModel::deleteCurrent, modifier = Modifier.fillMaxWidth()) {
                        Text("Delete skill")
                    }
                }
            }
        }
    }
}

@Composable
private fun TextButtonRow(label: String, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick) { Text(label) }
}
